-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 05, 2010 at 10:34 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ims`
--

-- --------------------------------------------------------

--
-- Table structure for table `jos_vm_product`
--

CREATE TABLE IF NOT EXISTS `jos_vm_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) NOT NULL DEFAULT '0',
  `product_parent_id` int(11) NOT NULL DEFAULT '0',
  `product_sku` varchar(64) NOT NULL DEFAULT '',
  `product_s_desc` varchar(255) DEFAULT NULL,
  `product_desc` text,
  `product_thumb_image` varchar(255) DEFAULT NULL,
  `product_full_image` varchar(255) DEFAULT NULL,
  `product_publish` char(1) DEFAULT NULL,
  `product_weight` decimal(10,4) DEFAULT NULL,
  `product_weight_uom` varchar(32) DEFAULT 'pounds.',
  `product_length` decimal(10,4) DEFAULT NULL,
  `product_width` decimal(10,4) DEFAULT NULL,
  `product_height` decimal(10,4) DEFAULT NULL,
  `product_lwh_uom` varchar(32) DEFAULT 'inches',
  `product_url` varchar(255) DEFAULT NULL,
  `product_in_stock` int(11) NOT NULL DEFAULT '0',
  `product_available_date` int(11) DEFAULT NULL,
  `product_availability` varchar(56) NOT NULL DEFAULT '',
  `product_special` char(1) DEFAULT NULL,
  `product_discount_id` int(11) DEFAULT NULL,
  `ship_code_id` int(11) DEFAULT NULL,
  `cdate` int(11) DEFAULT NULL,
  `mdate` int(11) DEFAULT NULL,
  `product_name` varchar(64) DEFAULT NULL,
  `product_sales` int(11) NOT NULL DEFAULT '0',
  `attribute` text,
  `custom_attribute` text NOT NULL,
  `product_tax_id` int(11) DEFAULT NULL,
  `product_unit` varchar(32) DEFAULT NULL,
  `product_packaging` int(11) DEFAULT NULL,
  `child_options` varchar(45) DEFAULT NULL,
  `quantity_options` varchar(45) DEFAULT NULL,
  `child_option_ids` varchar(45) DEFAULT NULL,
  `product_order_levels` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  KEY `idx_product_vendor_id` (`vendor_id`),
  KEY `idx_product_product_parent_id` (`product_parent_id`),
  KEY `idx_product_sku` (`product_sku`),
  KEY `idx_product_ship_code_id` (`ship_code_id`),
  KEY `idx_product_name` (`product_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='All products are stored here.' AUTO_INCREMENT=27 ;

--
-- Dumping data for table `jos_vm_product`
--

INSERT INTO `jos_vm_product` (`product_id`, `vendor_id`, `product_parent_id`, `product_sku`, `product_s_desc`, `product_desc`, `product_thumb_image`, `product_full_image`, `product_publish`, `product_weight`, `product_weight_uom`, `product_length`, `product_width`, `product_height`, `product_lwh_uom`, `product_url`, `product_in_stock`, `product_available_date`, `product_availability`, `product_special`, `product_discount_id`, `ship_code_id`, `cdate`, `mdate`, `product_name`, `product_sales`, `attribute`, `custom_attribute`, `product_tax_id`, `product_unit`, `product_packaging`, `child_options`, `quantity_options`, `child_option_ids`, `product_order_levels`) VALUES
(1, 1, 0, 'G01', '<p>Nice hand shovel to dig with in the yard.</p>\r\n', '\r\n<ul>  <li>Hand crafted handle with maximum grip torque  </li><li>Titanium tipped shovel platter  </li><li>Half degree offset for less accidents  </li><li>Includes HowTo Video narrated by Bob Costas  </li></ul>    <b>Specifications</b><br />  5" Diameter<br />  Tungsten handle tip with 5 point loft<br />\r\n', '8d886c5855770cc01a3b8a2db57f6600.jpg', 'cca3cd5db813ee6badf6a3598832f2fc.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 10, 1072911600, '48h.gif', 'Y', 1, NULL, 950320117, 1084907592, 'Hand Shovel', 0, '', '', 2, '', 0, NULL, NULL, NULL, NULL),
(2, 1, 0, 'G02', 'A really long ladder to reach high places.', '\r\n<ul>  <li>Hand crafted handle with maximum grip torque  </li><li>Titanium tipped shovel platter  </li><li>Half degree offset for less accidents  </li><li>Includes HowTo Video narrated by Bob Costas  </li></ul>    <b>Specifications</b><br />  5" Diameter<br />  Tungsten handle tip with 5 point loft<br />\r\n', 'ffd5d5ace2840232c8c32de59553cd8d.jpg', '8cb8d644ef299639b7eab25829d13dbc.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 76, 1072911600, '3-5d.gif', 'N', 0, NULL, 950320180, 1084907618, 'Ladder', 0, '', '', 2, '', 0, NULL, NULL, NULL, NULL),
(3, 1, 0, 'G03', 'Nice shovel.  You can dig your way to China with this one.', '\r\n<ul>  <li>Hand crafted handle with maximum grip torque  </li><li>Titanium tipped shovel platter  </li><li>Half degree offset for less accidents  </li><li>Includes HowTo Video narrated by Bob Costas  </li></ul>    <b>Specifications</b><br />  5" Diameter<br />  Tungsten handle tip with 5 point loft<br />\r\n', '8147a3a9666aec0296525dbd81f9705e.jpg', '520efefd6d7977f91b16fac1149c7438.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 32, 1072911600, '7d.gif', 'N', 0, NULL, 950320243, 1084907765, 'Shovel', 0, 'Size,XL[+1.99],M,S[-2.99];Colour,Red,Green,Yellow,ExpensiveColor[=24.00]', '', 2, '', 0, NULL, NULL, NULL, NULL),
(4, 1, 0, 'G04', 'This shovel is smaller but you''ll be able to dig real quick.', '\r\n<ul>  <li>Hand crafted handle with maximum grip torque  </li><li>Titanium tipped shovel platter  </li><li>Half degree offset for less accidents  </li><li>Includes HowTo Video narrated by Bob Costas  </li></ul>    <b>Specifications</b><br />  5" Diameter<br />  Tungsten handle tip with 5 point loft<br />\r\n', 'a04395a8aefacd9c1659ebca4dbfd4ba.jpg', '1b0c96d67abdbea648cd0ea96fd6abcb.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 98, 1088632800, 'on-order.gif', 'N', 0, NULL, 950320378, 1084907867, 'Smaller Shovel', 0, 'Size,big[+2.99],medium;Color,red[+0.99],green[-0.99]', '', 2, '', 0, NULL, NULL, NULL, NULL),
(5, 1, 0, 'H01', 'This saw is great for getting cutting through downed limbs.', '\r\n<ul>  <li>Hand crafted handle with maximum grip torque  </li><li>Titanium tipped shovel platter  </li><li>Half degree offset for less accidents  </li><li>Includes HowTo Video narrated by Bob Costas  </li></ul>    <b>Specifications</b><br />  5" Diameter<br />  Tungsten handle tip with 5 point loft<br />\r\n', '1aa8846d3cfe3504b2ccaf7c23bb748f.jpg', 'e614ba08c3ee0c2adc62fd9e5b9440eb.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 32, 1072911600, '1-4w.gif', 'Y', 2, NULL, 950321256, 1084907669, 'Nice Saw', 0, 'Size,big,small,medium;Power,100W,200W,500W', '', 2, '', 0, NULL, NULL, NULL, NULL),
(6, 1, 0, '2043934712', 'A great hammer to hammer away with.', '<ul>\r\n<li>Hand crafted handle with maximum grip torque </li>\r\n<li>Titanium tipped shovel platter </li>\r\n<li>Half degree offset for less accidents </li>\r\n<li>Includes HowTo Video narrated by Bob Costas </li>\r\n</ul>\r\n<p><strong>Specifications</strong><br /> 5" Diameter<br /> Tungsten handle tip with 5 point loft</p>', 'dccb8223891a17d752bfc1477d320da9.jpg', '578563851019e01264a9b40dcf1c4ab6.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 500, 1072828800, '24h.gif', 'N', 0, NULL, 950321631, 1271795801, 'Hammer', 0, 'Size,big,medium,small;Material,wood and metal,plastic and metal[-0.99]', '', 2, '', 0, 'N,N,N,N,N,N,,,', 'none,0,0,1', '', '0,0'),
(7, 1, 0, '1861769017', 'Don''t do it with an axe.  Get a chain saw.', '<ul>\r\n<li>Tool-free tensioner for easy, convenient chain adjustment </li>\r\n<li>3-Way Auto Stop; stops chain a fraction of a second </li>\r\n<li>Automatic chain oiler regulates oil for proper chain lubrication </li>\r\n<li>Small radius guide bar reduces kick-back </li>\r\n</ul>\r\n<p><br /> <strong>Specifications</strong><br /> 12.5 AMPS   <br /> 16" Bar Length   <br /> 3.5 HP   <br /> 8.05 LBS. Weight</p>', '8716aefc3b0dce8870360604e6eb8744.jpg', 'c3a5bf074da14f30c849d13a2dd87d2c.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 49, 1088553600, '48h.gif', 'N', 0, NULL, 950321725, 1271795699, 'Chain Saw', 0, '', '', 2, '', 0, 'N,N,N,N,N,Y,,,', 'none,0,0,1', '', '0,0'),
(8, 1, 0, '261909999', 'Cut rings around wood.  This saw can handle the most delicate projects.', '<ul>\r\n<li>Patented Sightline; Window provides maximum visibility for straight cuts </li>\r\n<li>Adjustable dust chute for cleaner work area </li>\r\n<li>Bail handle for controlled cutting in 90° to 45° applications </li>\r\n<li>1-1/2 to 2-1/2 lbs. lighter and 40% less noise than the average circular saw </li>\r\n<li><strong>Includes:</strong>Carbide blade </li>\r\n</ul>\r\n<p><br /> <strong>Specifications</strong><br /> 10.0 AMPS   <br /> 4,300 RPM   <br /> Capacity: 2-1/16" at 90°, 1-3/4" at 45°</p>', 'b4a748303d0d996b29d5a1e1d1112537.jpg', '9a4448bb13e2f7699613b2cfd7cd51ad.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 33, 1072828800, '3-5d.gif', 'N', 1, NULL, 950321795, 1271795721, 'Circular Saw', 0, 'Size,XL[+1],M,S[-2];Power,strong,middle,poor[=24]', '', 2, '', 0, 'N,N,N,N,N,N,,,', 'none,0,0,1', '', '0,0'),
(9, 1, 0, '131661501', 'Drill through anything.  This drill has the power you need for those demanding hole boring duties.', '<p><span style="color: #000000; font-size: small;"> \r\n<ul>\r\n<li>High power motor and double gear reduction for increased durability and improved performance </li>\r\n<li>Mid-handle design and two finger trigger for increased balance and comfort </li>\r\n<li>Variable speed switch with lock-on button for continuous use </li>\r\n<li><strong>Includes:</strong> Chuck key & holder </li>\r\n</ul>\r\n<br /> <strong>Specifications</strong><br /> 4.0 AMPS   <br /> 0-1,350 RPM   <br /> Capacity: 3/8" Steel, 1" Wood   <br /><br /> </span></p>\r\n<p> </p>', 'c70a3f47baf9a4020aeeee919eb3fda4.jpg', '1ff5f2527907ca86103288e1b7cc3446.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 30, 1072828800, '2-3d.gif', 'N', 0, NULL, 950321879, 1271798641, 'Drill', 0, '', '', 2, '', 0, 'N,N,N,N,N,Y,,,', 'none,0,0,1', '', '0,0'),
(10, 1, 0, '2010040851', 'Blast away that paint job from the past.  Use this power sander to really show them you mean business.', '<ul>\r\n<li>Lever activated paper clamps for simple sandpaper changes </li>\r\n<li>Dust sealed rocker switch extends product life and keeps dust out of motor </li>\r\n<li>Flush sands on three sides to get into corners </li>\r\n<li>Front handle for extra control </li>\r\n<li>Dust extraction port for cleaner work environment </li>\r\n</ul>\r\n<p><br /> <strong>Specifications</strong><br /> 1.2 AMPS    <br /> 10,000 OPM</p>', '7a36a05526e93964a086f2ddf17fc609.jpg', '480655b410d98a5cc3bef3927e786866.jpg', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 20, 1072828800, '1-2m.gif', 'N', 2, NULL, 950321963, 1271798691, 'Power Sander', 0, 'Size,big,medium,small;Power,100W,200W,300W', '', 2, '', 0, 'N,N,N,N,N,N,,,', 'none,0,0,1', '', '0,20'),
(11, 1, 1, 'G01-01', '', '', '', '', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 0, 0, '', '', 0, NULL, 955696949, 960372163, 'Hand Shovel', 0, NULL, '', 0, '', 0, NULL, NULL, NULL, NULL),
(12, 1, 1, 'G01-02', '', '', '', '', 'Y', '10.0000', '', '0.0000', '0.0000', '0.0000', '', '', 0, 0, '', '', 0, NULL, 955697006, 960372187, 'Hand Shovel', 0, NULL, '', 0, '', 0, NULL, NULL, NULL, NULL),
(13, 1, 1, 'G01-03', '', '', '', '', 'Y', '10.0000', '', '0.0000', '0.0000', '0.0000', '', '', 0, 0, '', '', 0, NULL, 955697044, 960372206, 'Hand Shovel', 0, NULL, '', 0, '', 0, NULL, NULL, NULL, NULL),
(14, 1, 2, 'L01', '', '', '', '', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 22, 1072911600, '', 'N', 0, NULL, 962351149, 1084902820, 'Metal Ladder', 0, NULL, '', 2, '', 0, NULL, NULL, NULL, NULL),
(15, 1, 2, 'L02', '', '', '', '', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 0, 0, '', '', 0, NULL, 962351165, 962351165, 'Wooden Ladder', 0, NULL, '', 0, '', 0, NULL, NULL, NULL, NULL),
(16, 1, 2, 'L03', '', '', '', '', 'Y', '10.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 0, 0, '', '', 0, NULL, 962351180, 962351180, 'Plastic Ladder', 0, NULL, '', 0, '', 0, NULL, NULL, NULL, NULL),
(17, 1, 0, '810575714', '', '', '', '', 'Y', '0.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 100, 1271462400, 'on-order.gif', 'N', 0, NULL, 1271445916, 1271795784, 'Ghee', 0, '', '', 0, 'piece', 0, 'N,N,N,N,N,Y,20%,10%,', 'none,0,0,1', '', '0,0'),
(18, 1, 0, '23', '', '', '', '', 'Y', '150.0000', 'kg', '0.0000', '0.0000', '0.0000', 'inches', '', 50, 1271635200, '', 'N', 0, NULL, 1271653533, 1271714333, 'Onion', 0, '', '', 0, 'kg', 15, 'N,N,N,N,N,Y,20%,10%,', 'none,0,0,1', '', '0,0'),
(19, 2, 0, '25554', '', '<p>Along with other fruits and vegetables, consumption of bananas are associated with a reduced risk of colorectal cancer and in women, breast cancer and renal cell carcinoma.<br />Individuals with a latex allergy may experience a reaction to bananas.<br />The juice extract prepared from the tender core treats kidney stones and high blood pressure.<br />Bananas contain considerable amounts of vitamin B6, vitamin C, and potassium. The latter makes them of particular interest to athletes who use them to quickly replenish their electrolytes.</p>', 'resized/Banana_4bce0b80f187e_90x90.jpg', 'Banana_4bce0b8106c48.jpg', 'Y', '0.0000', 'dozen', '0.0000', '0.0000', '0.0000', 'dozen', '', 0, 1271808000, '14d.gif', 'N', 0, NULL, 1271794561, 1271830303, 'Banana', 0, '', '', 0, 'piece', 3276820, 'N,N,N,N,N,Y,20%,10%,', 'none,0,0,1', '', '0,100'),
(20, 2, 0, '1514700117', '', '<p>Mangoes are widely used in Indian and Pakistani cuisine. Sour, unripe mangoes are used in chutneys, pickles, side dishes like meth-amba in Maharashtra and manga pachadi in Kerala. They are eaten raw with salt and chili. Raw mangoes are preserved in brine with dried red chilis, known as Achar in Hindi or "Ooragaaya" in Telugu or "Oorga" in Tamil and "Uppil Ittathu" in Malayalam literally meaning "Put in Salt". A cooling summer drink called panna or panha comes from mangoes.<br /><br />Ripe mangoes are typically eaten fresh. Mango smoothie, made by adding mango pulp to a yoghurt drink, is a popular drink called lassi in India and Indian restaurants elsewhere. Ripe mangoes are also used to make curries like mambazha kaalan in Kerala. Aamras is a popular pulp/thick juice made of mangoes with sugar or milk and is consumed along with bread.<br /><br />Mangoes are used in preserves like moramba, amchur (dried and powdered unripe mango) and pickles (commonly known as achaar). Different varieties of mango pickles are made in many regions of India, such as Avakaya Pachchadi of Andhra Pradesh, Vadu Maangaa pickle and Thokku Manga pickle from Tamil Nadu, miscut (pronounced mis-koot), a spicy mustard-oil pickle from Goa. Ripe mangoes are often cut into thin layers, desiccated, folded, and then cut. These bars, known as aampapdi,'' amavat or halva in Hindi, are similar to dried guava fruit bars available in Colombia.<br /><br />The fruit is also added to cereal products like muesli and oat granola.</p>', 'resized/Mango_4bce0f4183de4_90x90.jpg', 'Mango_4bce0f418777b.jpg', 'Y', '0.0000', 'dozens', '0.0000', '0.0000', '0.0000', 'dozens', '', 200, 1271721600, '2-3d.gif', 'N', 0, NULL, 1271795521, 1271798596, 'Mango', 0, '', '', 2, 'piece', 1638450, 'N,N,N,N,N,Y,20%,10%,', 'none,0,0,1', '', '200,500'),
(21, 2, 0, '9156', '', '', '', '', 'Y', '0.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 0, 1271808000, '', 'N', 0, NULL, 1271884990, 1271884990, 'Keyboard', 0, '', '', 0, 'piece', 0, 'N,N,N,N,N,N,20%,10%,', 'none,0,0,1', '', '0,0'),
(26, 2, 0, '2486', '', '', '', '', 'Y', '0.0000', 'pounds', '0.0000', '0.0000', '0.0000', 'inches', '', 0, 1271894400, '', 'N', 0, NULL, 1271958360, 1271958360, 'kuch bb nai he product ka name', 0, '', '', 0, 'piece', 0, 'N,N,N,N,N,N,20%,10%,', 'none,0,0,1', '', '0,0');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
