<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SMS ALERT SYS:</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="700" border="0" align="center">
    <tr>
      <td><img src="pics/see.jpg" width="799" height="133" /></td>
    </tr>
  </table>
  <table width="799" height="31" border="0" align="center">
    <tr>
      <td width="708" align="right" bgcolor="#D6D6D6"><a href="mainhtml.php">Home</a> | <a href="sign_in.gui.php">Sgin-out</a></td>
    </tr>
  </table>
  <table width="799" align="center">
    <tr>
      <td height="596" align="center" valign="top"><h1>Choose Any Sending Option</h1>
        <table width="200" height="22">
          <tr>
            <td bgcolor="#CCCCCC"><ul>
              <li><a href="send_org.php">Send to all Orgnization</a></li>
            </ul></td>
          </tr>
          <tr>
            <td bgcolor="#CCCCCC"><ul>
              <li><a href="send_admin.php">Send to all admin</a></li>
            </ul></td>
          </tr>
          <tr>
            <td bgcolor="#CCCCCC"><ul>
              <li><a href="send_vol.php">Send to all Volunteer</a></li>
            </ul></td>
          </tr>
          <tr>
            <td bgcolor="#CCCCCC"><ul>
              <li><a href="send_people.php">Send to Area People</a></li>
            </ul></td>
          </tr>
        </table>
        <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
    </tr>
  </table>
  \
   <table width="799" border="0" align="center">
    <tr>
      <td>footer</td>
    </tr>
  </table>
<p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
