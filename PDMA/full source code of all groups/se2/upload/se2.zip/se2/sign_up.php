<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SMS ALERT SYS:</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="cot.php">
  <table width="700" border="0" align="center">
    <tr>
      <td><img src="pics/see.jpg" width="799" height="133" /></td>
    </tr>
  </table>
  <table width="799" height="31" border="0" align="center">
    <tr>
      <td width="708" align="right" bgcolor="#D6D6D6"><a href="sign_in.gui.php">Sign-in</a></td>
    </tr>
  </table>
  <table width="799" align="center">
    <tr>
      <td height="700" align="center" valign="top"><h2><strong>Add new Employee</strong></h2>
        <table width="400" border="0">
        <tr></tr>
        <tr>
          <td align="center" bgcolor="#D6D6D6">Name</td>
          <td bgcolor="#D6D6D6"><label>
            <input name="nam" type="text" id="nam" size="30" />
          </label></td>
        </tr>
        <tr>
          <td align="center" bgcolor="#D6D6D6">ID</td>
          <td bgcolor="#D6D6D6"><input name="id" type="text" id="id" size="30" /></td>
        </tr>
        <tr>
          <td align="center" bgcolor="#D6D6D6">Password</td>
          <td bgcolor="#D6D6D6"><input name="pswd" type="password" id="pswd" size="30" /></td>
        </tr>
        <tr>
          <td align="center" bgcolor="#D6D6D6">Confirm Password</td>
          <td bgcolor="#D6D6D6"><input name="cpswd" type="password" id="cpswd" size="30" /></td>
        </tr>
        </table>
      <p>
        <label>
          <input type="submit" name="Sginup" id="Sginup" value="Sign-UP" />
        </label>
      </p></td>
    </tr>
  </table>
  \
   <table width="799" border="0" align="center">
    <tr>
      <td align="center">footer</td>
    </tr>
  </table>
<p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
