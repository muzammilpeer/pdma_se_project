<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SMS ALERT SYS:</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="check.php">
  <table width="700" border="0" align="center">
    <tr>
      <td><img src="pics/see.jpg" width="799" height="133" /></td>
    </tr>
  </table>
  <table width="799" height="31" border="0" align="center">
    <tr>
      <td width="708" align="right" bgcolor="#D6D6D6"><a href="sign_up.php">Sign-up</a></td>
    </tr>
  </table>
  <table width="799" align="center">
    <tr>
      <td height="596" align="center" valign="top"><h2>Sign-in</h2>
        <table width="333" border="0" align="center">
        <tr>
          <td width="146" align="center" bgcolor="#D6D6D6">ID</td>
          <td width="177" bgcolor="#D6D6D6"><label>
            <input name="empno" type="text" id="NAME" size="30" />
          </label></td>
        </tr>
        <tr>
          <td align="center" bgcolor="#D6D6D6">Name</td>
          <td bgcolor="#D6D6D6"><label>
            <input name="nam" type="text" id="nam" size="30" />
          </label></td>
        </tr>
        <tr>
          <td align="center" bgcolor="#D6D6D6">Password</td>
          <td bgcolor="#D6D6D6"><label>
            <input name="pasword" type="password" id="pasword" size="30" />
            </label></td>
        </tr>
      </table>
      <p>
        <label>
          <input type="submit" name="signin" id="signin" value="   Login   " />
        </label>
      </p></td>
    </tr>
  </table>
  \
   <table width="799" border="0" align="center">
    <tr>
      <td align="center">footer</td>
    </tr>
  </table>
<p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
