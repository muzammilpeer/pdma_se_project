<?php
/**
* Facile Forms - A Joomla Forms Application
* @version 1.4.4
* @package FacileForms
* @copyright (C) 2004-2005 by Peter Koch
* @license Released under the terms of the GNU General Public License
**/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$_MAMBOTS->registerFunction( 'onPrepareContent', 'botFacileForms' );

function botFacileForms($published, &$row, $mask=0, $page=0)
{
	// store some vars in globals to access from the replacer
	$GLOBALS['botFacileFormsPublished'] = $published;

	// define the regular expression for the bot
	// the syntax is: { FacileForms : formname, page, border, urlparams, suffix }
	$regex =
		"/".                    // delimiter
		"\\{".                  // opening {
		"[\\s]*".               // skip whitespace
		"FacileForms".          // required tag identifier
		"[\\s]*".               // skip whitespace
		":".                    // colon
		"[\\s]*".               // skip whitespace
		"([A-Za-z0-9_\\-]+)".   // required form name
		"(".                        // start of page/border/params scan
			"[\\s]*".               // skip whitespace
			",".                    // require a comma
			"[\\s]*".               // skip whitespace
			"(\\d*)".               // find integer pagenumber
			"(".                        // start border scan
				"[\\s]*".               // skip whitespace
				",".                    // require a comma
				"[\\s]*".              // skip whitespace
				"(0|1)?".               // find border as 0 or 1
				"(".                        // start params scan
					"[\\s]*".               // skip whitespace
					",".                    // require a comma
					"[\\s]*".               // skip whitespace
					"([^\\s\\},]*)".        // find any chars but whitespace, comma and }
	                "(".                        // start suffix scan
	                    "[\\s]*".               // skip whitespace
	                    ",".                    // require a comma
	                    "[\\s]*".               // skip whitespace
	                    "([^\\s\\},]*)".        // find any chars but whitespace, comma and }
	                ")?".                       // 0 or 1 times suffix
				")?".                       // 0 or 1 times params
			")?".                       // 0 or 1 times a border
		")?".                       // 0 or 1 times page/border/params
		"[\\s]*".               // skip whitespace
		"\\}".                  // closing }
		"/s";                    // delimiter

	// perform the replacement
	$row->text = preg_replace_callback( $regex, 'botFacileForms_replacer', $row->text );

	// clean up globals
	unset( $GLOBALS['botFacileFormsPublished'] );

	return true;
} // botFacileForms

function botFacileForms_replacer( &$matches )
{
	global $database, $ff_comsite, $ff_config, $ff_target;

	// return nothing in case the mambot is disabled
	if (!$GLOBALS['botFacileFormsPublished']) return '';

	// get paths
	$ff_mospath = str_replace('\\','/',dirname(dirname(dirname(__FILE__))));
	$ff_compath = $ff_mospath.'/components/com_facileforms';

	// load config
	require_once($ff_compath.'/facileforms.class.php');
	$ff_config = new facileFormsConf();
	initFacileForms('frontend');

	// get the parameters from the regex scan
	$formid   = '';
	$formname = '';
	$page     = 1;
	$border   = 1;
	$params   = '';
	$suffix   = '';
	$cnt = count($matches);
	if ($cnt > 1) {
		$formname = $matches[1];
		if ($cnt > 3) {
			if ($matches[3]!='') $page = intval($matches[3]);
			if ($cnt > 5) {
				if ($matches[5]!='') $border = intval($matches[5]);
				if ($cnt > 7) {
					$params = $matches[7];
					if ($cnt > 9) $suffix = $matches[9];
				} // if
			} // if
		} // if
	} // if

	if (!$ff_target) $ff_target = 1; else $ff_target++;
	$target = mosGetParam($_REQUEST, 'ff_target', '');
	$myTarget = $target==$ff_target || ($target=='' && $ff_target==1);

	if ($myTarget) { // yes, ff_parameters are meant for me
		$formid   = mosGetParam($_REQUEST, 'ff_form',  $formid);
		$formname = mosGetParam($_REQUEST, 'ff_name',  $formname);
		$page     = mosGetParam($_REQUEST, 'ff_page',  $page);
		$border   = mosGetParam($_REQUEST, 'ff_border',$border);
	} // if

	// load form
	if ($formid != '') {
		$database->setQuery(
			"select * from #__facileforms_forms ".
			"where id=$formid and published=1 and runmode<2"
		);
		$forms = $database->loadObjectList();
		if (count($forms) < 1) return '[Form '.$formid.' not found!]';
	} else {
		$database->setQuery(
			"select * from #__facileforms_forms ".
			"where name='$formname' and published=1 and runmode<2 ".
			"order by ordering, id"
		);
		$forms = $database->loadObjectList();
		if (count($forms) < 1) return '[Form '.$formname.' not found!]';
	} // if
	$form = $forms[0];

	// prepare width and height parameters
	$framewidth = 'width="'.$form->width;
	if ($form->widthmode) $framewidth .= '%" '; else $framewidth .= '" ';
	$frameheight = '';
	if (!$form->heightmode) $frameheight = 'height="'.$form->height.'" ';

	// build the url
	$url = $ff_comsite.'/facileforms.frame.php?ff_target='.$ff_target.'&amp;ff_form='.$form->id;
	if ($page>1)     $url .= '&amp;ff_page='.$page;
	if ($border>0)   $url .= '&amp;ff_border='.$border;
	if ($suffix!='') $url .= '&amp;ff_suffix='.urlencode($suffix);
	$url .= $params;
	reset($_POST);
	while (list($prop, $val) = each($_POST))
		if (!is_array($val) && !ff_reserved($prop, !$myTarget))
			$url .= '&amp;'.$prop.'='.urlencode($val);
	reset($_GET);
	while (list($prop, $val) = each($_GET))
		if (!is_array($val) && !ff_reserved($prop, !$myTarget))
			$url .= '&amp;'.$prop.'='.urlencode($val);

	// build frame params
	$params =   'id="ff_frame'.$form->id.'" '.
				'src="'.$url.'" '.
				$framewidth.
				$frameheight.
				'frameborder="'.$border.'" '.
				'allowtransparency="true" '.
				'scrolling="no" ';
	return  "\n<iframe ".$params.">\n".
			"<p>Sorry, your browser cannot display frames!</p>\n".
			"</iframe>\n";
} // botFacileForms_replacer

?>