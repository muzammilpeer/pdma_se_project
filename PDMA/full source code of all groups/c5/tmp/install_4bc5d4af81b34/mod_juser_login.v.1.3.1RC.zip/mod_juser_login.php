<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

global $mosConfig_frontend_login, $database, $mosConfig_absolute_path, $mosConfig_live_site, $my, $path;

function menuoutput($menutype, $menu_class, $sep5, $logout_type, $database, $sep)
					{//Menu output
						$query = "SELECT * FROM #__menu WHERE menutype = '$menutype'";
						$database->setQuery( $query );
					 	$param = $database->loadObjectList();
						$params = $param[0];
						
						echo '<div id="jl_list">'.$sep5;
						
								foreach ($param as $row) 
								{
									$title = $row->name;
									$link = $row->link;
									$pub = $row->published;
									
									if ($pub == 1 and $link != 'index.php?option=com_login') echo '<a href="'.sefRelToAbs ($link).'" class="'.$menu_class.'">'.$title.'</a>'.$sep.$sep5;
									elseif ($logout_type && $pub == 1)  echo ('<a href= "'.sefRelToAbs ($link).'" class="'.$menu_class.'">'.$title.'</a>'.$sep5.$sep);
								}
						echo '</div>';
					}
					
function avataroutput ($showav, $my, $database, $mosConfig_live_site)
					{
					// begin of avatar
					error_reporting(0);
						if($showav)
							{
							?>
					<div id ="ju_av">	  
						  <?php
						  $query = "SELECT *"
							 ."\n FROM #__juser_users_additional_data"
							 ."\n WHERE `user_id` = ".$my->id;
						  $database->setQuery( $query ); 
						  $avatar_ = $database->loadObjectList();
						  $query = "SELECT * FROM #__je_config WHERE name = 'uploaded_avatar_directory'";
						  $database->setQuery( $query );
						  $rows = $database->loadObjectList();
						  $row = $rows[0];
						  $av_path = $row->selected;
						  $av_path = stristr($av_path,"/images/");
						  if(!$avatar_[0]->avatar){ 
						  echo '<img src="'.$mosConfig_live_site.'/administrator/components/com_juser/img/default_avatar.jpg" >';
						  }
						  else {
						  echo '<img src="'.$mosConfig_live_site.$av_path.'user_'.$my->id.strtolower(strrchr($avatar_[0]->avatar,'.')).'" >';
						  } ?>
					</div>	  
						  <?php
						}//end of avatar
					}

if ( $mosConfig_frontend_login != NULL && ($mosConfig_frontend_login === 0 || $mosConfig_frontend_login === '0')) {
	return;
}
ERROR_REPORTING (E_ALL);
// url of current page that user will be returned to after login
if ($query_string = mosGetParam( $_SERVER, 'QUERY_STRING', '' )) {
	$return = 'index.php?' . $query_string;
} else {
	$return = 'index.php';
}
// converts & to &amp; for xtml compliance
$return = str_replace( '&', '&amp;', $return );

@session_start();

if(@$_SESSION['jcs_access_url']) $return = @$_SESSION['jcs_access_url'];

$registration_enabled 	= $mainframe->getCfg( 'allowUserRegistration' );
$message_login 			= $params->def( 'login_message', 	0 );
$message_logout 		= $params->def( 'logout_message', 	0 );
$login 					= $params->def( 'login', 			$return );
$logout 				= $params->def( 'logout', 			$return );
$name 					= $params->def( 'name', 			1 );
$greeting 				= $params->def( 'greeting', 		1 );
$pretext 				= $params->get( 'pretext' );
$posttext 				= $params->get( 'posttext' );
$mplace					= $params->def( 'mplace', 			0 );
$regist					= $params->def( 'regist', 			0 );
$lostpas				= $params->def( 'lostpas', 			0 );
$remme					= $params->def( 'remme', 			0 );
$regurl					= $params->def( 'regurl', 			0 );
$showav					= $params->def( 'showav', 			0 );
$menutype				= $params->def( 'menutype', 			0 );
$logout_type			= $params->def( 'logout_type', 			0 );
$custgreet				= $params->def( 'custgreet', 			0 );
$showmen				= $params->def( 'showmen', 				0 );
$lastlog				= $params->def( 'lastlog',				0 );

//Style switching
	switch ($mplace)
	{
		case 0:	
		
		?>
		<link href="<?php echo $mosConfig_live_site;?>/modules/mod_jlogin/jl_style_vert.css" rel="stylesheet" type="text/css"/>
		<?php
		$sep=null;
		$sep2='<br/>';
		$sep3=null;
		$sep4='</div>';
		$sep5=null;
		$menu_class='mainlevel';
		break;
		
		case 1:
	
		?>
		<link href="<?php echo $mosConfig_live_site;?>/modules/mod_jlogin/jl_style_horiz.css" rel="stylesheet" type="text/css"/>
		<?php
		$sep=null;
		$sep2=null;
		$sep3='</div>';
		$sep4=null;
		$sep5='|';
		$menu_class='horizlevel';
		break;
		
		case 2:
		
		?>
		<link href="<?php echo $mosConfig_live_site;?>/modules/mod_jlogin/jl_style_comp.css" rel="stylesheet" type="text/css"/>
		<?php
		$sep='<br/>';
		$sep2=null;
		$sep3=null;
		$sep4='</div>';
		$sep5=null;
		$menu_class='compactlevel';
		break;
	}
	//end syle switching

	switch ($regurl) {
	case 0:
	$regurl='index.php?option=com_juser&task=UserRegistration';
	break;
	
	case 1:
	$regurl='index.php?option=com_comprofiler&task=registers';
	break;
	
	case 2:
	$regurl='index.php?option=com_registration&task=register';
	break;
	
	}
if ( $my->id ) 
{
// Logout output
// ie HTML when already logged in and trying to logout
	if ( $name ) {
		$name = $my->name;
	} else {
		$name = $my->username;
	}
	?>
	<form action="<?php echo sefRelToAbs( 'index.php?option=logout' ); ?>" method="post" name="logout" id="mod_juser_login">
					<div id=last_login>
						<?php	//last login into
						if ($lastlog)
						{
						$query = 'SELECT `lastvisitDate` FROM #__users WHERE `id` ='.$my->id;
						$database->setQuery ($query);
						$lastvis=$database->loadResult();
						echo 'Last visit: '.$lastvis;
						}
					echo '</div>';
					avataroutput ($showav, $my, $database, $mosConfig_live_site);
						if ($showmen && $mplace==2) {
						menuoutput($menutype, $menu_class, $sep5, $logout_type, $database, $sep);
						echo '<div style="clear: both"></div>';
						}
						/*Greeting*/
						if ( $greeting ) echo '<font id="greeting" >'._HI.$name.'</font>';
						
						if ($showmen && $mplace==0) menuoutput($menutype, $menu_class, $sep5, $logout_type, $database, $sep);
		
					if (!$logout_type or !$showmen)
					{
					if (!$showmen) echo $sep;
					?>
					<input type="submit" class="button" id="jlogout" value="<?php echo _BUTTON_LOGOUT; ?>" />
					<?php
					}
					if ($showmen && $mplace==1) menuoutput($menutype, $menu_class, $sep5, $logout_type, $database, $sep);
				
			?>
		<input type="hidden" name="option" value="logout" />
		<input type="hidden" name="op2" value="logout" />
		<input type="hidden" name="lang" value="<?php echo $mosConfig_lang; ?>" />
		<input type="hidden" name="return" value="<?php echo sefRelToAbs( $logout ); ?>" />
		<input type="hidden" name="message" value="<?php echo $message_logout; ?>" />
	</form>
	<?php

	} 
	else {
// Login output
// ie HTML when not logged in and trying to login
	// used for spoof hardening
	$validate = josSpoofValue(1);
	?>

		<form action="<?php echo sefRelToAbs( 'index.php' ); ?>" method="post" name="login" id="mod_juser_login">
				<?php
				echo $pretext;
				?>
			<div id="mod_juser_sec1">
					
					<label for="mod_juser_un">
					<?php echo _USERNAME; ?>
					</label>		
					<?php echo $sep2;?>		
					<input name="username" id="mod_juser_un" type="text" class="inputbox" alt="username"/>
					<?php if ($mplace != 1) {?>
			</div> 
			
			<div id="mod_juser_sec2">
					<?php }?>							
					<label for="mod_juser_pw">
					<?php echo _PASSWORD; ?>
					</label>		
					<?php echo $sep2;?>				
					<input name="passwd" id="mod_juser_pw" type="password"  class="inputbox" alt="password" />
			</div>		
					<?php
					?>
			<div id="mod_jlogin_button">												
					<input  type="submit" name="Submit" class="button" id="jlogin" value="<?php echo _BUTTON_LOGIN;?>"/>
			</div>
					<?php
					if ($remme && $mplace!=1) 
					{
					?>
			<div id="jl_remember_2">
					<input type="checkbox" name="remember" id="remember" class="inputbox" value="yes" alt="Remember Me" />
					<label for="remember">
					<?php echo _REMEMBER_ME;?>
					</label>
			</div>
					<?php 
					}
					if ($lostpas) 
					{
					if ($mplace != 0) echo '<br/>';
					?>
			<div id="jl_lost_password">
						<a class="jl_notice" href="<?php echo sefRelToAbs( 'index.php?option=com_registration&amp;task=lostPassword' ); ?>">
						<?php echo _LOST_PASSWORD; 
					 ?></a>
			</div>
					<?php
							}				
					if ( $registration_enabled and $regist) {?>
			<div id="jl_no_account">
							<?php
							echo ' '.$sep5.' ';
							if ($mplace != 2) {
							echo _NO_ACCOUNT;} 
							?>
					<a class="jl_notice" href="<?php echo sefRelToAbs( $regurl ); ?>">
					<?php echo _CREATE_ACCOUNT; 
					?> </a> 
			</div>
					<?php } 
					if ($remme and $mplace == 1) 
					{
					echo ' '.$sep5.' ';
					?>
			<div id="jl_remember_1">
					<input type="checkbox" name="remember" id="remember" class="inputbox" value="yes" alt="Remember Me" />
					<label for="remember">
					<?php echo _REMEMBER_ME;?>
					</label>
			</div>
					<?php 
					}
					?>
	

		<?php
		echo $posttext;
		?>
		<input type="hidden" name="option" value="login" />
		<input type="hidden" name="op2" value="login" />
		<input type="hidden" name="lang" value="<?php echo $mosConfig_lang; ?>" />
		<input type="hidden" name="return" value="<?php echo sefRelToAbs( $login ); ?>" />
		<input type="hidden" name="message" value="<?php echo $message_login; ?>" />
		<input type="hidden" name="force_session" value="1" />
		<input type="hidden" name="<?php echo $validate; ?>" value="1" />
		</form>
		<?php
	}
	?>