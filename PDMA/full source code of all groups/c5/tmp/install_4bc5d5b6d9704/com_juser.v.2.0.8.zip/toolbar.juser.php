<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/

// ������ ������� �������
defined( '_VALID_MOS' ) or die( 'access denied' );

require_once( $mainframe->getPath( 'toolbar_html' ) );
if(!class_exists('JEConfig'))
require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/components/com_juser/joomlaequipment.config.php' );

switch ( $task ) {
  case 'integration_editor':
		TOOLBAR_JUser::integrationEditor();
		break;
	case 'integration_manager':
		TOOLBAR_JUser::integrationManager();
		break;
	case 'buy_juser_pro':
		break;
	case 'check_email':
		TOOLBAR_JUser::CheckEmail();
		break;
	case 'send_newsletter':
		TOOLBAR_JUser::send_newsLetter();
		break;
	case 'newsletter':
		TOOLBAR_JUser::newsLetter();
		break;
	case 'exportUser':
		TOOLBAR_JUser::EXPORT_USER();
		break;
	case 'export_execute':
		TOOLBAR_JUser::EXPORT_EXECUTE();
		break;
	case 'report_execute':
		TOOLBAR_JUser::report_execute();
		break;
	case 'report_for_print':
		TOOLBAR_JUser::ReportForPrint();
		break;
	case 'config':
	case 'applycnf':
		JEConfig::Toolbar();
		break;
	case 'new':
	case 'edit':
	case 'editA':
		TOOLBAR_JUser::_EDIT();
		break;
	case 'new_field':
		TOOLBAR_JUser::_NEW_FIELD();
		break;
	case 'editfield':
		TOOLBAR_JUser::_EDIT_FIELD();
		break;
	case 'extend_fields':
		TOOLBAR_JUser::_FIELDS();
		break;
	case 'report':
		TOOLBAR_JUser::_REPORT();
		break;
	default:
		TOOLBAR_JUser::_DEFAULT();
		break;
}
?>