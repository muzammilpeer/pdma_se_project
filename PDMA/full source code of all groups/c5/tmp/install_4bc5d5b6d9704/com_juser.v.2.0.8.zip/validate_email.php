<?php 
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined( '_VALID_MOS' ) or die( 'access denied' );

	if(!function_exists('checkdnsrr')) 
	{
		function checkdnsrr($hostName, $recType = '')
		{
			if(!empty($hostName)) {
				if( $recType == '' ) $recType = "MX";
				exec("nslookup -type=$recType $hostName", $result);
				foreach ($result as $line) {
					if(eregi("^$hostName",$line)) {
						return true;
					}
				}
				return false;
			}
			return false;
		}
	}
	if (!function_exists ('getmxrr') ) {
		function getmxrr($hostname, &$mxhosts, &$mxweight) {
			if (!is_array ($mxhosts) ) {
				$mxhosts = array ();
			}
			if (!empty ($hostname) ) {
				$output = "";
				@exec ("nslookup.exe -type=MX $hostname.", $output);
				$imx=-1;

				foreach ($output as $line) {
					$parts = "";
					if (preg_match ("/^$hostname\tMX preference = ([0-9]+), mail exchanger = (.*)$/", $line, $parts) ) {
						$imx++;
						$mxweight[$imx] = $parts[1];
						$mxhosts[$imx] = $parts[2];
					}
				}
				return ($imx!=-1);
			}
			return false;
		}
	}
	function SnowCheckMail($Email,$Debug=false) 
	{
		global $HTTP_HOST; 
		$Return =array();

		if (!eregi("^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,3})$", $Email)) { 
			$Return[0]=false; 
			$Return[1]="${Email} is E-Mail form that is not right."; 
			if ($Debug) echo "Error : {$Email} is E-Mail form that is not right.<br>";		 
			return $Return; 
		} 
		else if ($Debug) echo "Confirmation : {$Email} is E-Mail form that is not right.<br>"; 

		list ( $Username, $Domain ) = split ("@",$Email); 

		if ( checkdnsrr ( $Domain, "MX" ) )  { 
			if($Debug) echo "Confirmation : MX record about {$Domain} exists.<br>"; 
			if ( @getmxrr ($Domain, $MXHost))  {
				if($Debug) { 
					echo "Confirmation : Is confirming address by MX LOOKUP.<br>"; 
					for ( $i = 0,$j = 1; $i < count ( $MXHost ); $i++,$j++ ) { 
						echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Result($j) - $MXHost[$i]<BR>";  
					} 
				} 
			}
			else {return false;} 
		} 
		else { 
			return false;
			if ($Debug) echo "Confirmation : MX record about {$Domain} does not exist.<br>"; 
		} 

		$Return[0]=true; 
		$Return[1]="{$Email} is E-Mail address that there is no any problem."; 
		return $Return; 
	}
?>