<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined( '_VALID_MOS' ) or die( 'access denied' );

	$client="JUser";

	require ($mosConfig_absolute_path.'/administrator/components/com_juser/xajax/xajax_core/xajax.inc.php');
	$xajax = new xajax('index3.php?option=com_juser&no_html=1');
	include ($mosConfig_absolute_path .'/administrator/components/com_jcs/jcs.functions.php');
		
	function show_table($id,$uid)
	{
    global $mosConfig_live_site;
		$objResponse = new xajaxResponse();
		ob_start();
		print'<div style="border:1px solid #aaaaaa;"><div align="left" style="background-color:#ffffff;padding:2px;"><img onclick="Effect.Shrink(\''.$id.'\');; return false;" style="cursor:pointer;" src="'.$mosConfig_live_site.'/administrator/images/publish_x.png"></div>';
		jcsManage($uid);
		print'</div>';
		$text = ob_get_contents();
		ob_end_clean();	
    //$objResponse->alert($text);
		$objResponse->assign($id,"innerHTML",$text);
		$objResponse->script("Effect.Grow('".$id."');");
		return $objResponse;
	}
	function jcsPublishX($id,$i)
	{	
		global $database, $mosConfig_live_site;
		
		$query = "select `published` from `#__jcs_user_subscr` WHERE `id` =". $id;
		$database->setQuery( $query );
		$value = $database->loadResult();
		$value=1-$value;
		
		$objResponse = new xajaxResponse();
		
		$query = "UPDATE `#__jcs_user_subscr` SET `published` = ".intval($value)." WHERE `id` =". $id;
		$database->setQuery( $query );
		$database->query();
		$img=intval($value)==1?'/administrator/images/tick.png':'/administrator/images/publish_x.png';
		$objResponse->assign('publish_img_'.$i,"src",$img);
		return $objResponse;
	}
	$xajax->registerFunction("jcsPublishX");
	$xajax->registerFunction("show_table");
	$xajax->processRequest();
	$xajax->printJavascript($mosConfig_live_site.'/administrator/components/com_juser/xajax/');
?>