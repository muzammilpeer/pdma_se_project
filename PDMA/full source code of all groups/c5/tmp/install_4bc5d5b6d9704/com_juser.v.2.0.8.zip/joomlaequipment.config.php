<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
//error_reporting(0);
defined( '_VALID_MOS' ) or die( 'Restricted access' );
define('JDS', "/");
class JEConfig
{
    function set($val, $val2='', $o='')
    {
        global $database;
        if(!$option) $option = mosGetParam( $_REQUEST,'option', false);
        if(!$option || !$val) return false;
        $val = explode('.', $val);
        $section = $val[0];
        $value   = $val[1];

        $sql = "INSERT INTO #__je_config (
            `component`, `section`, `lable`, `name`,
            `type`, `values`, `selected`, `fieldset`) VALUES (
            '{$option}', '{$section}', '{$o[lable]}', '{$value}',
            '{$o[type]}', '{$o[values]}', '{$val2}', '{$o[fieldset]}'
            )";
        //echo $sql;
        $database->setQuery( $sql );
        $database->query();
        //echo $database->stderr(); exit;
        return;// $rows;
    }

    /**
     * Enter description here...
     *
     * @param text $val enter this and that
     * @param text $option component djfhskdjf
     * @return string
     */
    function get($val, $option='')
    {
        global $database;
        if(!$option) $option = mosGetParam( $_REQUEST,'option', false);
        if(!$option || !$val) return false;
        $val = explode('.', $val);
        $section = $val[0];
        $value   = $val[1];
        $sql = "SELECT `selected` FROM #__je_config WHERE `section` = '{$section}' AND name = '{$value}'";
        $database->setQuery( $sql );
        $rows = $database->loadResult();
        return $rows;
    }

    function renderForm($form = false)
    {
        global $database;
        mosCommonHTML::loadOverlib();

        if($form) echo '<form action="index2.php" method="post" id="adminForm" name="adminForm" enctype="">';
        echo '<table cellpadding="1" cellspacing="1" border="0" width="100%"><tr><td width="250"><table class="adminheading"><tr><th nowrap class="config">JUser Configuration</th></tr></table>';
        $option = mosGetParam( $_REQUEST,'option', false);
        if(!$option) josRedirect( 'index2.php', JText::_('Cannot get Component name in JEConfig') );

        $sql = "SELECT * FROM #__je_config WHERE component = '{$option}' AND hidden = 'N'  ORDER BY `section` ASC, fieldset ASC, type  ASC ";
        $database->setQuery( $sql );
        $rows = $database->loadObjectList();
        $com = '';

        $tabs = new mosTabs(1);
        $tabs->startPane('config');



/*
        foreach($rows AS $k => $row)
        {
            if($com != $row->section)
            {
              if($com != '')
              {
                  echo '</table>';
                  $tabs->endTab();

              }
              $tabs->startTab(ucfirst($row->section), 'tab-'.$row->section);
              echo '<table class="adminform">';
            }
            $com = $row->section;
            echo self::_renderRow($row);
        }
*/
        foreach($rows AS $k => $row)
        {
            if($set != $row->fieldset)
            {
                if($set != '')
                {
                    echo '</table></fieldset>';
                }
            }
            if($com != $row->section)
            {
                if($com != '')
                {
                    $tabs->endTab();
                }
                $tabs->startTab(ucfirst($row->section), 'tab-'.$row->section);
            }
            if($set != $row->fieldset)
            {
              //if($set != '')
              //{
              //   $tabs .= '</fieldset>';
              //}
              echo '<fieldset style="display:block; width:5%; float:left; clear:both"><LEGEND>'.ucfirst($row->fieldset).'</LEGEND><table width="20%" class="admintable">';
            }
            $com = $row->section;
            $set = $row->fieldset;
            //$tabs .= "<P>Get it</P>";
            echo JEConfig::_renderRow($row);
        }
        echo '</table></fieldset>';
        $tabs->endTab();
        $tabs->endPane();
        if($form)
        {
            echo '<input type="hidden" name="option" value="'.mosgetparam($_REQUEST, 'option').'" />';
            echo '<input type="hidden" name="task" value="" />';
            echo '<input type="hidden" name="hidemainmenu" value="0" />';
            echo '</form>';
        }
    }

    function _renderRow($row)
    {
        $label = $row->lable;
        if($row->description)
        {
            $label = sprintf(
                '<SPAN class="editlinktip"><SPAN onmouseover="return '.
                'overlib(\'%s\', BELOW, RIGHT, WIDTH, \'280\');" '.
                'onmouseout="return nd();" style="text-decoration: '.
                'none; color: #333;">%s</SPAN></SPAN>',$row->description ,$row->lable);
        }
        $out = sprintf('<tr valign="top"><td width="10%s" nowrap="nowrap">%s:</td><td width="10%s" nowrap="nowrap">%s</td></tr>', '%', $label, '%',  JEConfig::_renderElement($row));
        return $out;
    }

    function _renderElement($row)
    {
    	global $mainframe;
        switch ($row->type)
        {
            case "yesno":
                $out = mosHTML::yesnoRadioList($row->name.$row->id, 'class="inputbox"', $row->selected);
            break;

            case "selectlist":
                $items = explode(",", $row->values);
                foreach($items AS $item)
                {
                    $list[] = mosHTML::makeOption(trim($item), trim($item));
                }
                $out = mosHTML::selectList($list, $row->name.$row->id, 'class="inputbox" size="'.count($items).'" ', 'value', 'text', $row->selected);
            break;

            case "dropdown":
                $items = explode(",", $row->values);
                foreach($items AS $item)
                {
                    $list[] = mosHTML::makeOption(trim($item), trim($item));
                }
                $out = mosHTML::selectList($list, $row->name.$row->id, 'class="inputbox" size="1" ', 'value', 'text', $row->selected);
            break;

            case "textarea":
                $out = sprintf('<textarea class="text_area" name="%s" rows="5" cols="40">%s</textarea>', $row->name.$row->id, $row->selected);
            break;
            case "page":
            	$pages[] = mosHTML::makeOption('', " - Without registraton policy - ");
                global $database;
								$sql = "SELECT * FROM #__content WHERE 1 AND sectionid = 0 AND catid = 0";
								$database->setQuery($sql);
								$rows = $database->loadObjectList();
								foreach($rows AS $row2)
								{
								    $pages[] = mosHTML::makeOption($row2->id, $row2->title);
								}
                $out = mosHTML::selectList($pages, $row->name.$row->id, 'class="inputbox" size="7" ', 'value', 'text', $row->selected);
            break;

            case "directory":
              $home = $mainframe->getCfg('absolute_path');
              $dir = str_replace(array('/','\\','//','\\\\'), JDS, $row->values);
              $dir = $home.JDS.ereg_replace("^/", "", $dir);
              //echo $dir;
              if(!is_dir($dir.JDS)) return ('Value is not a directory');
              if(!is_readable($dir)) return ('Directory is not readable');
              $dirs[] = mosHTML::makeOption($dir, str_replace($home, '', $dir));
              //$skip = explode(', ', $row->params);
              $dirs2 = JEConfig::_getDirs($dir);
              if(is_array($dirs2)) $dirs = array_merge($dirs, $dirs2);
              $out = mosHTML::selectList($dirs, $row->name.$row->id, 'class="inputbox" size="1" ', 'value', 'text', $row->selected);
            break;

            case "sections":
            	$SectionList=JEConfig::getSectionList();
            	if(is_array($SectionList) && count($SectionList)>0){
            		foreach($SectionList AS $section) $sectionOption[] = mosHTML::makeOption($section->id, $section->title);
            	}
            	$selectedList = unserialize(stripslashes($row->selected));
            	if(is_array($selectedList) && count($selectedList)>0){
            		$i=0;
	            	foreach($selectedList as $selectedItem)
      					{
      						$selected[$i] = new stdClass();
      						$selected[$i]->value=$selectedItem;
      						$i++;
      					}
      				}
            	$out = mosHTML::selectList($sectionOption, $row->name.$row->id.'[]', ' class="inputbox" multiple ', 'value', 'text', $selected );
            break;
            case "categories_multiple":
            	$CategoryList=JEConfig::getContentCategoryList();
//              print_r($CategoryList);exit;
              $categoryOption[] = mosHTML::makeOption('', '');
            	if(is_array($CategoryList) && count($CategoryList)>0){
            		foreach($CategoryList AS $category) $categoryOption[] = mosHTML::makeOption($category->id, $category->title);
            	}
            	$selectedList = unserialize(stripslashes($row->selected));
            	if(is_array($selectedList) && count($selectedList)>0){
            		$i=0;
	            	foreach($selectedList as $selectedItem)
      					{
      						$selected[$i] = new stdClass();
      						$selected[$i]->value=$selectedItem;
      						$i++;
      					}
      				}
            	$out = mosHTML::selectList($categoryOption, $row->name.$row->id.'[]', ' class="inputbox" multiple ', 'value', 'text', $selected );
            break;

            case "static_content":
            	$content_list=JEConfig::getStaticContentList();
            	if(is_array($content_list) && count($content_list)>0){
                $contentOption[] = mosHTML::makeOption('', '');
            		foreach($content_list AS $content) $contentOption[] = mosHTML::makeOption($content->id, $content->title);
            	}
            	$out = mosHTML::selectList($contentOption, $row->name.$row->id, ' class="inputbox" ', 'value', 'text',  $row->selected );
            break;

            default:
                $out = sprintf('<input type="text" class="inputbox" name="%s" value="%s" size="40">', $row->name.$row->id, htmlspecialchars( $row->selected ));
            break;
        }
        return $out;
    }
      function getContentCategoryList()
      {
      	global $database;
      	$query = "SELECT CONCAT( '(', #__sections.title ,') ', #__categories.title ) as `title`, #__categories.id"
             ."\n FROM `#__categories`,`#__sections`"
             ."\n WHERE #__categories.section = #__sections.id AND #__sections.scope = 'content'"
             ."\n ORDER BY #__sections.ordering, #__categories.ordering";
      	$database->setQuery( $query );
      	$categories = $database->loadObjectList();
      	return $categories;
      }
      function getSectionList()
      {
      	global $database;
      	$query = "SELECT `title`, `id` FROM `#__sections`";
      	$database->setQuery( $query );
      	$sections = $database->loadObjectList();
      	return $sections;
      }
      function getStaticContentList()
      {
      	global $database;
      	$query = "SELECT `title`, `id` FROM `#__content` WHERE `sectionid` = 0";
      	$database->setQuery( $query );
      	$static_content = $database->loadObjectList();
      	return $static_content;
      }
      function _getDirs($dir)
		{
        global $mainframe;
        $home = $mainframe->getCfg('absolute_path');
        $point = opendir($dir);
        if(!$point) return ('Cannot Open Directory');
        $dir = ereg_replace("/$", "", $dir);
        while (($file = readdir($point)) !== false) {
            if($file == '.' || $file == '..' || !is_dir($dir.JDS.$file)) continue;
            $dirs[] = mosHTML::makeOption($dir.JDS.$file, str_replace($home, '', $dir.JDS.$file));
            $add = JEConfig::_getDirs($dir.JDS.$file);
            if(is_array($add)) $dirs = array_merge($dirs, $add);
        }
        closedir($point);
        return $dirs;

		}
    function Toolbar()
    {
        mosMenuBar::startTable();
    		//mosMenuBar::title( JText::_( 'JPromoter [Edit Page]'), '../components/com_jpromoter/images/logo.png' );
    		//mosMenuBar::spacer();
        //mosMenuBar::custom('panel', '../components/com_jpromoter/images/cpanel.png', NULL, JText::_('cPanel'), false, false );
    		//mosMenuBar::spacer();
    		//mosMenuBar::divider();
    		mosMenuBar::spacer();

        mosMenuBar::save('savecnf');
    		mosMenuBar::spacer();

        mosMenuBar::apply('applycnf');
    		mosMenuBar::spacer();

        mosMenuBar::cancel();
    		mosMenuBar::spacer();


    		//mosMenuBar::help('index.html', 'com_jpromoter');
    		mosMenuBar::endTable();
    }

    function save($task, $option = '')
    {
        global $database;

        if(!$option) $option = mosGetParam( $_REQUEST,'option', false);
        if(!$option)
        {
            echo "Cannot save. No Option";
            return;
        }
        $sql = "SELECT * FROM #__je_config WHERE `component` = '{$option}' AND hidden = 'N'";
        //echo $sql;
        $database->setQuery( $sql );
        $rows = $database->loadObjectList();
        foreach($rows AS $row)
        {
        	if($row->type == 'sections' || $row->type == 'categories_multiple')
        	{
        		$val=serialize(mosGetParam( $_REQUEST, $row->name.$row->id, array(), '' ));
        	}
        	else
        	{
	            $val = addslashes(mosGetParam( $_REQUEST, $row->name.$row->id));
	        }
            $sql = "UPDATE #__je_config SET selected = '$val' WHERE `id` = '{$row->id}'";
            $database->setQuery( $sql );
            $database->query();
        }

        if(mosGetParam( $_REQUEST,'task') == 'savecnf')
        {
            $link = "index2.php?option=".mosgetparam($_REQUEST, 'option');
        }
        else
        {
            $link = "index2.php?option=".mosgetparam($_REQUEST, 'option')."&task=config";
        }
        mosRedirect($link, "Configuration have been saved!");
    }
}

?>