<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

class HTML_JUser {
  function  show_user_profile($user, $ext_fields)
  {
    global $database,$mosConfig_absolute_path,$mosConfig_live_site, $my;
	
	$date_format = explode('-',JEConfig::get('general.date_format'));
	
     echo "<div class=\"componentheading\">$mosConfig_sitename profile for ".$user->username.(JEConfig::get('general.show_usertype_at_userlist') == 1 ? ' <small>('.$user->usertype.')</small>' : '')."</div>";
    if (isset($my) && $my->id != 0) $user_register = 1;
    else $user_register=0;
    print'<table width="100%" cellspacing="8"><tr><td width="1%">';
    if(JEConfig::get('general.enable_avatar') == 1 && JEConfig::get('general.show_avatar_at_userlist') == 1)
    {
      $query = "SELECT *"
         ."\n FROM #__juser_users_additional_data"
         ."\n WHERE `user_id` = ".$user->id;
      $database->setQuery( $query );
      $avatar_ = $database->loadObjectList();
      $path=stripslashes(JEConfig::get('general.uploaded_avatar_directory'));
      $path=str_replace('\\','/',$path);
      $path=str_replace($mosConfig_absolute_path,$mosConfig_live_site,$path);
      if(!$avatar_[0]->avatar){
       	 print '<img src="'.$mosConfig_live_site.'/administrator/components/com_juser/img/default_avatar.jpg" >';
      }
      else print '<img src="'.$path.'/user_'.$user->id.strtolower(strrchr($avatar_[0]->avatar,'.')).'" >';
    }
    print'</td><td>';
    print '<table cellspacing="8">';
    print JEConfig::get('general.show_name_at_userlist')==1 ? '<tr><td style="text-align:right"  valign="top" ><b>'.UM_UD_TABLE_FIELDS_NAME.'</b></td><td>'.$user->name.'</td></tr>' : '';
    print JEConfig::get('general.show_email_at_userlist')==1 ? '<tr><td style="text-align:right"  valign="top" ><b>'.UM_UD_TABLE_FIELDS_EMAIL.'</b></td><td>'.$user->email.'</td></tr>' : '';
    print JEConfig::get('general.show_reg_date_at_userlist')==1 ? '<tr><td style="text-align:right"  valign="top" ><b>'.UM_UD_TABLE_FIELDS_REGDATE.'</b></td><td class="createdate">'.$user->registerDate.'</td></tr>' : '';
    print JEConfig::get('general.show_last_visit_at_userlist')==1 ? '<tr><td style="text-align:right"  valign="top"><b>'.UM_UD_TABLE_FIELDS_LASTVISIT.'</b></td><td class="modifydate">'.$user->lastvisitDate.'</td></tr>' : '';
    print '</table>';
    print '</td></tr><tr><td colspan="2">';
    print '<table cellspacing="8">';
    if(count($ext_fields)>0 && is_array($ext_fields)){
	    foreach ($ext_fields as $field){
			  if($catid != $field->catid)
	      {?>
	         <tr>
	           <td colspan="2" >
	           <div class="contentheading"><?php print $field->catid==0 ? 'Other' : $field->cat_title;?></div>
						<div class="contentpaneopen"><?php print $field->cat_description;?></div>
						</td></tr><?php
			    $catid=$field->catid;
		    }
		    print '<tr><td style="text-align:right"  valign="top" ><b>'.$field->title.'<b></td><td>';
	      switch( $field->type )
	   		{
	   			case 'file':
						$path=stripslashes(JEConfig::get('general.uploaded_file_directory'));
						$path=str_replace('\\','/',$path);
						$path=str_replace($mosConfig_absolute_path,$mosConfig_live_site,$path);
						print $field->uvalue? '<a target="_blank" href="'.$path.$field->uvalue.'">'.$field->uvalue.'</a>' : '';
	   				break;
	   			case 'text':
	           print $field->uvalue;
	   				break;
	   			case 'select':
	           print $field->uvalue;
	   				break;
	   			case 'checkbox':
	           print str_replace("\n","<br>",str_replace("\r",'',$field->uvalue));
	   				break;
	   			case 'radio':
	           print $field->uvalue;
	   				break;
	   			case 'textarea':
	           print nl2br($field->uvalue);
	   				break;
	   			case 'date':
	   			   $value=explode("-", $field->uvalue);
		             $date['DD'] = $value[0];
		             $date['MM'] = $value[1];
		             $date['YYYY'] = $value[2];
     				 print $date[$date_format[0]].' '.$date[$date_format[1]].' '.$date[$date_format[2]].' ';
	   				break;
          case 'phone':
             $phone = unserialize(stripslashes($field->uvalue));
             print $phone[code].' '.$phone[prefix].' '.$phone[phone].' '.$phone[extention] ;
            break;
          case 'simple phone':
             $phone = unserialize(stripslashes($field->uvalue));
             print $phone[prefix].' '.$phone[phone];
            break;
	   		}
	      print '</td></tr>';
			}
	}
    print'</table>';
    print'</td></tr></table>';
  }
  function show_user_list($users, $lists, $pageNav)
  {
    global $database,$mosConfig_absolute_path,$mosConfig_live_site, $my, $mosConfig_sitename;
	
	$date_format = explode('-',JEConfig::get('general.date_format'));
	
    $link = 'index.php?option=com_juser&amp;task=user_list&amp';
    print '<div class="componentheading">'.$mosConfig_sitename.' User List</div>';
    print'<form action="index.php" method="post" name="mosUserForm" id="mosUserForm">';
    if (JEConfig::get('general.filters_show_search')){
      ?>
      <div style="text-align:right">
      <b><?php print FILTERS_SEARCH;?>:</b>
  		<input type="text" name="search" value="<?php echo htmlspecialchars( mosGetParam($_REQUEST,'search','') );?>" class="inputbox" onChange="document.mosUserForm.submit();" />
  		<?php
    }
    if (JEConfig::get('general.filters_show_corefilters')){
  		echo '<b>'.FILTERS_COREFILTERS.':</b>';
  		echo $lists['type'];
  		echo $lists['logged'];
  		echo'</div>';
    }
    if (JEConfig::get('general.filters_show_additionalfilters')){
  		echo '<hr>';
  		echo '<div style="text-align:right"><b>'.FILTERS_ADDITIONALFILTERS.':</b>';
  		if(count($lists['additional_filters'])>0){
  		  foreach($lists['additional_filters'] as $filter){
          print $filter;
  		  }
  		}
    }
		print'</div>';
    print'  <input type="hidden" name="task" value="user_list">';
    print'  <input type="hidden" name="option" value="com_juser">';
    print'  <input type="hidden" name="limit" value="'.mosGetParam($_REQUEST,'limit',5).'">';
    print'  <input type="hidden" name="limitstart" value="'.mosGetParam($_REQUEST,'limitstart',0).'">';
    print'</form>';
    if (isset($my) && $my->id != 0) $user_register = 1;
    else $user_register=0;
    if(count($users)>0){
       foreach($users as $user)
       {
         $username = '<a href="index.php?option=com_juser&task=show_profile&id='.$user->id.'">'.$user->username.(JEConfig::get('general.show_usertype_at_userlist') == 1 ? ' <small>('.$user->groupname.')</small>' : '').'</a>';
         $userData = '<table cellspacing="8">';
         $userData .= JEConfig::get('general.show_name_at_userlist')==1 ? '<tr><td style="text-align:right"  valign="top" >'.UM_UD_TABLE_FIELDS_NAME.'</td><td>'.$user->name.'</td></tr>' : '';
         $userData .= JEConfig::get('general.show_email_at_userlist')==1 ? '<tr><td style="text-align:right"  valign="top" >'.UM_UD_TABLE_FIELDS_EMAIL.'</td><td>'.$user->email.'</td></tr>' : '';
         $userData .= JEConfig::get('general.show_reg_date_at_userlist')==1 ? '<tr><td style="text-align:right"  valign="top" >'.UM_UD_TABLE_FIELDS_REGDATE.'</td><td class="createdate">'.$user->registerDate.'</td></tr>' : '';
         $userData .= JEConfig::get('general.show_last_visit_at_userlist')==1 ? '<tr><td style="text-align:right"  valign="top">'.UM_UD_TABLE_FIELDS_LASTVISIT.'</td><td class="modifydate">'.$user->lastvisitDate.'</td></tr>' : '';
         $query = "SELECT fl. * , ud.field_id, ud.user_id,ud.uvalue,ud.ctime, fl.id as field_id, #__categories.title as cat_title"
         		. "\n FROM #__extending_field_list as `fl`"
         		. "\n LEFT JOIN #__users_extended_data as `ud` ON fl.id = ud.field_id"
         		. "\n AND ud.user_id = " . (int) $user->id
         		. "\n LEFT JOIN #__categories ON #__categories.id = fl.catid"
            . "\n WHERE fl.`published` = 1 AND  fl.`display_at_users_list` = 1 AND fl.`access` <= ".$user_register
         		. "\n ORDER by fl.catid ASC, fl.ordering ASC";
         $database->setQuery( $query );
         $ext_fields = $database->loadObjectList();
         if(count($ext_fields)>0 && is_array($ext_fields)){
          foreach($ext_fields as $field)
          {
            $userData .= '<tr><td style="text-align:right"  valign="top" >'.$field->title.'</td><td>';
            switch( $field->type )
         		{
         			case 'file':
      					$path=stripslashes(JEConfig::get('general.uploaded_file_directory'));
      					$path=str_replace('\\','/',$path);
      					$path=str_replace($mosConfig_absolute_path,$mosConfig_live_site,$path);
      					$userData.= $field->uvalue? '<a target="_blank" href="'.$path.$field->uvalue.'">'.$field->uvalue.'</a>' : '';
         				break;
         			case 'text':
                 $userData .= $field->uvalue;
         				break;
         			case 'select':
                 $userData .= $field->uvalue;
         				break;
         			case 'checkbox':
                 $userData .= str_replace("\n","<br>",str_replace("\r",'',$field->uvalue));
         				break;
         			case 'radio':
                 $userData .= $field->uvalue;
         				break;
         			case 'textarea':
                 $userData .= nl2br($field->uvalue);
         				break;
         			case 'date':
         			   $value=explode("-", $field->uvalue);
                 $date['DD'] = $value[0];
                 $date['MM'] = $value[1];
                 $date['YYYY'] = $value[2];
         				 $userData .= $date[$date_format[0]].' '.$date[$date_format[1]].' '.$date[$date_format[2]].' ';
         				break;
              case 'phone':
                $phone = unserialize(stripslashes($field->uvalue));
                $userData.=$phone[code].' '.$phone[prefix].' '.$phone[phone].' '.$phone[extention];
               break;
              case 'simple phone':
                $phone = unserialize(stripslashes($field->uvalue));
                $userData.=$phone[prefix].' '.$phone[phone];
               break;
         		}
          $userData .= '</td></tr>';
          }
         }
         $userData .= '</table>';
         if(JEConfig::get('general.enable_avatar') == 1 && JEConfig::get('general.show_avatar_at_userlist') == 1)
         {
            $query = "SELECT *"
               ."\n FROM #__juser_users_additional_data"
               ."\n WHERE `user_id` = ".$user->id;
            $database->setQuery( $query );
            $avatar_ = $database->loadObjectList();
            $path=stripslashes(JEConfig::get('general.uploaded_avatar_directory'));
            $path=str_replace('\\','/',$path);
            $path=str_replace($mosConfig_absolute_path,$mosConfig_live_site,$path);
            if(!$avatar_[0]->avatar){
           	 $avatar   = '<img src="'.$mosConfig_live_site.'/administrator/components/com_juser/img/default_avatar.jpg" >';
            }
            else $avatar   = '<img src="'.$path.'/user_'.$user->id.strtolower(strrchr($avatar_[0]->avatar,'.')).'" >';
         }
         include($mosConfig_absolute_path.'/components/com_juser/user_card.html');
       }
       print '<div style="clear:both" align="center">'.$pageNav->writePagesCounter();
       print ' Show:'.$pageNav->writeLimitBox( $link ). "Users on the page.";
       print'</div>';
       print'<div style="clear:both" align="center">';
				echo $pageNav->writePagesLinks( $link );
       print'</div>';
    }
  }
	function frontpage() { ?>
		<div class="componentheading"> <?php echo _WELCOME; ?> </div>
		<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td> <?php echo _WELCOME_DESC; ?>	</td>
		</tr>
		</table>
		<?php
	}

	function userEdit( $row, $option, &$params, $ext_row, $task,$msg='' ) {
		global $mosConfig_absolute_path, $mosConfig_frontend_userparams;
		$JavaScript='';
		//$validate = josSpoofValue();

		mosCommonHTML::loadOverlib();
		if($msg) print '<div align="center" style="color:#CC3300;font-weight:bolder;"><big>'.$msg.'</big></div>';
		?>
		<div class="componentheading">
			<?php echo ($task=='UserRegistration' || $task=='saveUserRegistration') ? REG_FORM_HEAD_TITLE_REGISTRATION : REG_FORM_HEAD_TITLE_USERDETAILS; ?>
		</div>
		<form action="index.php" method="post" name="mosUserForm" id="mosUserForm" enctype="multipart/form-data">
			<?php
			if( $task=='UserRegistration' || $task=='saveUserRegistration' )
			{
				echo '<div>'.REG_FORM_HEAD_NOTICE.'</div>';
			}
			else
			{
				echo '<div>'.REG_FORM_HEAD_NOTICE.'</div>';
			}
			echo REG_FORM_HEAD_ATTENTION;

			$mark_color=JEConfig::get('general.required_color');
			if(!$mark_color){$mark_color="#dd5500";}

			if(JEConfig::get('general.required_field')=='bold')
			{
				echo ' <font color="'.$mark_color.'"><b>bold</b></font>';
			}
			else if(JEConfig::get('general.required_field')=='underline')
			{
				echo ' <font color="'.$mark_color.'"><u>underline</u></font>';
			}
			else if(JEConfig::get('general.required_field')=='sign *')
			{
				echo ' '.REQUIRED_MARK_SIGN.' <font color="'.$mark_color.'">*</font>';
			}
			else if(JEConfig::get('general.required_field')=='border')
			{
				echo ' <span style="border-right:10px solid '.$mark_color.';border-bottom:1px solid '.$mark_color.'">border</span>';
			}?>
		<div class="contentheading">
			<?php echo REG_FORM_FIRST_GROUP; ?>
		</div>
		<table cellpadding="0" cellspacing="5" border="0" width="85%">
		<tr>
			<?php	$error = isset($row->nameerror) ? $row->nameerror : '';
				print JUser::create_standart_field('text',_YOUR_NAME,'name', $row->name, 40, '',$error, $JavaScript);?>
		</tr>
		<tr>
			<?php	$error = isset($row->emailerror) ? $row->emailerror : '';
				print JUser::create_standart_field('text',_EMAIL,'email', $row->email, 40, '',$error, $JavaScript);?>
		</tr>
		<tr>
			<?php	$error = isset($row->usernameerror) ? $row->usernameerror : '';
				print JUser::create_standart_field('text',_UNAME,'username', $row->username, 40, '',$error, $JavaScript);?>
		</tr>
    <tr>
			<?php	$error = isset($row->coreavatarerror) ? $row->coreavatarerror : '';
				print JUser::create_core_avatar_field('file',ALL_AVATAR_TITLE, $row->coreavatar, 40, $error, $JavaScript);?>
		</tr>
		<tr>
			<?php	$error = isset($row->passworderror) ? $row->passworderror : '';
				print JUser::create_standart_field('password',_PASS,'password', '', 40, '',$error, $JavaScript);?>
		</tr>
		<tr>
			<?php	$error = isset($row->verifyPasserror) ? $row->verifyPasserror : '';
				print JUser::create_standart_field('password',_VPASS,'verifyPass', '', 40, '',$error, $JavaScript);?>
		</tr>
		<?php
		$catid='';
		$num=0;
    $is_siteUserEdit=(mosGetParam($_REQUEST, 'task')=='UserDetails' || mosGetParam($_REQUEST, 'task')=='saveUserEdit');
		foreach ($ext_row as $field){
			if( $field->published==1 && (( !$is_siteUserEdit && $field->show_at_reg==1) || ( $is_siteUserEdit && $field->show_at_edit==1)) )
      {
				if($catid != $field->catid)
        {?>
            <tr>
              <td colspan="2" >
              <div class="contentheading"><?php print $field->catid==0 ? 'Other' : $field->cat_title;?></div>
  						<div class="contentpaneopen"><?php print $field->cat_description;?></div>
  						</td>
            </tr><?php
					$catid=$field->catid;
				}
				?><tr><?php print JUser::create_field( $field , '', $JavaScript );?></tr><?php
			}
		}
		?></table><?php


    if( $task=='UserRegistration' || $task=='saveUserRegistration' )
		{
		  if(JEConfig::get('general.captcha_on')){
  			print '<br><table><tr>';
        $captcha_text = RandString(JEConfig::get('general.count_chars_captcha'),JEConfig::get('general.captcha_character_set'));
        print '<td valign="center" style="padding:3px">'.REG_FORM_ENTERCAPTCHA.'</td>';
        print '<td style="padding:3px"><img src="index.php?option=com_juser&task=captcha&tapochka='.base64_encode($captcha_text).'"></td>';
        print '<td valign="center" style="padding:3px"><input type="hidden" name="hidden_captcha" value="'.base64_encode($captcha_text).'">';
        print '<input type="text" name="captcha_validate"></td>';
        print '</tr></table><br>';
      }
		}
		if( JEConfig::get('general.registraton_policy') && ($task=='UserRegistration' || $task=='saveUserRegistration'))
		{
			print '<br>'.HTML_JUser::policy().'<br>';
		}
		if( $task=='UserRegistration' || $task=='saveUserRegistration' )
		{
      ?>
			<input class="button" type="button" onclick="submitbutton();" value="<?php echo REG_FORM_SUBMIT_BUTTON_REGISTER; ?>"><?php
		}
		else
		{
			?><input class="button" type="button" onclick="submitbutton();" value="<?php echo REG_FORM_SUBMIT_BUTTON_UPDATE; ?>"><?php
		}
		?>
		<br><br>
		<input type="hidden" name="id" value="<?php echo $row->id;?>" />
		<input type="hidden" name="option" value="com_juser" />
		<input type="hidden" name="task" value="<?php print $task;?>" />
		<input type="hidden" name="previous_task" value="<?php print $task;?>" />
		<!--<input type="hidden" name="<?php echo $validate; ?>" value="1" />-->
		</form>
<script language="JavaScript">
    function formatFloat(id)
    {
       var cur =
       document.getElementById(id).value;
       reg = /[^\d\.]+/;
       cur = cur.replace(',', '.');
       cur = cur.replace('..', '.');
       cur = cur.replace(reg, '');
       document.getElementById(id).value = cur;
    }
    function formatInteger(id)
    {
       var cur =
       document.getElementById(id).value;
       reg = /[^\d]+/;
       cur = cur.replace(',', '.');
       cur = cur.replace('..', '.');
       cur = cur.replace(reg, '');
       document.getElementById(id).value = cur;
    }
    function submitbutton(){
        var err=false;
        <?php echo $JavaScript['validate_standart_fields']; ?>
        <?php echo $JavaScript['validate_extended_fields']; ?>
        if(document.getElementById('field_verifyPass').value != document.getElementById('field_password').value)
				{
            document.getElementById("error_verifyPass").innerHTML = '<?php echo HEAD_MSG_IF_PASSWORDS_ISNOT_SAME ;?>';
            err=true;
        }
        else
        {
            document.getElementById("error_verifyPass").innerHTML = '';
        }
        <?php
		if(JEConfig::get('general.registraton_policy') && ($task == 'UserRegistration' || $task == 'saveUserRegistration'))
		{
			print ' if(document.getElementById("tc_agree").checked !=true)
				{alert("'.HEAD_MSG_IF_DONT_AGREE.'");	return false;}';
		}
    ?>

    if(err)
    {
        alert("<?php echo HEAD_MSG_IF_FIELD_IS_EMPTY; ?>");
        return false;
    }
    document.getElementById("mosUserForm").submit();
}
</script>
<?php

	}

	function policy()
	{
		global $database;

		$query="SELECT `introtext` FROM #__content WHERE 1 AND `id`= ".JEConfig::get('general.registraton_policy');
		$database->setQuery( $query );
		$text = $database->loadResult();
		switch(JEConfig::get('general.registraton_policy_display_type'))
		{
			case 'Link':
				$result='<input type="checkbox" id="tc_agree" name="tc" value="agree"> '.REG_FORM_IAGREE.' <a href="index2.php?option=com_content&task=view&id='.JEConfig::get('general.registraton_policy').'" TARGET="_blank">TC</a>';
				break;
			case 'Text':
				$result = $text;
				$result.='<br><input type="checkbox" id="tc_agree" name="tc" value="agree"> '. REG_FORM_IAGREE;
				break;
			case 'ScrollText':
				$result = '<div style="width:95%;height:150px;overflow:auto;border:1px solid gray;padding-left:10px;padding-right:10px;">'.$text.'</div>';
				$result.='<input type="checkbox" id="tc_agree" name="tc" value="agree"> '. REG_FORM_IAGREE;
				break;

		}
		return $result;
	}

	function confirmation() {
		?>
		<div class="componentheading">
			<?php echo _SUBMIT_SUCCESS; ?>
		</div>

		<table>
		<tr>
			<td>
				<?php echo _SUBMIT_SUCCESS_DESC; ?>
			</td>
		</tr>
		</table>
		<?php
	}
}
?>
