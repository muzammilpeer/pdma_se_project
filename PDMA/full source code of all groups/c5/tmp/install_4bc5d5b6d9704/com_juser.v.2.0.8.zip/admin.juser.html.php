<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

function selectListAccess( $row, $additional='', $text_only=false ) {
   global $database;
   if($text_only){
      $query = "SELECT name"
         . "\n FROM #__groups"
         . "\n WHERE id = ".$row
         . "\n ORDER BY id"
         ;
      $database->setQuery( $query );
      $group = $database->loadResult();
      return $group;
   }
   else{
      $query = "SELECT id AS value, name AS text"
         . "\n FROM #__groups"
         . "\n ORDER BY id"
         ;
      $database->setQuery( $query );
      $groups = $database->loadObjectList();
      $access = mosHTML::selectList( $groups, 'access', 'class="inputbox" size="3" '.$additional.' ', 'value', 'text', intval( $row ) );
      return $access;
   }
}

class HTML_JUser {
   function field_suggestion_show($suggestion)
   {
     //print'<pre>';print_r($suggestion);print'</pre>';
     print '<table align="center"><tr><td><h2>'.INTEGRATION_MANUALY_FIELD_SUGGESTION.'</h2><br>
     '.INTEGRATION_MANUALY_FIELD_SUGGESTION_CRITICAL.'</td></tr>';
     print '<tr><td align="left">';
     print '<b>Field must have follow type:</b><font color="#993300">(required)</font><br>';
     print $suggestion['type'];
     print '</td></tr>';

     if(is_array($suggestion['values']) != NULL){
       print '<tr><td align="left">';
       print '<b>Field must have follow values:</b>'.($suggestion['values_block']?'<font color="#993300">(required)</font>':'').'<br>';
       print '<textarea cols="50" rows="10">'.implode("\n",$suggestion['values']).'</textarea>';
       print '</td></tr>';
     }
     if($suggestion['description'] != NULL){
       print '<tr><td align="left">';
       print '<b>Field must have follow description:</b>'.($suggestion['description_block']?'<font color="#993300">(required)</font>':'').'<br>';
       print '<textarea cols="50" rows="10">'.$suggestion['description'].'</textarea>';
       print '</td></tr>';
     }
     if($suggestion['required'] != NULL){
       print '<tr><td align="left">';
       print '<b>Field must have follow required:</b>'.($suggestion['required_block']?'<font color="#993300">(required)</font>':'').'<br>';
       print ($suggestion['required']?'Yes':'No');
       print '</td></tr>';
     }
     if($suggestion['published'] != NULL){
       print '<tr><td align="left">';
       print '<b>Field must have follow published:</b>'.($suggestion['published_block']?'<font color="#993300">(required)</font>':'').'<br>';
       print ($suggestion['published']?'Yes':'No');
       print '</td></tr>';
     }
     if($suggestion['show_at_reg'] != NULL){
       print '<tr><td align="left">';
       print '<b>Field must have follow Show at registration:</b>'.($suggestion['show_at_reg_block']?'<font color="#993300">(required)</font>':'').'<br>';
       print ($suggestion['show_at_reg']?'Yes':'No');
       print '</td></tr>';
     }
     if($suggestion['changeable'] != NULL){
       print '<tr><td align="left">';
       print '<b>Field must have follow changeable:</b>'.($suggestion['changeable_block']?'<font color="#993300">(required)</font>':'').'<br>';
       print ($suggestion['changeable'] ? 'Yes' : 'No');
       print '</td></tr>';
     }
     exit;
   }
   function integration_editor( $component, $categories, $integration_id )
   {
      global $mosConfig_absolute_path, $mosConfig_live_site, $database;

      $synchronize = require_integration($integration_id);
      //$synchronize = new comIntegration ( $component[0]->id );

      $fieldList = $synchronize->field_list;
      ?>
     <table align="left" valign="top" width="100%">
     <tr>
     	 <td width="150" align="left" valign="top" >
     	 <?php require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );?>
     	 </td>
       <td align="left" valign="top" style="padding-left:10px">

      		<table class="adminheading" >
      		<tr>
      			<th class="user">
      				<?php echo SECTION_HEAD_INTEGRATION_EDITOR; ?>
      			</th>
            <td nowrap="nowrap">
                 <!--<?php echo SECTION_HEAD_SHOWSYSTEMFIELD; ?>
                 <input type="checkbox" name="show_system_field" id="show_system_field_id" value="show" <?php print mosGetParam($_REQUEST, 'show_system_field', '') == 'show' ? 'checked':''; ?> onchange="showHide();">-->
            </td>
      		</tr>
      		</table>
      		<form action="index3.php" method="POST" name="showNewFieldForm" target="_blank">
            <input type="hidden" name="option" value="com_juser">
            <input type="hidden" name="task" value="field_suggestion_show">
            <input type="hidden" name="suggestion" value="" id="hidden_suggestion2">
          </form>
          <form action="index2.php" method="POST" name="newFieldForm">
            <input type="hidden" name="option" value="com_juser">
            <input type="hidden" name="task" value="new_field">
            <input type="hidden" name="suggestion" value="" id="hidden_suggestion">
          </form>
          <form action="index2.php" method="post" name="adminForm">
            <table class="adminlist">
            <tr>
              <th width="1%">#</th>
              <th width="28%"><?php print $component[0]->component ?></th>
              <th width="65%">JUser</th>
              <th width="3%">Integrate</th>
              <th width="3%">Ready</th>
            </tr>
            <?php
            $k=0;
            $i=1;
            foreach($fieldList as $field)
            {
               $database->setQuery("SELECT * FROM `#__juser_integration_comparisons` WHERE `ident` = '".$field['ident']."'");
               $database->LoadObject($saved_comparison);

               $display = $synchronize->types_properties[$field['type']]->system? 'style="display:none;"' : '';
               ?><tr class="row<?php print$k; ?>" <?php print $display; ?>>
                    <td><?php print $i;?></td>
                    <td width="10%">
                      <big><?php print $field['title']; ?></big>
                      <br>Type:<b><?php print $field['type']; ?></b>
                      <br>Description: <?php print $field['description']; ?>
                    </td>
                    <td width="10%">
                      <table width="100%">
                      <tr>
                        <td style="border:none" width="30%"><i>Comparisons fields</i></td>
                        <td style="border:none" width="30%"><i>Suggestion to create new field in JUser</i></td>
                        <td style="border:none" width="30%"><i>Default value from JUser</i></td>
                      </tr>
                      <tr>
                    <?php
                    $comparisons = $synchronize->types_properties[$field['type']]->comparisons;
                    if( count($comparisons)>0 && in_array('avatar',$comparisons))
                    {
                      print'<td style="border:none" colspan="2"><b>avatar</b><input type="hidden" value="avatar" name="static_juser_field'.$i.'"></td>';
                    }
                    else if(count($comparisons)>0 && !$synchronize->types_properties[$field['type']]->system){
                       print'<td style="border:none">';
                       $comparisonFields = $synchronize->getComparisonFields($comparisons);
                       if(count($comparisonFields)>0){
                          unset($options);
                          $options[] = mosHTML::makeOption( '', '' );
                          foreach($comparisonFields as $cField){
                            $options[] = mosHTML::makeOption( $cField->id, str_limit($cField->title,30).' ('.$cField->type.')' );
                          }
            					  	print mosHTML::selectList( $options, 'comparison'.$i, ' style="width:150px" ', 'value', 'text', $saved_comparison->juser_field_id);
                       }
                       else{
                          print'<font color="red">Not found comparisons fields in JUser</font>';
                       }
                       print'</td><td style="border:none">';
                       $suggestions = $synchronize->suggestions[$field['ident']];
                       foreach($suggestions as $suggestion){
                         print'<a href="JavaScript:document.getElementById(\'hidden_suggestion\').value=\''.htmlspecialchars(serialize($suggestion)).'\'; document.newFieldForm.submit();">'.$suggestion['type'].'</a> (<a href="JavaScript:document.getElementById(\'hidden_suggestion2\').value=\''.htmlspecialchars(serialize($suggestion)).'\';document.showNewFieldForm.submit();")>prompting for manually</a>)<br>';
//  newFieldForm
                       }
                       print'</td>';
                    }
                    else{
                       print'<td style="border:none" colspan="2" align="center"><font color="blue">This field can`t have any comparisons fields</font></td>';
                    }
                    if(!$synchronize->types_properties[$field['type']]->system && $synchronize->types_properties[$field['type']]->system){
                      print'<td style="border:none"><input type="text" size="40" value="'.
                        ($saved_comparison->default_value ?
                            $saved_comparison->default_value :
                            $def_value=$synchronize->types_properties[$field['type']]->default).'" name="default'.$i.'"></td>';
                    }
                    else{
                      print'<td style="border:none"></td>';
                    }
                    ?>
                      </tr>
                      </table>
                    </td>
                    <td>
                      <?php
                      print'<input type="hidden" name="name'.$i.'" value='.$field['name'].'>';
                      print'<input type="hidden" name="ident'.$i.'" value='.$field['ident'].'>';
                      print'<input type="hidden" name="is_system'.$i.'" value='.($synchronize->types_properties[$field['type']]->system*1).'>';
                      if($synchronize->types_properties[$field['type']]->system){
                        print'<input type="hidden" name="integrate'.$i.'" value="system"';
                      }
                      else if($field['required'] != '1'){
                        print'<input type="checkbox" name="integrate'.$i.'" value="integrate"  '.($saved_comparison->integrate? 'checked="checked"' : '').'>';
                      }
                      else{
                        print'<font color="#993300">required</font>';
                        print'<input type="hidden" name="integrate'.$i.'" value="required">';
                      }
                      ?>
                    </td>
                    <td>
                      <?php
                        if($saved_comparison->juser_field_id || $saved_comparison->static_juser_field || ($synchronize->types_properties[$field['type']]->system && count($saved_comparison)>0))
                        {
                          print'<img src="'.$mosConfig_live_site.'/images/tick.png'.'" alt="ready">';
                        }
                      ?>
                    </td>
                  </tr>
               <?php
               if(!$display) $k=1-$k;
               $i++;
            }
            ?>
            </table>
            <input type="hidden" name="id" value="<?php print mosGetParam($_REQUEST, 'id', ''); ?>" />
            <input type="hidden" name="option" value="com_juser" />
         		<input type="hidden" name="task" value="integration_editor" />
         		<input type="hidden" name="hidemainmenu" value="0" />
         </form>
         </td>
       </tr>
       </table><?php
  }
  function integration_manager($integrations)
  {
    global $mosConfig_absolute_path,$mosConfig_live_site;
    $error = mosGetParam($_REQUEST, 'install_error', '');
    if($error)
    {
      print'<div>Error: '.stripslashes($error).'</div>';
    }
    ?>
    <table align="left" valign="top" width="100%">
   	<tr>
   		<td width="150" align="left" valign="top" >
   		<?php require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );?>
   		</td>
   		<td align="left" valign="top" style="padding-left:10px">
      <form action="index2.php" method="post" name="adminForm_"  enctype="multipart/form-data">
        <table class="adminheading" >
      		<tr>
      		  <th class="install">
      			<?php echo SECTION_HEAD_INTEGRATION_MANAGER_INSTALL_NEW; ?>
      			</th>
      		</tr>
      		</table>
      		<table class="adminform">
      		<tr>
      			<th colspan="2">
      			<?php echo INTEGRATION_TABLE_HEAD; ?>
      			</th>
      		</tr>
          <tr>
            <td valign="top">
            <?php echo INTEGRATION_TABLE_FIELD_FILE; ?>
            </td>
            <td align="left">
            <input class="text_area" name="userfile" size="70" type="file">
       			<input class="button" value="Upload File &amp; Install" type="submit">
            </td>
          </tr>
    			</table>
      		<input type="hidden" name="option" value="com_juser" />
      		<input type="hidden" name="task" value="install_integration" />
      		<input type="hidden" name="hidemainmenu" value="0" />
      	</form>

       <table class="content" align="center">
       <tbody>
       <?php JUser::writableCell("administrator/components/com_juser/integration"); ?>
       <?php JUser::writableCell("media"); ?>
       </tbody>
       </table>
       <?php
       if(is_array($integrations) && count($integrations)>0){
       ?>
       <form action="index2.php" method="post" name="adminForm">
      		<table class="adminheading" >
      		<tr>
      			<th class="install">
      				<?php echo SECTION_HEAD_INTEGRATION_MANAGER_INSTALLED; ?>
      			</th>
      		</tr>
      		</table>
      		<table class="adminlist">
      		<tr>
      			<th width="1%" class="title">
      			#
      			</th>
      			<th width="1%" class="title">
      			<input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count($integrations); ?>);" />
      			</th>
            <th class="title">
      			<?php echo INTEGRATION_TABLE_FIELD_COMPONENT; ?>
      			</th>
            <th class="title">
      			<?php echo INTEGRATION_TABLE_FIELD_PUBLISHED; ?>
      			</th>
            <!--<th class="title">
      			<?php echo INTEGRATION_TABLE_FIELD_SATUSIMPORT; ?>
      			</th>-->
            <th class="title">
      			<?php echo INTEGRATION_TABLE_FIELD_SATUSEXPORT; ?>
      			</th>
            <th class="title" width="10%">
      			<?php echo INTEGRATION_TABLE_FIELD_INTEGRATIONDATE; ?>
      			</th>
      		</tr>
          <?php
          $k=0;
          foreach($integrations as $key => $integration ){
          $link = 'index2.php?option=com_juser&amp;task=integration_editor&amp;id='. $integration->id.'&amp;hidemainmenu=1';
          $img 	= $integration->published ? 'tick.png' : 'publish_x.png';
          $task_publish = $integration->published ? 'unpublishing_integration' : 'publishing_integration';
    			$imgImport 	= $integration->import_status ? 'tick.png' : 'publish_x.png';
          $imgExport 	= $integration->export_status ? 'tick.png' : 'publish_x.png';?>
          <tr class="row<?php print $k;?>">
            <td>
            <?php print ($key+1); ?>
            </td>
            <td>
            <?php print mosHTML::idBox( $key, $integration->id ); ?>
            </td>
            <td>
            <a href="<?php print $link; ?>">
              <?php print $integration->component;?>
            </a>
            </td>
            <td>
            <a href="javascript: void(0);" onClick="return listItemTask('cb<?php echo $key;?>','<?php echo $task_publish;?>')">
              <img src="images/<?php echo $img;?>" width="12" height="12" border="0" alt="<?php echo $alt; ?>" />
            </a>
            </td>
            <!--
            <td>
            <img src="<?php echo $mosConfig_live_site.'/images/'.$imgImport;?>" width="12" height="12" border="0" alt="<?php echo $alt; ?>" />
            </td>
            -->
            <td>
            <?php
               print'<img src="'.$mosConfig_live_site.'/images/'.$imgExport.'" width="12" height="12" border="0" alt="'.$alt.'" />';
            ?>
            </td>
            <td>
            <?php print $integration->integration_data;?>
            </td>
          </tr>
          <?php
          $k=1-$k;
          }
          ?>
    			</table>
          <?php }?>
      		<input type="hidden" name="option" value="com_juser" />
      		<input type="hidden" name="task" value="" />
      		<input type="hidden" name="hidemainmenu" value="0" />
    			<input type="hidden" name="boxchecked" value="0" />
        </form>
        </td>
   	</tr>
   	</table>

    <?php
  }
	function message_page()
	{
    global $mosConfig_absolute_path;
   	?>
   	<table align="left" valign="top" width="100%">
   	<tr>
   		<td width="150" align="left" valign="top" >
   		<?php require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );?>
   		</td>
   		<td align="left" valign="top" style="padding-left:10px">
   		<?php require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/buy_juser_pro.html" ); ?>
   		</td>
   	</tr>
   	</table><?php
	}
  function  newsletter_conditions($cid,$jcs_list,$extend_fields, $message)
  {
    global $mosConfig_absolute_path;
   	?>
      	<form action="index2.php" method="post" name="adminForm">
      		<table class="adminheading" >
      		<tr>
      			<th class="user">
      				<?php echo SECTION_HEAD_NEWSLETTER_CONDITIONS; ?>
      			</th>
      		</tr>
      		</table>
      		<table class="adminform">
      			<tr>
      				<th colspan="2">
      					<?php echo SECTION_HEAD_NEWSLETTER_CONDITIONS ?>
      				</th>
      			</tr>
      			<tr>
      			 <td width="130" valign="top"><?php echo NL_TABLE_FIELDS_HTMLORTEXT ?></td>
      			 <td><?php print NL_TABLE_TEXT; ?> <input type="radio" name="htmlortext" value="text" checked>
                 <?php print NL_TABLE_HTML; ?> <input type="radio" name="htmlortext" value="HTML"></td>
      			</tr>
      			<tr>
      			 <td width="130" valign="top"><?php echo NL_TABLE_FIELDS_SUBJECT ?></td>
      			 <td><input type="text" name="subject"></td>
      			</tr>
      			<tr>
      			 <td width="130" valign="top"><?php echo NL_TABLE_FIELDS_PRETEXT ?></td>
      			 <td><textarea cols="60" rows="4" name="pretext"></textarea></td>
      			</tr>
      			<tr>
      			 <td width="130" valign="top"></td>
      			 <td><div style="border: 1px solid gray; overflow: auto; width: 70%; height: 150px; padding-left: 10px; padding-right: 10px;"><?php print $message;?></div></td>
      			</tr>
      			<tr>
      			 <td width="130" valign="top"><?php echo NL_TABLE_FIELDS_POSTTEXT ?></td>
      			 <td><textarea cols="60" rows="4" name="posttext"></textarea></td>
      			</tr>
      			<?php if(is_dir($mosConfig_absolute_path."/administrator/components/com_jcs")){?>
      			<tr>
      				<td width="130" valign="top">
      					<?php echo NL_TABLE_FIELDS_JCSCONDITIONS; ?>
      				</td>
      				<td>
      					<?php
      						$options_jcs[] = mosHTML::makeOption( '', '' );
      						if(count($jcs_list)>0)
      						{
      							foreach($jcs_list as $jcs_item)
      							{
      								$options_jcs[] = mosHTML::makeOption( $jcs_item->id, $jcs_item->name );
      							}
      							print mosHTML::selectList( $options_jcs, 'condition_jcs[]', ' MULTIPLE ', 'value', 'text');
      						}
      						else
      						{
      							print NL_TABLE_FIELDS_NOTFOUNDJCS;
      						}
      					?>
      				</td>
      			</tr>
      			<?php }?>
      			<tr>
      				<td width="130" valign="top">
      					<?php echo NL_TABLE_FIELDS_CONDITIONS; ?>
      				</td>
      				<td>
      					<?php
      					foreach($extend_fields as $field)
      					{
      						$options[] = mosHTML::makeOption( $field->id, $field->title );
      					}

      					$options2[] = mosHTML::makeOption( 'like', NL_TABLE_FIELDS_MARK_LILE );
      					$options2[] = mosHTML::makeOption( '=', NL_TABLE_FIELDS_MARK_QUALSTHEN );
      					$options2[] = mosHTML::makeOption( '>', NL_TABLE_FIELDS_MARK_MORETHEN );
      					$options2[] = mosHTML::makeOption( '<', NL_TABLE_FIELDS_MARK_LESSTHEN );
      					$options2[] = mosHTML::makeOption( '>=', NL_TABLE_FIELDS_MARK_MOREOREQUALSTHEN );
      					$options2[] = mosHTML::makeOption( '<=', NL_TABLE_FIELDS_MARK_LESSOREQUALSTHEN );
      					$options2[] = mosHTML::makeOption( '<>', NL_TABLE_FIELDS_MARK_NOTQUALSTHEN );
      					?>
      					<?php print mosHTML::selectList( $options, 'condition_filed_1', '', 'value', 'text'); ?>
      					<?php print mosHTML::selectList( $options2, 'condition__sign_1', '', 'value', 'text'); ?>
      					<input type="text" name="condition__sign_param1" class="inputbox" size="55" value="" /><br>
      					<?php print mosHTML::selectList( $options, 'condition_filed_2', '', 'value', 'text'); ?>
      					<?php print mosHTML::selectList( $options2, 'condition__sign_2', '', 'value', 'text'); ?>
      					<input type="text" name="condition__sign_param2" class="inputbox" size="55" value="" /><br>
      					<?php print mosHTML::selectList( $options, 'condition_filed_3', '', 'value', 'text'); ?>
      					<?php print mosHTML::selectList( $options2, 'condition__sign_3', '', 'value', 'text'); ?>
      					<input type="text" name="condition__sign_param3" class="inputbox" size="55" value="" />
      				</td>
      			</tr>
      		</table>
          <input type="hidden" name="newsletters" value="<?php print htmlspecialchars(serialize($cid)); ?>" />
      		<input type="hidden" name="option" value="com_juser" />
      		<input type="hidden" name="task" value="" />
      		<input type="hidden" name="hidemainmenu" value="0" />
      	</form><?php
  }
	function CheckEMail( $users, $pageNav, $validate, $left )
	{
		global $mosConfig_absolute_path;
		?>
		<table align="left" valign="top" width="100%"><tr><td width="150" align="left" valign="top" >
		<?php require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );?>
		</td>
		<td align="left" valign="top" style="padding-left:10px">
		<form action="index2.php" method="post" name="adminForm">
			<table class="adminheading">
			<tr>
				<th class="user">
					<?php echo SECTION_MENU_NEWS_CHECKEMAIL; ?>
				</th>
			</tr>
			</table>
			<div align="center">
				<big><b>
				<?php printf(CE_CHECKEDANDLEFT, $validate, $left,'<input type="text" name="count_next" value="'.(mosGetParam($_REQUEST, 'count_next')? mosGetParam($_REQUEST, 'count_next') : '50').'" size="5">'); ?>
				</b></big>
			</div>
			<?php if(count($users) > 0){?>
			<table class="adminlist">
			<tr>
				<th width="1%" class="title">
				#
				</th>
				<th width="1%" class="title">
				<input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count($users); ?>);" />
				</th>
				<th class="title">
				<?php echo UM_TABLE_HEAD_NAME; ?>
				</th>
				<th width="15%" class="title" >
				<?php echo UM_TABLE_HEAD_USERNAME; ?>
				</th>
				<th width="5%" class="title">
				<?php echo UM_TABLE_HEAD_ENABLED; ?>
				</th>
				<th width="15%" class="title">
				<?php echo UM_TABLE_HEAD_GROUP; ?>
				</th>
				<th width="15%" class="title">
				<?php echo UM_TABLE_HEAD_EMAIL; ?>
				</th>
				<th width="10%" class="title">
				<?php echo UM_TABLE_HEAD_LASTVISIT; ?>
				</th>
				<th width="1%" class="title">
				<?php echo UM_TABLE_HEAD_ID; ?>
				</th>
			</tr>
			<?php $i=1; $k = 0;
			foreach($users as $row){
			$img 	= $row->block ? 'publish_x.png' : 'tick.png';
			$link 	= 'index2.php?option=com_juser&amp;task=editA&amp;id='. $row->uuser_id. '&amp;hidemainmenu=1';?>
			<tr class="<?php echo "row$k"; ?>">
				<td>
				<?php echo $i+$pageNav->limitstart;?>
				</td>
				<td>
				<?php echo mosHTML::idBox( $i-1, $row->uuser_id ); ?>
				</td>
				<td>
				<a href="<?php print $link; ?>">
				<?php echo $row->name; ?>
				</a>
				<td>
				<?php echo $row->username ; ?>
				</td>
				<td>
				<img src="images/<?php echo $img;?>" width="12" height="12" border="0" alt="<?php echo $alt; ?>" />
				</td>
				<td>
				<?php echo ($row->usertype ? $row->usertype : 'Registered'); ?>
				</td>
				<td>
				<a href="mailto:<?php echo $row->email; ?>">
				<?php echo $row->email; ?>
				</a>
				</td>
				<td nowrap="nowrap">
				<?php echo mosFormatDate( $row->lastvisitDate, _CURRENT_SERVER_TIME_FORMAT ); ?>
				</td>
				<td>
				<?php echo $row->uuser_id; ?>
				</td>
			</tr>
			<?php $k = 1 - $k;
			$i++;}?>
			</table>
			<div align="center">
			<?php echo $pageNav->getListFooter(); ?>
			</div>
			<?php } ?>
			<input type="hidden" name="option" value="com_juser" />
			<input type="hidden" name="task" value="check_email" />
			<input type="hidden" name="boxchecked" value="0" />
			<input type="hidden" name="hidemainmenu" value="0" />
		</form>
		</td></tr></table>
		<?php
	}

	function ShowNewsLetter( $NewsLeters, $pageNav )
	{
		global $mosConfig_absolute_path;
		?><table align="left" valign="top" width="100%"><tr><td width="150" align="left" valign="top" >
		<?php require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );?>
		</td><td align="left" valign="top" style="padding-left:10px">
			<form action="index2.php" method="post" name="adminForm">
				<table class="adminheading">
				<tr>
					<th class="user">
						<?php echo SECTION_MENU_NEWS_LETTER; ?>
					</th>
				</tr>
				<?php $k = 0;?>
				</table>
				<table class="adminlist">
				<tr>
					<th width="1%" class="title" >
					#
					</th>
					<th width="1%" class="title">
					<input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count($NewsLeters); ?>);" />
					</th>
					<th width="24%" class="title">
					<?php echo NL_SHOW_TABLE_FIELDS_TITLE; ?>
					</th>
          <th width="24%" class="title">
					<?php echo NL_SHOW_TABLE_FIELDS_SECTION; ?>
					</th>
          <th width="24%" class="title">
					<?php echo NL_SHOW_TABLE_FIELDS_CATEGORY; ?>
					</th>
					<!--<th width="30%" class="title">
					<?php echo NL_SHOW_TABLE_FIELDS_SUBJECT; ?>
					</th>
					<th width="30%" class="title">
					<?php echo NL_SHOW_TABLE_FIELDS_MESSAGE; ?>
					</th>-->
					<th width="2%" class="title">
					<?php echo NL_SHOW_TABLE_FIELDS_PUBLISHED; ?>
					</th>
					<!--<th width="5%" class="title">
					<?php echo NL_SHOW_TABLE_FIELDS_STATUS; ?>
					</th>-->
					<th width="10%" class="title">
					<?php echo NL_SHOW_TABLE_FIELDS_CD; ?>
					</th>
				</tr>
				<?php $i=1;
				if(is_array($NewsLeters) && count($NewsLeters)>0){
				foreach($NewsLeters as $newsletter){
				$link = 'index2.php?option=com_content&sectionid='.$newsletter->section_id.'&task=edit&hidemainmenu=1&id='.$newsletter->id; ?>
				<tr class=row"<?php echo "$k"; ?>">
					<td>
					<?php echo $i+$pageNav->limitstart;?>
					</td>
					<td>
					<?php echo mosHTML::idBox( $i-1, $newsletter->id ); ?>
					</td>
					<td>
					<a href="<?php print $link; ?>">
					<?php echo str_limit($newsletter->title,40); ?>
					</a>
					</td>
          <td>
          <a href="index2.php?option=com_content&sectionid=<?php echo $newsletter->section_id; ?>">
					<?php echo $newsletter->section_name; ?>
          </a>
					</td>
          <td>
          <a href="index2.php?option=com_categories&section=content&task=editA&hidemainmenu=1&id=<?php echo $newsletter->cat_id;?>">
					<?php echo $newsletter->cat_title; ?>
          </a>
					</td>
					<!--<td>
					<?php /* echo str_limit($newsletter->subject,40); */ ?>
					</td>
					<td>
					<?php /* echo htmlspecialchars(str_limit($newsletter->message,40)); */?>
					</td>-->
					<td>
					<?php print $newsletter->state == 0 ? '<a href="javascript: void(0);" onClick="return listItemTask(\'cb'.($i-1).'\',\'publishing_newsletter\')"><img src="images/publish_x.png" alt="published"' : '<a href="javascript: void(0);" onClick="return listItemTask(\'cb'.($i-1).'\',\'unpublishing_newsletter\')"><img src="images/publish_g.png" alt="unpublished"' ; ?> border="0" width="12" height="12"  /></a>
					</td>
					<?php /*
					<td>
					<img <?php print $newsletter->status == 0 ? 'src="images/publish_y.png" alt="Not sended"' : 'src="images/publish_g.png" alt="Sended"' ; ?>border="0" width="12" height="12"  />
					</td>
					*/?>
					<td>
					<?php echo $newsletter->created; ?>
					</td>
				</tr>
				<?php $k = 1 - $k;
				$i++;}}?>
				</table>
				<div align="center">
				<?php echo $pageNav->getListFooter(); ?>
				</div>
				<input type="hidden" name="option" value="com_juser" />
				<input type="hidden" name="task" value="newsletter" />
				<input type="hidden" name="boxchecked" value="0" />
				<input type="hidden" name="hidemainmenu" value="1" />
		</td></tr></table>
		<?php
	}

	function export_execute( $rows, $ext_fields, $pageNav)
	{
    global $mosConfig_live_site;
    $table='<table cellpadding="4" cellspacing="1" border="0" class="adminlist">';
		$table.='<tr>';
		$table.= '<th class="title" nowrap="nowrap">#</th>';
		$table.= mosgetparam($_POST,'show_field_name')=='show' ? '<th class="title" nowrap="nowrap">Name</th>' : '';
		$table.= mosgetparam($_POST,'show_field_username')=='show' ? '<th class="title" nowrap="nowrap">User Name</th>' : '';
		$table.= mosgetparam($_POST,'show_field_email')=='show' ? '<th class="title" nowrap="nowrap">Email</th>' : '';
		$table.= mosgetparam($_POST,'show_field_registerDate')=='show' ? '<th class="title" nowrap="nowrap">Register Date</th>' : '';
		$table.= mosgetparam($_POST,'show_field_block')=='show' ? '<th class="title" nowrap="nowrap">Active</th>' : '';

		foreach($ext_fields as $field)
		{
			$table.=mosgetparam($_POST,'show_field_'.$field->field_id)=='show' ? '<th class="title" nowrap="nowrap">'.$field->title.'</th>' : '';
		}
		$table.='</tr>';
		$i=0;
		$k=0;
		$table2=$table;

		foreach( $rows as $row )
		{

			$table.= $i>0 ? '</td></tr><tr class="row'.$k.'">' : '<tr class="row'.$k.'">';
			$table.= '<td>'.($i+$pageNav->limitstart+1).'</td>';
			$table.= mosgetparam($_POST,'show_field_name')=='show' ? '<td>'.str_limit($row['name'],50).'</td>' : '';
			$table.= mosgetparam($_POST,'show_field_username')=='show' ? '<td>'.str_limit($row['username'],50).'</td>' : '';
			$table.= mosgetparam($_POST,'show_field_email')=='show' ? '<td>'.str_limit($row['email'],50).'</td>' : '';
			$table.= mosgetparam($_POST,'show_field_registerDate')=='show' ? '<td>'.str_limit($row['registerDate'],50).'</td>' : '';
			$table.= mosgetparam($_POST,'show_field_block')=='show' ? '<td>'.str_limit($row['block'] == 1 ? 'No' : 'Yes' ,50).'</td>' : '';

			$table2.= $i>0 ? '</td></tr><tr class="row'.$k.'">' : '<tr class="row'.$k.'">';
			$table2.= '<td>'.($i+1).'</td>';
			$table2.= mosgetparam($_POST,'show_field_name')=='show' ? '<td>'.$row['name'].'</td>' : '';
			$table2.= mosgetparam($_POST,'show_field_username')=='show' ? '<td>'.$row['username'].'</td>' : '';
			$table2.= mosgetparam($_POST,'show_field_email')=='show' ? '<td>'.$row['email'].'</td>' : '';
			$table2.= mosgetparam($_POST,'show_field_registerDate')=='show' ? '<td>'.$row['registerDate'].'</td>' : '';
			$table2.= mosgetparam($_POST,'show_field_block')=='show' ? '<td>'.str_limit($row['block'] == 1 ? 'No' : 'Yes' ,50).'</td>' : '';
			foreach($ext_fields as $field)
			{
        $value=$row['field_'.$field->field_id];
        if($field->type=='phone')
        {
          $value=unserialize(stripslashes($value));
          $value=$value[code].' '.$value[prefix].' '.$value[phone].' '.$value[extention];
        }
        if($field->type=='simple phone')
        {
          $value=unserialize(stripslashes($value));
          $value=$value[prefix].' '.$value[phone];
        }
				$table.= mosgetparam($_POST,'show_field_'.$field->field_id)=='show' ? '<td>'.str_limit($value,50).'</td>' : '';
				$table2.= mosgetparam($_POST,'show_field_'.$field->field_id)=='show' ? '<td>'.$value.'</td>' : '';
			}
        	$i++;
        	$k=1-$k;
		}
		$table.='</td></tr></table>';
		$table2.='</td></tr></table>';
		print'
				<form name="file_export" method="POST" ACTION="index3.php" TARGET="_blank">
					<br><br><br><br>
					<div align="left">
						<a style="border:none" href="javascript: void(0);" onClick="document.getElementById(\'hidden_type\').value=\'xls\';document.file_export.submit();">
							Download table in XLS format: <img style="border:none" src="'.$mosConfig_live_site.'/administrator/components/com_juser/img/xls.png">
						</a> &nbsp;&nbsp;&nbsp;&nbsp;
						<a style="border:none" href="javascript: void(0);" onClick="document.getElementById(\'hidden_type\').value=\'csv\';document.file_export.submit();">
							Download table in CSV format: <img style="border:none" src="'.$mosConfig_live_site.'/administrator/components/com_juser/img/csv.png">
						</a>
					</div>';
					foreach($_POST as $post_key => $post_value){
               if ($post_key=='task' || $post_key=='option'|| $post_key=='serial_post') continue;
               print'<input type="hidden" name="'.$post_key.'" value="'.$post_value.'">';
          }
          print'
          <input type="hidden" value="1" name="no_html">
          <input type="hidden" value="export_file" name="task">
          <input type="hidden" value="com_juser" name="option">
          <input type="hidden" value="xls" name="type">
					<input type="hidden" id="hidden_type" name="type" value="">
					<input type="hidden" name="serial_post" value="'.htmlspecialchars(serialize($_POST)).'">
				</form>
				<br><br>';
    print'<form action="index2.php" method="post" name="adminForm">';
		print $table;
    print '<div align="center">';
    print $pageNav->getListFooter();
    print '</div>';
    if(!$_POST['serial_post']){
      print'<input type="hidden" name="serial_post" value="'.htmlspecialchars(serialize($_POST)).'">';
      foreach($_POST as $post_key => $post_value){
         print'<input type="hidden" name="'.$post_key.'" value="'.$post_value.'">';
      }
    }
    else{
      $unserial_post=unserialize(stripslashes($_POST['serial_post']));
      foreach($unserial_post as $post_key => $post_value){
         print'<input type="hidden" name="'.$post_key.'" value="'.$post_value.'">';
      }
      print'<input type="hidden" name="serial_post" value="'.htmlspecialchars(serialize($unserial_post)).'">';
    }
    print '<input type="hidden" name="option" value="com_juser" />';
    print '<input type="hidden" name="task" value="export_execute" id="adminFormsTask"/>';
    print '<input type="hidden" name="hidemainmenu" value="0" />';
    print '</form>';
	}
	function exportUser($ext_fields)
	{
    global $mosConfig_live_site, $mosConfig_absolute_path;
		mosCommonHTML::loadCalendar();
	  ?><table align="left" valign="top" width="100%">
   	<tr>
   		<td width="150" align="left" valign="top" >
   		<?php require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );?>
   		</td>
   		<td align="left" valign="top" style="padding-left:10px">
  	  <table class="adminheading"  >
  		<tr>
  			<th class="user">
  				<?php echo UM_EXPORT_HEAD; ?>: <small>configuration</small>
  			</th>
  		</tr>
  		</table>
  		<script language="javascript">
  			function show_field_values(id)
  			{
  				var c=document.getElementById('field_div_'+id);
  				var e=document.getElementById('expand_field_div_'+id);
  				if(c.style.display == "none"){ c.style.display = "block"; e.src="<?php print $mosConfig_live_site; ?>/administrator/images/collapseall.png";}
  				else{ val=false; c.style.display = "none"; e.src="<?php print $mosConfig_live_site; ?>/administrator/images/expandall.png";}
  			}
  			function selection(id,col)
  			{
  				var c=document.getElementById('select_deselect_'+id);
  				if(c.checked == true)	{ var val=true; }
  				else					{ var val=false; }
  				for(i=0;i<col;i++)		{ document.getElementById('id_filter_field_'+id+'['+i+']').checked=val; }
  			}
  		</script>
  		<form action="index2.php" method="post" name="adminForm">
  			<table cellpadding="4" cellspacing="1" border="0" class="adminform" style="width:60%">
  			<tr><th class="title" nowrap="nowrap"><?php print UM_EXPORT_TABLE_SHOWFIELDS;?></th>
  			<tr>
  				<td nowrap="nowrap" valign="top">
  					<table>
  					<tr><td colspan="5">Standart fields:<hr></td></tr>
  					<tr>
  						<td><input type="checkbox" name="show_field_name" value="show" checked="checked">Name</td>
  						<td><input type="checkbox" name="show_field_username" value="show" checked="checked">User Name</td>
  						<td><input type="checkbox" name="show_field_email" value="show" checked="checked">Email</td>
  						<td><input type="checkbox" name="show_field_registerDate" value="show" checked="checked">Register Date</td>
  						<td><input type="checkbox" name="show_field_block" value="show" checked="checked">Active</td>
  					</tr>
  					<tr><td colspan="5">Extended fields:<hr></td></tr>
  					<tr>
  						<?php
  							$number_column=1;
  							foreach($ext_fields as $field)
  							{
  								if($number_column > 5){print '</tr><tr>';$number_column=1;}
  								print'<td><input type="checkbox" name="show_field_'.$field->field_id.'" value="show" checked="checked">'.$field->title.'</td>';
  								$number_column++;
  							}
  							?>
  					</tr>
  					</table>
  				</td>
  			</tr>
  			</table>
  			<br>
  			<table cellpadding="4" cellspacing="1" border="0" class="adminform" style="width:60%">
  			<tr><th class="title" nowrap="nowrap"><?php print UM_EXPORT_TABLE_ACTIVE;?></th>
  			<tr>
  				<td nowrap="nowrap" valign="top">
  					<input class="inputbox" type="radio" name="user_active" value="0" checked="checked"/> <?php print UM_EXPORT_TABLE_ACTIVEYES;?>
  					<input class="inputbox" type="radio" name="user_active" value="1"/> <?php print UM_EXPORT_TABLE_ACTIVENO;?>
  					<input class="inputbox" type="radio" name="user_active" value="Both"/> <?php print UM_EXPORT_TABLE_ACTIVEBOTH;?>
  				</td>
  			</tr>
  			</table>
  			<br>
  			<table cellpadding="4" cellspacing="1" border="0" class="adminform" style="width:60%">
  			<tr><th class="title" nowrap="nowrap"><?php print UM_EXPORT_TABLE_DATELIMIT;?></th>
  			<tr>
  				<td nowrap="nowrap" valign="top">
  					<?php $current_date=getdate(time());?>
  					<?php $date_month_ago=getdate(time()-31*24*60*60);?>
  					<table>
  					<tr>
  						<td>From:</td>
  						<td>
  							<input class="inputbox" type="text" name="from_date" id="from" size="25" maxlength="19" value="<?php print $date_month_ago[year].'-'.$date_month_ago[mon].'-'.$date_month_ago[mday];?>"/>
  							<input name="reset" type="reset" style="cursor:pointer" class="button" onClick="return showCalendar('from', 'y-mm-dd');" value="...">
  						</td>
  					</tr>
  					<tr>
  						<td>To:</td>
  						<td><input class="inputbox" type="text" name="to_date" id="to" size="25" maxlength="19" value="<?php print $current_date[year].'-'.$current_date[mon].'-'.$current_date[mday];?>"/>
  					<input name="reset" type="reset" style="cursor:pointer" class="button" onClick="return showCalendar('to', 'y-mm-dd');" value="...">
  						</td>
  					</tr>
  					</table>
  				</td>
  			</tr>
  			</table>
  			<br>
  			<table cellpadding="4" cellspacing="1" border="0" class="adminform" style="width:60%">
  			<tr>
  				<th class="title" nowrap="nowrap"><?php print UM_EXPORT_TABLE_FILTERS;?></th>
  			</tr>
  			<tr>
  				<td nowrap="nowrap" valign="top"><?php
  				$i=0;
  				foreach($ext_fields as $field)
  				{
  					if ($field->type == 'file' || $field->type == 'phone' || $field->type == 'simple phone' || $field->type == 'separator') continue;
  					?><fieldset style="clear: both;"><?php
  						?><legend><?php
  						print	($field->type == 'select' || $field->type == 'radio' || $field->type == 'checkbox')?
  								'<img style="cursor:pointer" id="expand_field_div_'.$field->field_id.'" src="'.$mosConfig_live_site.'/administrator/images/expandall.png" onClick="show_field_values('.$field->field_id.')"> ':
  								' ';
  						echo $field->title;
  						?></legend>
  							<?php
  						if($field->type == 'select' || $field->type == 'radio' || $field->type == 'checkbox')
  						{


  							$field_values=explode("\n",str_replace("\r",'',$field->uvalues));
  									?><input onClick="selection('<?php print $field->field_id; ?>',<?php print count($field_values);?>);" type="checkbox" id="select_deselect_<?php print $field->field_id;?>"> <?php print UM_EXPORT_TABLE_SELECTDESELECT;
  									print'<div style="display:none;" id="field_div_'.$field->field_id.'">';?>
  									<hr>
  									<table>
  									<tr><?php
  							$number_column = 1;
  							$i=0;
  							foreach($field_values as $value)
  							{
  								if($number_column > 4){?></tr><tr><?php $number_column=1;}
  								?><td><input type="checkbox" name="filter_field_<?php print $field->field_id;?>[<?php print $i;?>]" id="id_filter_field_<?php print $field->field_id;?>[<?php print $i;?>]" value="filter" ><?php print $value;?></td><?php
  								$number_column++;
  								$i++;
  							}
  								?></tr>
  								</table><?php
  						}
  						else if($field->type == 'date')
  						{
  							?><div nowrap="nowrap">
  							<select name="sign_field_<?php print $field->field_id;?>">
  								<option value="<"><</option>
  								<option value="<=">=<</option>
  								<option value=">">></option>
  								<option value=">=">=></option>
  								<option value="=">=</option>
  							</select>
  							<input class="inputbox" type="text" name="filter_field_<?php print $field->field_id;?>" id="date_filter_<?php print $field->field_id;?>" size="25" maxlength="19" value=""/>
  							<input name="reset" type="reset" style="cursor:pointer" class="button" onClick="return showCalendar('date_filter_<?php print $field->field_id;?>', 'y-mm-dd');" value="...">
  							</div><?php
  						}
  						else
  						{
  							?><input type="text" name="filter_field_<?php print $field->field_id;?>"><?php
  						}

  					?></fieldset><?php
  					$i++;
  				}
  				?></td>
  			</tr>
  			</table>
  			<input type="hidden" name="option" value="com_juser" />
  			<input type="hidden" name="task" value="" />
  			<input type="hidden" name="hidemainmenu" value="0" />
  		</form>
  		</td></tr></table><?php
	}
	function report_configuration($fields)
	{
	  global $mosConfig_absolute_path;
		mosCommonHTML::loadCalendar();
		?>
		<table align="left" valign="top" width="100%">
   	<tr>
   		<td width="150" align="left" valign="top" >
   		<?php require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );?>
   		</td>
   		<td align="center">
			<form action="index2.php" method="post" name="adminForm">
			<script language="javascript">
				function check_all(col)
				{
					var val;
					if(document.getElementById("check_all_").checked == true){ var val=true; }
					else{ val=false; }
					for(i=0;i<col;i++){ document.getElementById("field" + i).checked =val; }
				}
			</script>
			<table class="adminheading" >
			<tr>
				<th class="user">
					<?php echo R_TABLE_HEAD; ?>: <small>configuration</small>
				</th>
			</tr>
			</table>
			<table cellpadding="4" cellspacing="1" border="0" class="adminform" style="width:300px;">
			<tr><th colspan="3" class="title" >Report configuration</th></tr>
			<tr>
				<td nowrap="nowrap" valign="top"><?php echo R_TABLE_FIELDS_SHOWTOTALREPORT; ?>:</td>
				<td nowrap="nowrap">
					<input type="radio" name="show_total" value="0" />
					No
					<input type="radio" name="show_total" value="1" checked="checked" />
					Yes
				</td>
				<td valign="top"></td>
			</tr>
			<tr>
				<td nowrap="nowrap" valign="top"><?php echo R_TABLE_FIELDS_CHECKFIELDS; ?>:</td>
				<td nowrap="nowrap"><?php
				$i=0;
				foreach($fields as $field)
				{
					print '<input type="checkbox" name="field['.$i.']" id="field'.$i.'" value="'.$field->id.'" />'.$field->title.'<br>';
					$i++;
				}
				?></td>
				<td valign="top" nowrap="nowrap"><input onClick="check_all(<?php print $i;?>);" type="checkbox" name="check_all_field" id="check_all_" /> Check all</td>
			</tr>
			<?php $current_date=getdate(time());?>
			<?php $date_month_ago=getdate(time()-31*24*60*60);?>
			<tr>
				<td nowrap="nowrap" valign="top"><?php echo R_TABLE_FIELDS_DATEFROM; ?>:</td>
				<td nowrap="nowrap">
					<input class="inputbox" type="text" name="from" id="from" size="25" maxlength="19" value="<?php print $date_month_ago[year].'-'.$date_month_ago[mon].'-'.$date_month_ago[mday];?>"/>
					<input name="reset" type="reset" class="button" onClick="return showCalendar('from', 'y-mm-dd');" value="...">
				</td>
			</tr>
			<tr>
				<td nowrap="nowrap" valign="top"><?php echo R_TABLE_FIELDS_DATETO; ?>:</td>
				<td nowrap="nowrap">
					<input class="inputbox" type="text" name="to" id="to" size="25" maxlength="19" value="<?php print $current_date[year].'-'.$current_date[mon].'-'.$current_date[mday];?>"/>
					<input name="reset" type="reset" class="button" onClick="return showCalendar('to', 'y-mm-dd');" value="...">
				</td>
			</tr>
			</table>

			<input type="hidden" name="option" value="com_juser" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="hidemainmenu" value="0" />
		</form>
    </td>
    </tr></table><?php
	}
	function editField( $field, $categories, $fields_by_cat, $suggestion='' )
	{
	/*print '$fields_by_cat:<pre>';print_r($fields_by_cat); print'</pre>';
	exit;*/
    if($suggestion)
      $suggestion=unserialize(stripslashes($suggestion));
    //print'<div align="center"><pre>';print_r($suggestion);print'</pre></div>';
		?>
	<form action="index2.php" method="post" name="adminForm">
		<table class="adminheading" >
		<tr>
			<th class="user">
				<?php echo SECTION_MENU_FIELD_MANAGER; ?>: <small>
				<?php echo $field->id || count($suggestion)==0 ? 'Edit' : 'New'; ?>
				</small>
			</th>
		</tr>
		</table>
		<table class="adminform">
			<tr>
				<th colspan="2"> <?php echo $field->id || count($suggestion)==0  ? 'Edit Field' : 'New Field'; ?> </th>
			</tr>
			<tr id="fields_title">
				<td width="130" valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_TITLE; ?>	</td>
				<td>
					<input type="text" name="title" class="inputbox" size="90" value="<?php print $field->title;?>" />
				</td>
			</tr>
			<tr id="fields_type">
				<td valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_TYPE; ?> </td>
				<td> <?php
            if( count($suggestion)>0 && $suggestion['type'] != '' ){
              print '<b>'.$suggestion['type'].'</b>';
              print '<input type="hidden" name="type" value="'.$suggestion['type'].'">';
            }
            else{
              $options[] = mosHTML::makeOption( 'separator', 'separator');
   						$options[] = mosHTML::makeOption( 'text', 'text');
   						$options[] = mosHTML::makeOption( 'textarea', 'textarea');
   						$options[] = mosHTML::makeOption( 'select', 'select');
   						$options[] = mosHTML::makeOption( 'checkbox', 'checkbox');
   						$options[] = mosHTML::makeOption( 'radio', 'radio');
   						$options[] = mosHTML::makeOption( 'date', 'date');
   						$options[] = mosHTML::makeOption( 'file', 'file');
   						$options[] = mosHTML::makeOption( 'simple phone', 'simple phone');
              $options[] = mosHTML::makeOption( 'phone', 'phone');
  						print mosHTML::selectList( $options, 'type', ' id="type" onChange="view();"', 'value', 'text', $field->type );
            }?>
				</td>
			</tr>
			<tr id="fields_type">
				<td valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_GROUP; ?>	</td>
				<td> <?php
						unset($options);
						$options[] = mosHTML::makeOption( '', '');
						foreach($categories as $category)
						{
							$options[] = mosHTML::makeOption( $category->id, $category->name );
						}
						print mosHTML::selectList( $options, 'catid', ' id="select_cat_id" onChange="catChange(document.getElementById(\'select_cat_id\').value);" ', 'value', 'text', $field->catid );?>
				</td>
			</tr>
			<tr id="fields_type">
				<td valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_ORDERING; ?>	</td>
				<td> <?php
				     print JUserDinList($fields_by_cat, '  ', $field->catid , $field->ordering);
						?>
				</td>
			</tr>
      <tr id="fields_type">
				<td valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_SHOWATLIST; ?>	</td>
				<td> <?php
         unset($options);
			   $options[] = mosHTML::makeOption( 1, 'Show at list and at profile' );
			   $options[] = mosHTML::makeOption( 0, 'Show at profile only' );
			   $options[] = mosHTML::makeOption( 2, 'Not show at profile neither list' );
         if(count($suggestion)>0 && isset($suggestion['display_at_users_list']))
         {
           if($suggestion['display_at_users_list_block']){
              print'<b>'.$suggestion['display_at_users_list'].'</b>';
              print'<input type="hidden" name="required" value="'.($suggestion['display_at_users_list'] == 'Show at list and at profile' ? '1' : '0').'">';
           }
           else{
           print mosHTML::selectList( $options, 'display_at_users_list', '', 'value', 'text', ($suggestion['display_at_users_list']=='Show at list and at profile' ? '1' : '0') );
           }
         }
         else
         {
           print mosHTML::selectList( $options, 'display_at_users_list', '', 'value', 'text', $field->display_at_users_list );
         }?>
				</td>
			</tr>
      <tr>
        <td valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_ACCESS; ?>	</td>
        <td><?php
          if(count($suggestion)>0 && isset($suggestion['access']))
          {
            if($suggestion['access_block'])
            {
              print '<b>'.selectListAccess( $suggestion['access'], '' , true ).'</b>';
              print '<input type="hidden" name="access" value="'.$suggestion['access'].'">';
            }
            else
            {
              print selectListAccess( $suggestion['access'] );
            }
          }
          else print mosAdminMenus::Access( $field );
          ?>
        </td>
      </tr>
			<tr id="fields_published">
				<td valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_PUBLISHED; ?>	</td>
				<td> <?php
          if(count($suggestion)>0 && isset($suggestion['published'])){
            if($suggestion['published_block']){
              print'<b>'.$suggestion['published'].'</b>';
              print'<input type="hidden" name="published" value="'.($suggestion['published'] == '1' ? '1' : '0').'">';
            }
            else{
              print mosHTML::yesnoRadioList( 'published', 'class="inputbox" size="1" '.($suggestion['published_block'] ? ' readonly="readonly" ' : ''), $suggestion['published'] == '1' ? '1' : '0' );
            }
          }
          else
          {
             $default_value = $field->id ? $field->published : 1;
   					 print mosHTML::yesnoRadioList( 'published', 'class="inputbox" size="1"', $default_value );
          }?>
				</td>
			</tr>
			<tr id="fields_required">
				<td valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_REQUIRED; ?> </td>
				<td> <?php
        if(count($suggestion)>0 && isset($suggestion['required'])){
          if($suggestion['required_block']){
              print'<b>'.$suggestion['required'].'</b>';
              print'<input type="hidden" name="required" value="'.($suggestion['required'] == '1' ? '1' : '0').'">';
          }
          else{
              print mosHTML::yesnoRadioList( 'required', 'class="inputbox" size="1" ', $suggestion['required'] == '1' ? '1' : '0' );
          }
        }
        else
        {
          $default_value = $field->id ? $field->required : 0;
					print mosHTML::yesnoRadioList( 'required', 'class="inputbox" size="1"', $default_value );
        }?>
				</td>
			</tr>
			<tr id="fields_on_reg">
				<td width="130" valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_SHOWATREG; ?>	</td>
				<td> <?php
          if(count($suggestion)>0 && isset($suggestion['show_at_reg'])){
            if($suggestion['show_at_reg_block']){
              print'<b>'.$suggestion['show_at_reg'].'</b>';
              print'<input type="hidden" name="show_at_edit" value="'.($suggestion['show_at_reg'] == '1' ? '1' : '0').'">';
            }
            else{
               print mosHTML::yesnoRadioList( 'show_at_reg', 'class="inputbox" size="1"', $suggestion['show_at_reg'] == '1' ? '1' : '0' );
            }
          }
          else
          {
            $default_value = $field->id ? $field->show_at_reg : 1;
   					print mosHTML::yesnoRadioList( 'show_at_reg', 'class="inputbox" size="1"', $default_value );
          }?>
				</td>
			</tr>
      <tr id="fields_on_edit">
				<td width="130" valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_SHOWATEDIT; ?>	</td>
				<td> <?php
          if(count($suggestion)>0 && isset($suggestion['show_at_edit'])){
            if($suggestion['show_at_edit_block']){
              print'<b>'.$suggestion['show_at_edit'].'</b>';
              print'<input type="hidden" name="show_at_edit" value="'.($suggestion['show_at_edit'] == '1' ? '1' : '0').'">';
            }
            else{
              print mosHTML::yesnoRadioList( 'show_at_edit', 'class="inputbox" size="1"', $suggestion['show_at_edit'] == '1' ? '1' : '0' );
            }
          }
          else{
             $default_value = $field->id ? $field->show_at_edit : 1;
   					print mosHTML::yesnoRadioList( 'show_at_edit', 'class="inputbox" size="1"', $default_value );
          }?>
				</td>
			</tr>
      <tr id="changeable_on_edit">
				<td width="130" valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_CHANGEABLE; ?>	</td>
				<td> <?php
          if(count($suggestion)>0 && isset($suggestion['changeable'])){
            if($suggestion['changeable_block']){
              print'<b>'.$suggestion['changeable'].'</b>';
              print'<input type="hidden" name="changeable" value="'.($suggestion['changeable'] == '1' ? '1' : '0').'">';
            }
            else{
              print mosHTML::yesnoRadioList( 'changeable', 'class="inputbox" size="1"', $suggestion['changeable'] == '1' ? '1' : '0' );
            }
          }
          else{
             $default_value = $field->id ? $field->changeable : 1;
   					print mosHTML::yesnoRadioList( 'changeable', 'class="inputbox" size="1"', $default_value );
          }?>
				</td>
			</tr>
      <tr id="unique_field">
				<td width="130" valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_UNIQUE; ?>	</td>
				<td> <?php
          if(count($suggestion)>0 && isset($suggestion['unique_field']))
          {
            if($suggestion['unique_field_block']){
              print'<b>'.$suggestion['unique_field'].'</b>';
              print'<input type="hidden" name="unique_field" value="'.($suggestion['unique_field'] == '1' ? '1' : '0').'">';
            }
            else{
              print mosHTML::yesnoRadioList( 'unique_field', 'class="inputbox" size="1"'.($suggestion['unique_field_block'] ? ' readonly="readonly" ' : ''), $suggestion['unique_field'] == '1' ? '1' : '0' );
            }
          }
          else
          {
             $default_value = $field->id ? $field->unique_field : 0;
   					print mosHTML::yesnoRadioList( 'unique_field', 'class="inputbox" size="1"', $default_value );
          }?>
				</td>
			</tr>
			<tr id="search_by_this_field">
				<td width="130" valign="top"> <?php echo FM_TABLE_EDIT_FIELDS_SEARCHBYFIELD; ?>	</td>
				<td> <?php
          if(count($suggestion)>0 && isset($suggestion['search_by_this_field']))
          {
            if($suggestion['search_by_this_field_block']){
              print'<b>'.$suggestion['search_by_this_field'].'</b>';
              print'<input type="hidden" name="search_by_this_field" value="'.($suggestion['search_by_this_field'] == '1' ? '1' : '0').'">';
            }
            else{
              print mosHTML::yesnoRadioList( 'search_by_this_field', 'class="inputbox" size="1"'.($suggestion['search_by_this_field_block'] ? ' readonly="readonly" ' : ''), $suggestion['search_by_this_field'] == '1' ? '1' : '0' );
            }
          }
          else
          {
             $default_value = $field->id ? $field->search_by_this_field : 0;
   					print mosHTML::yesnoRadioList( 'search_by_this_field', 'class="inputbox" size="1"', $default_value );
          }?>
				</td>
			</tr>
			<tr id="fields_validate">
				<td width="130" valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_VALIDATE; ?> </td>
				<td>
          <?php
          if(count($suggestion)>0 && isset($suggestion['validate']))
          {
            //print'<input type="text" name="validate" id="fields_validate_" value="'.$suggestion['validate'].'" size="90" '.($suggestion['validate_block'] ? ' readonly="readonly" ' : '').'>';
            print'<textarea name="validate" id="fields_validate_" '.($suggestion['validate_block'] ? ' readonly="readonly" ' : '').' COLS="65" ROWS="2">'.$suggestion['validate'].'</textarea>';
          }
          else
          {
  					//print'<input type="text" name="validate" id="fields_validate_" value="'.$field->validate.'" size="90">';
  					print'<textarea name="validate" id="fields_validate_" COLS="65" ROWS="2">'.$field->validate.'</textarea>';
          }
          ?>
				</td>
			</tr>
			<tr id="fields_size">
				<td width="130" valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_SIZE; ?> </td>
				<td>
					<?php
            if(count($suggestion)>0 && isset($suggestion['size'])){
              print '<input type="text" name="size" class="inputbox" size="5" id="fields_size_" value="'.$suggestion['size'].'" '.($suggestion['size_block'] ? ' readonly="readonly" ' : '').' />';
            }
            else{
              print '<input type="text" name="size" class="inputbox" size="5" id="fields_size_" value="'.$field->size.'"  />';
            }
          ?>
				</td>
			</tr>
			<tr id="fields_columns_quantity">
				<td width="130" valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_COLUMNS; ?>	</td>
				<td>
					<?php
            if(count($suggestion)>0 && isset($suggestion['count_cols'])){
              print '<input type="text" name="count_cols" class="inputbox" size="5" id="fields_size_" value="'.$suggestion['count_cols'].'" '.($suggestion['count_cols_block'] ? ' readonly="readonly" ' : '').' />';
            }
            else{
              print '<input type="text" name="count_cols" class="inputbox" size="5" id="fields_columns_quantity_" value="'.$field->count_cols.'" />';
            }
          ?>
				</td>
			</tr>
			<tr id="fields_vertical_size">
				<td width="130" valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_VSIZE; ?>	</td>
				<td>
          <?php
          if(count($suggestion)>0 && isset($suggestion['size_vertical'])){
            print'<input type="text" name="size_vertical" class="inputbox" size="5" id="fields_vertical_size_" value="'.$suggestion['size_vertical'].'" '.($suggestion['size_vertical_block'] ? ' readonly="readonly" ' : '').' />';
          }
          else{
					  print'<input type="text" name="size_vertical" class="inputbox" size="5" id="fields_vertical_size_" value="'.$field->size_vertical.'" />';
          }
          ?>
				</td>
			</tr>
			<tr id="fields_values">
				<td width="130" valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_VALUES; ?> </td>
				<td>
           <?php
          if(count($suggestion)>0 && isset($suggestion['values'])){
            $result='';
            $i=0;
            foreach($suggestion['values'] as $value)
            {
              if($i>0){$result .="\r\n";}
              $result .= $value;
              $i++;
            }
            print'<TEXTAREA NAME="values" WRAP="virtual" COLS="65" ROWS="10" id="fields_values_" '.($suggestion['values_block'] ? ' readonly="readonly" ' : '').'>'.$result.'</TEXTAREA>';
          }
          else{
					  print'<TEXTAREA NAME="values" WRAP="virtual" COLS="65" ROWS="10" id="fields_values_">'.$field->uvalues.'</TEXTAREA>';
          }
          ?>
				</td>
			</tr>
			<tr id="fields_default_value">
				<td width="130" valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_DEFAULT_VALUE; ?> </td>
				<td>
           <?php
          if(count($suggestion)>0 && isset($suggestion['default_value'])){
            print'<TEXTAREA NAME="default_value" WRAP="virtual" COLS="65" ROWS="10" id="fields_default_value_" '.($suggestion['default_value_block'] ? ' readonly="readonly" ' : '').'>'.$suggestion['default_value'].'</TEXTAREA>';
          }
          else{
					  print'<TEXTAREA NAME="default_value" WRAP="virtual" COLS="65" ROWS="10" id="fields_default_value_">'.$field->default_value.'</TEXTAREA>';
          }
          ?>
				</td>
			</tr>
			<tr id="fields_description">
				<td width="130" valign="top">	<?php echo FM_TABLE_EDIT_FIELDS_DESCRIPTION; ?>	</td>
				<td>
        <?php
          if(count($suggestion)>0 && isset($suggestion['description'])){
            print'<TEXTAREA NAME="description" WRAP="virtual" COLS="65" ROWS="5" '.($suggestion['description_block'] ? ' readonly="readonly" ' : '').' >'.$suggestion['description'].'</TEXTAREA>';
          }
          else{
					  print'<TEXTAREA NAME="description" WRAP="virtual" COLS="65" ROWS="5">'.$field->description.'</TEXTAREA>';
          }
        ?>
				</td>
			</tr>
		</table>
		<input type="hidden" name="field_id" value="<?php print $field->id;?>" />
		<input type="hidden" name="option" value="com_juser" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="hidemainmenu" value="0" />
	</form>
	<script language="javascript">
		view();
		function view()
		{
			switch(document.getElementById('type').value)
			{
			  case 'separator':
					display_(true,true,true,true,true,true);
					break;
				case 'text':
					display_(false,false,true,true,true,false);
					break;
				case 'textarea':
					display_(false,false,true,false,true,false);
					break;
				case 'select':
					display_(true,true,true,true,false,false);
					break;
				case 'checkbox':
					display_(true,true,false,true,false,false);
					break;
				case 'radio':
					display_(true,true,false,true,false,false);
					break;
				case 'date':
					display_(true,true,true,true,true,true);
					break;
				case 'file':
					display_(true,false,true,true,true,true);
					break;
        case 'phone':
					display_(true,true,true,true,true,true);
					break;
				case 'simple phone':
					display_(true,true,true,true,true,true);
					break;
			}
		}fields_default_value_
		function display_(validate,size,columns_quantity,vertical_size,values,default_value)
		{
			document.getElementById('fields_validate_').disabled = validate;
				if(!validate){document.getElementById('fields_validate').style.color='#000000';}
				else{document.getElementById('fields_validate').style.color='#999999';}
			document.getElementById('fields_size_').disabled = size;
				if(!size){document.getElementById('fields_size').style.color='#000000';}
				else{document.getElementById('fields_size').style.color='#999999';}
			document.getElementById('fields_columns_quantity_').disabled = columns_quantity;
				if(!columns_quantity){document.getElementById('fields_columns_quantity').style.color='#000000';}
				else{document.getElementById('fields_columns_quantity').style.color='#999999';}
			document.getElementById('fields_vertical_size_').disabled = vertical_size;
				if(!vertical_size){document.getElementById('fields_vertical_size').style.color='#000000';}
				else{document.getElementById('fields_vertical_size').style.color='#999999';}
			document.getElementById('fields_values_').disabled = values;
				if(!values){document.getElementById('fields_values').style.color='#000000';}
				else{document.getElementById('fields_values').style.color='#999999';}
			document.getElementById('fields_default_value_').disabled = default_value;
				if(!default_value){document.getElementById('fields_default_value').style.color='#000000';}
				else{document.getElementById('fields_default_value').style.color='#999999';}

		}
	</script>
		<?php
	}

	function showFields($ext_fields, $option, $pageNav)
	{
		global $mosConfig_absolute_path;
		print'<table align="left" valign="top" width="100%"><tr><td width="150" align="left" valign="top" >';
		require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );
		print'</td><td align="left" valign="top" style="padding-left:10px">';
		?>

	<form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
			<th class="user">
				<?php echo SECTION_MENU_FIELD_MANAGER; ?>
			</th>
		</tr>
		</table>
		<table class="adminlist">
		<tr>
			<th width="2%" class="title" >
			#
			</th>
			<th width="3%" class="title">
			<input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count($ext_fields); ?>);" />
			</th>
			<th class="title" width="20%">
			<?php echo FM_TABLE_HEAD_TITLE; ?>
			</th>
			<th width="5%" class="title" >
			<?php echo FM_TABLE_HEAD_TYPE; ?>
			</th>
			<th width="5%" class="title" >
			<?php echo FM_TABLE_HEAD_GROUP; ?>
			</th>
			<th colspan="2" align="center" width="5%">
			<?php echo FM_TABLE_HEAD_MOVE; ?>
			</th>
			<th width="2%">
			<?php echo FM_TABLE_HEAD_ORDER; ?>
			</th>
			<th width="1%">
			<a href="javascript: saveorder( <?php echo count( $ext_fields )-1; ?> )"><img src="images/filesave.png" border="0" width="16" height="16" alt="Save order" /></a>
			</th>
			<th width="5%" class="title" nowrap="nowrap">
			<?php echo FM_TABLE_HEAD_PUBLISHED; ?>
			</th>
			<th width="2%">
			<?php echo FM_TABLE_HEAD_USERS; ?>
			</th>
			<th width="5%" class="title" nowrap="nowrap">
			<?php echo FM_TABLE_HEAD_REQUIRED; ?>
			</th>
      <th width="5%" class="title">
      <?php echo FM_TABLE_HEAD_ACCESS; ?>
      </th>
			<th width="10%" class="title">
			<?php echo FM_TABLE_HEAD_VALUES; ?>
			</th>
		</tr>
		<?php
		$k=0;$i=0;
		foreach( $ext_fields as $field )
		{
		$i++;
    $access 	= mosCommonHTML::AccessProcessing( $field, $i-1 );
		$link 	= 'index2.php?option=com_juser&amp;task=editfield&amp;field_id='. $field->id. '&amp;hidemainmenu=1';
		?>
		<tr class="<?php echo "row$k"; ?>">
			<td>
			<?php echo $i+$pageNav->limitstart;?>
			</td>
			<td>
			<?php echo mosHTML::idBox( $i-1, $field->id ); ?>
			</td>
			<td>
			<a href="<?php echo $link; ?>">
			<?php echo $field->title? $field->title : '(Titleless)'; ?>
			</a>
			</td>
			<td>
			<?php echo $field->type; ?>
			</td>
			<td>
			<a href="index2.php?option=com_categories&section=com_extending_field_list&task=editA&hidemainmenu=1&id=<?php echo $field->catid;?>">
			<?php echo $field->cat_name; ?>
			</a>
			</td>
			<td>
			<?php echo $pageNav->orderUpIcon( $i-1, ($field->catid==$ext_fields[$i-2]->catid)); ?>
			</td>
			<td>
			<?php echo $pageNav->orderDownIcon( $i-1, $n, ($field->catid==$ext_fields[$i]->catid)); ?>
			</td>
			<td align="center" colspan="2">
			<input type="text" name="order[]" size="5" value="<?php echo $field->ordering; ?>" class="text_area" style="text-align: center" />
			</td>
			<td>
			<?php echo $field->published ? '<a href="javascript: void(0);" onClick="return listItemTask(\'cb'.($i-1).'\',\'hide_fields\')"><img src="images/publish_g.png" width="12" height="12" border="0" alt="" /></a>': '<a href="javascript: void(0);" onClick="return listItemTask(\'cb'.($i-1).'\',\'publish_fields\')"><img src="images/publish_x.png" width="12" height="12" border="0" alt="" /></a>'; ?>
			</td>
			<td>
			<?php echo $field->users_count; ?>
			</td>
			<td >
			<?php echo $field->required ? '<img src="images/tick.png" width="12" height="12" border="0" alt="" />': ''; ?>
			</td>
      <td>
      <?php echo $access; ?>
      </td>
			<td>
			<?php
				if($field->uvalues && strlen($field->uvalues)>20)
        {
            echo substr($field->uvalues,0,15).'...';
        }
        else
        {
            echo $field->uvalues;
        }
			?>
			</td>
		</tr>
		<?php
		$k=1-$k;
		}
		?>
		</table>
		<div align="center">
		<?php echo $pageNav->getListFooter(); ?>
		</div>
		<input type="hidden" name="option" value="<?php echo $option;?>" />
		<input type="hidden" name="task" value="extend_fields" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="1" />
	</form>

		<?php
	print'</td></tr></table>';
	}
	function showUsers( &$rows, $pageNav, $search, $option, $lists ) {
		global $mosConfig_absolute_path,$mosConfig_live_site,$database;
		print'<table align="left" valign="top" width="100%"><tr><td width="150" align="left" valign="top" >';
		require_once( $mosConfig_absolute_path ."/administrator/components/com_juser/menubar.php" );
		print'</td><td align="left" valign="top" style="padding-left:10px">';
		?>
		<script language="javascript" type="text/javascript">
			function submitbutton(pressbutton) {
				var form = document.adminForm;
				if (pressbutton == 'moveUsers') {
					if (form.boxchecked.value == 0){
						alert('Please make a selection from the list to move');
						form.group_type.value = 0;
					} else if (confirm('Are you sure you want to move selected items? ')){
						submitform( pressbutton );
					} else {
						form.group_type.value = 0;
					}
				} else {
					submitform( pressbutton );
				}
				return;
			}
		</script>
		<script src="components/com_juser/js/scriptaculous-js-1.7.0/lib/prototype.js" type="text/javascript"></script>
		<script src="components/com_juser/js/scriptaculous-js-1.7.0/src/scriptaculous.js" type="text/javascript"></script>
		<script src="components/com_juser/js/scriptaculous-js-1.7.0/src/effects.js" type="text/javascript"></script>
		<span style="display:none;	:800px;border:1px solid #aaaaaa;padding:10px;background-color:#ffffff" id="src_child">
		</span>
		<script type="text/javascript" language="javascript">

			function showBox(id, cid,pos, uid)
			{
				var p = document.getElementById(id);
				var c = document.getElementById(cid);
				if(c.style.display == 'none')
				{
					//hideBox(cid);
					var top  = (pos == "y") ? p.offsetHeight+2 : 0;
					var left = (pos == "x") ? p.offsetWidth +2 : 0;

					for (; p; p = p.offsetParent)
					{
					top  += p.offsetTop;
					left += p.offsetLeft;
					}

					c.style.position    = "absolute";
					c.style.top         = top +'px';
					c.style.left        = left+'px';
					xajax_show_table(cid,uid);
				}
			}
			function hideBox(cid)
			{
					new Effect.Fold(cid);
			}
		</script>
		<script type="text/javascript" >
			function at_show_aux(parent, child){
			  var p = document.getElementById(parent);
			  var c = document.getElementById(child );
			  var top  = (c["at_position"] == "y") ? p.offsetHeight+2 : 0;
			  var left = (c["at_position"] == "x") ? p.offsetWidth +2 : 0;
			  for (; p; p = p.offsetParent){ top  += p.offsetTop; left += p.offsetLeft; }
			  c.style.position   = "absolute"; c.style.top        = top +'px'; c.style.left       = left+'px'; c.style.visibility = "visible";
			}
			function at_show(){
			  var p = document.getElementById(this["at_parent"]);
			  var c = document.getElementById(this["at_child" ]);
			  at_show_aux(p.id, c.id); clearTimeout(c["at_timeout"]);
			}
			function at_hide(){
			  var c = document.getElementById(this["at_child"]);
			  c["at_timeout"] = setTimeout("document.getElementById('"+c.id+"').style.visibility = 'hidden'", 333);
			}
			function at_click(){
			  var p = document.getElementById(this["at_parent"]);
			  var c = document.getElementById(this["at_child" ]);
			  if (c.style.visibility != "visible") at_show_aux(p.id, c.id); else c.style.visibility = "hidden";
			  return false;
			}
			function at_attach(parent, child, showtype, position, cursor){
			  var p = document.getElementById(parent);
			  var c = document.getElementById(child);
			  p["at_parent"] = p.id; c["at_parent"] = p.id; p["at_child"] = c.id;
			  c["at_child"] = c.id; p["at_position"] = position; c["at_position"] = position;
			  c.style.position   = "absolute"; c.style.visibility = "hidden";
			  if (cursor != undefined) p.style.cursor = cursor;
			  p.onclick = at_click; p.onmouseout  = at_hide; c.onmouseover = at_show; c.onmouseout  = at_hide;
			}
		</script>
		<?php
			HTML_JUser::ShowUsersForm($rows, $pageNav, false, $search, $option, $lists);
			print'</td></tr></table>';
	}
	function ShowUsersForm( &$rows, $pageNav, $simple=false, $search='', $option='', $lists='' )
	{
		global $database,$mosConfig_absolute_path,$mosConfig_live_site;
		?>
		<form action="index<?php print ( $simple ? '3' : '2' )?>.php" method="post" name="adminForm">
		<?php if( !$simple ){ ?>
		<table class="adminheading">
		<tr>
			<th class="user">
			<?php echo SECTION_MENU_USER_MANAGER; ?>
			</th>
			<td>
			Move&nbsp;Selected&nbsp;To:
			</td>
			<td width="right">
			<?php echo $lists['grouptype'];?>
			</td>
			<?php
			if (JEConfig::get('general.filters_show_search')){
  			print '<td>'.FILTERS_SEARCH.':</td>';
  			print '<td>';
  			print '<input type="text" name="search" value="'.htmlspecialchars( $search ).'" class="inputbox" onChange="document.adminForm.submit();" />';
  			print '</td>';
      }
			if (JEConfig::get('general.filters_show_corefilters')){
			  print '<td>'.FILTERS_COREFILTERS.':</td>';
			  print '<td width="right">'.$lists['type'].'</td>';
  			print '<td width="right">'.$lists['logged'].'</td>';
			}
			?>
		  </tr>
		</table>
		<div style="text-align:right;">
		<?php
			if (JEConfig::get('general.filters_show_additionalfilters')){
  			if(count($lists['additional_filters'])>0){
  			  print'<b>'.FILTERS_ADDITIONALFILTERS.':</b>';
  			  foreach($lists['additional_filters'] as $filter){
  			    print ''.$filter.'';
  			  }
  			}
			}
		} ?>
		</div>
		<table class="adminlist">
		<tr>
			<th width="1%" class="title">
			#
			</th>
			<th width="1%" class="title">
			<input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count($rows); ?>);" />
			</th>
			<?php if(is_dir($mosConfig_absolute_path."/administrator/components/com_jcs")){?>
			<th width="1%" class="title">
			Jcs
			</th>
			<?php }?>
			<th width="1%" class="title">
			<?php echo UM_TABLE_HEAD_FILES; ?>
			</th>
			<th class="title">
			<?php echo UM_TABLE_HEAD_NAME; ?>
			</th>
			<th width="15%" class="title" >
			<?php echo UM_TABLE_HEAD_USERNAME; ?>
			</th>
			<th width="5%" class="title" nowrap="nowrap">
			<?php echo UM_TABLE_HEAD_LOGGEDIN; ?>
			</th>
			<th width="5%" class="title">
			<?php echo UM_TABLE_HEAD_ENABLED; ?>
			</th>
			<th width="15%" class="title">
			<?php echo UM_TABLE_HEAD_GROUP; ?>
			</th>
			<th width="15%" class="title">
			<?php echo UM_TABLE_HEAD_EMAIL; ?>
			</th>
			<th width="10%" class="title">
			<?php echo UM_TABLE_HEAD_LASTVISIT; ?>
			</th>
			<th width="1%" class="title">
			<?php echo UM_TABLE_HEAD_ID; ?>
			</th>
		</tr>
		<?php
		$k = 0;
		for ($i=0, $n=count( $rows ); $i < $n; $i++) {
			$row 	=& $rows[$i];

			$img 	= $row->block ? 'publish_x.png' : 'tick.png';
			$task 	= $row->block ? 'unblock' : 'block';
			$alt 	= $row->block ? UM_TABLE_ALT_ENABLEDIMAGE : UM_TABLE_ALT_BLOCKIMAGE;
			$link 	= 'index2.php?option=com_juser&amp;task=editA&amp;id='. $row->id. '&amp;hidemainmenu=1';
			unset($file_block);
			$query = "SELECT *"
					. "\n FROM #__users_extended_data"
					. "\n WHERE `user_id` = ".$row->id." AND `field_id` in (select `id` from #__extending_field_list where `type` = 'file') AND `uvalue` <> ''"
					. "\n ORDER BY `field_id` desc";
			$database->setQuery( $query );
			$files = $database->loadObjectList();
			if(count($files)>0)
			{
				$file_block  = '<img src="'.$mosConfig_live_site.'/administrator/images/filesave.png" id="menu_parent_'.$row->id.'">';
				$file_block .= '<div id="menu_child_'.$row->id.'" style="position: absolute; visibility: hidden; border: 1px solid black; background: #FFFFEE; padding: 2px 5px 2px 5px;">';
				foreach($files as $file_)
				{
					$file_block .='<div>';
					$path=stripslashes(JEConfig::get('general.uploaded_file_directory'));
					$path=str_replace('\\','/',$path);
					$path=str_replace($mosConfig_absolute_path,$mosConfig_live_site,$path);
					$file_block .= $file_->uvalue? '<a target="_blank" href="'.$path.$file_->uvalue.'">'.$file_->uvalue.'</a><br>' : '';
					$file_block .='</div>';
				}
				$file_block .= '</div>';
				$file_block .=	'<script type="text/javascript">';
				$file_block .= 	'	at_attach("menu_parent_'.$row->id.'", "menu_child_'.$row->id.'", "click", "y", "pointer");';
				$file_block .= 	'</script>';
			}
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td>
				<?php echo $i+1+$pageNav->limitstart;?>
				</td>
				<td>
				<?php echo mosHTML::idBox( $i, $row->id ); ?>
				</td>
				<?php if(is_dir($mosConfig_absolute_path."/administrator/components/com_jcs")){
				$query = "select *	from`#__jcs_user_subscr` WHERE `user_id` =". $row->id;
				$database->setQuery( $query );
				$res = $database->loadObjectList();
				?>
				<!--***********************-->
				<td>
				<?php
				if(count($res)>0){
				?>
				<a href="javascript:void(0) ">
					<img id="src_parent<?php print $i;?>" onClick='showBox("src_parent<?php print $i;?>", "src_child","x",<?php print $row->id; ?>)' border="0" src="components/com_jcs/subscription.gif" alt=""/>
				</a>
				<?php }?>
				</td>
				<!--***********************-->
				<?php }?>
				<td>
				<?php echo $file_block; ?>
				</td>
				<td>
				<?php print (!$simple ? '<a href="'.$link.'">' : ''); ?>
				<?php echo $row->name; ?>
				<?php print (!$simple ? '</a>' : ''); ?>
				<td>
				<?php echo $row->username; ?>
				</td>
				</td>
				<td align="center">
				<?php echo $row->loggedin ? '<img src="images/tick.png" width="12" height="12" border="0" alt="" />': ''; ?>
				</td>
				<td>
				<a href="javascript: void(0);" onClick="return listItemTask('cb<?php echo $i;?>','<?php echo $task;?>')">
				<img src="images/<?php echo $img;?>" width="12" height="12" border="0" alt="<?php echo $alt; ?>" />
				</a>
				</td>
				<td>
				<?php echo $row->groupname; ?>
				</td>
				<td>
				<a href="mailto:<?php echo $row->email; ?>">
				<?php echo $row->email; ?>
				</a>
				</td>
				<td nowrap="nowrap">
				<?php echo mosFormatDate( $row->lastvisitDate, _CURRENT_SERVER_TIME_FORMAT ); ?>
				</td>
				<td>
				<?php echo $row->id; ?>
				</td>
			</tr>
			<?php
			$k = 1 - $k;
		}
		?>
		</table>
		<div align="center">
		<?php echo $pageNav->getListFooter(); ?></div>

		<input type="hidden" name="option" value="JUser" />
		<input type="hidden" name="task" value="<?php print $simple ? 'check_email' : '';?>" />
		<input type="hidden" name="client" value="JUser" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="previous_task" value="<?php print mosgetparam($_REQUEST,'task'); ?>" />
		<input type="hidden" name="hidemainmenu" value="0" />
	</form>
		<?php
	}
	function editUser( &$row, &$ext_row, &$contact, &$lists, $option, $uid, &$params ) {
		global $my, $acl;
		global $mosConfig_live_site;

		mosMakeHtmlSafe( $row );

		$tabs = new mosTabs( 0 );

		mosCommonHTML::loadOverlib();
		$canBlockUser 	= $acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'user properties', 'block_user' );
		$canEmailEvents = $acl->acl_check( 'workflow', 'email_events', 'users', $acl->get_group_name( $row->gid, 'ARO' ) );
		?>
		<script language="javascript" type="text/javascript">
		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}
			var r = new RegExp("[\<|\>|\"|\'|\%|\;|\(|\)|\&|\+|\-]", "i");

			// do field validation
			if (trim(form.name.value) == "") {
				alert( "You must provide a name." );
			} else if (form.username.value == "") {
				alert( "You must provide a user login name." );
			} else if (r.exec(form.username.value) || form.username.value.length < 3) {
				alert( "You login name contains invalid characters or is too short." );
			} else if (trim(form.email.value) == "") {
				alert( "You must provide an e-mail address." );
			} else if (form.gid.value == "") {
				alert( "You must assign user to a group." );
			} else if (trim(form.password.value) != "" && form.password.value != form.password2.value){
				alert( "Password do not match." );
			} else if (form.gid.value == "29") {
				alert( "Please Select another group as `Public Front-end` is not a selectable option" );
			} else if (form.gid.value == "30") {
				alert( "Please Select another group as `Public Back-end` is not a selectable option" );
			} else {
				submitform( pressbutton );
			}
		}

		function gotocontact( id ) {
			var form = document.adminForm;
			form.contact_id.value = id;
			submitform( 'contact' );
		}
		</script>
		<form action="index2.php" enctype="multipart/form-data" method="post" name="adminForm">

		<table class="adminheading">
		<tr>
			<th class="user">
			User: <small><?php echo $row->id ? 'Edit' : 'Add';?></small>
			</th>
		</tr>
		</table>

		<table width="100%">
		<tr>
			<td width="60%" valign="top">
				<table class="adminform">
				<tr>
					<th colspan="2">
					<?php echo UM_UD_TABLE_HEAD; ?>
					</th>
				</tr>
				<tr>
					<td width="130">
					<?php echo UM_UD_TABLE_FIELDS_NAME; ?>
					</td>
					<td>
					<input type="text" name="name" class="inputbox" size="40" value="<?php echo $row->name; ?>" maxlength="50" />
					</td>
				</tr>
				<tr>
					<td>
					<?php echo UM_UD_TABLE_FIELDS_USERNAME; ?>
					</td>
					<td>
					<input type="text" name="username" class="inputbox" size="40" value="<?php echo $row->username; ?>" maxlength="25" />
					</td>
				<tr>
					<td>
					<?php echo UM_UD_TABLE_FIELDS_EMAIL; ?>
					</td>
					<td>
					<input class="inputbox" type="text" name="email" size="40" value="<?php echo $row->email; ?>" />
					</td>
				</tr>
        <tr>
      		<?php	$error = isset($row->coreavatarerror) ? $row->coreavatarerror : '';
      		print JUser::create_core_avatar_field('file',ALL_AVATAR_TITLE, $row->coreavatar, 40, $error, $JavaScript, $row->id);?>
      	</tr>
				<tr>
					<td>
					<?php echo UM_UD_TABLE_FIELDS_NEWPASS; ?>
					</td>
					<td>
					<input class="inputbox" type="password" name="password" size="40" value="" />
					</td>
				</tr>
				<tr>
					<td>
					<?php echo UM_UD_TABLE_FIELDS_VERIFYPASS; ?>
					</td>
					<td>
					<input class="inputbox" type="password" name="password2" size="40" value="" />
					</td>
				</tr>
				<tr>
					<td valign="top">
					<?php echo UM_UD_TABLE_FIELDS_GROUP; ?>
					</td>
					<td>
					<?php echo $lists['gid']; ?>
					</td>
				</tr>
				<?php
				if ($canBlockUser) {
					?>
					<tr>
						<td>
						<?php echo UM_UD_TABLE_FIELDS_BLOCKUSER; ?>
						</td>
						<td>
						<?php echo $lists['block']; ?>
						</td>
					</tr>
					<?php
				}
				if ($canEmailEvents) {
					?>
					<tr>
						<td>
						<?php echo UM_UD_TABLE_FIELDS_RSE; ?>
						</td>
						<td>
						<?php echo $lists['sendEmail']; ?>
						</td>
					</tr>
					<?php
				}
				if( $uid ) {
					?>
					<tr>
						<td>
						<?php echo UM_UD_TABLE_FIELDS_REGDATE; ?>
						</td>
						<td>
						<?php echo $row->registerDate;?>
						</td>
					</tr>
				<tr>
					<td>
					<?php echo UM_UD_TABLE_FIELDS_LASTVISIT; ?>
					</td>
					<td>
					<?php echo $row->lastvisitDate;?>
					</td>
				</tr>
					<?php
				}
				?>
				<tr>
					<td colspan="2">&nbsp;

					</td>
				</tr>
				</table>
			</td>
			<td width="40%" valign="top">
				<table class="adminform">
				<tr>
					<th colspan="1">
					<?php echo 'Parameters'; ?>
					</th>
				</tr>
				<tr>
					<td>
					<?php echo $params->render( 'params' );?>
					</td>
				</tr>
				</table>

				<?php
				if ( !$contact ) {
					?>
					<table class="adminform">
					<tr>
						<th>
						Contact Information
						</th>
					</tr>
					<tr>
						<td>
						<br />
						No Contact details linked to this User:
						<br />
						See 'Components -> Contact -> Manage Contacts' for details.
						<br /><br />
						</td>
					</tr>
					</table>
					<?php
				} else {
					?>
					<table class="adminform">
					<tr>
						<th colspan="2">
						Contact Information
						</th>
					</tr>
					<tr>
						<td width="15%">
						Name:
						</td>
						<td>
						<strong>
						<?php echo $contact[0]->name;?>
						</strong>
						</td>
					</tr>
					<tr>
						<td>
						Position:
						</td>
						<td >
						<strong>
						<?php echo $contact[0]->con_position;?>
						</strong>
						</td>
					</tr>
					<tr>
						<td>
						Telephone:
						</td>
						<td >
						<strong>
						<?php echo $contact[0]->telephone;?>
						</strong>
						</td>
					</tr>
					<tr>
						<td>
						Fax:
						</td>
						<td >
						<strong>
						<?php echo $contact[0]->fax;?>
						</strong>
						</td>
					</tr>
					<tr>
						<td></td>
						<td >
						<strong>
						<?php echo $contact[0]->misc;?>
						</strong>
						</td>
					</tr>
					<?php
					if ($contact[0]->image) {
						?>
						<tr>
							<td></td>
							<td valign="top">
							<img src="<?php echo $mosConfig_live_site;?>/images/stories/<?php echo $contact[0]->image; ?>" align="middle" alt="Contact" />
							</td>
						</tr>
						<?php
					}
					?>
					<tr>
						<td colspan="2">
						<br /><br />
						<input class="button" type="button" value="change Contact Details" onclick="javascript: gotocontact( '<?php echo $contact[0]->id; ?>' )">
						<i>
						<br />
						'Components -> Contact -> Manage Contacts'.
						</i>
						</td>
					</tr>
					</table>
					<?php
				}
				?>
			</td>
		</tr>
				<?php
				$catid='';
				$i=0;
				foreach ($ext_row as $field)
				{
					if($catid != $field->catid)
					{
						if($i>0)
						{
								?></table>
								</td>
							</tr><?php
						}
						$i++;
						?>
						<tr>
							<td>
								<table class="adminform">
								<tr>
									<th colspan="2">
									<?php print $field->catid==0?'Other':$field->cat_title; ?>
									</th>
								</tr>
								<?php
							$catid=$field->catid;
					}
					?><tr>
						<?php print JUser::create_field($field,'',$JavaScript=''); ?>
					</tr>
					<?php
				}
        ?>
		</table>

		<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="contact_id" value="" />
		<?php
		if (!$canEmailEvents) {
			?>
			<input type="hidden" name="sendEmail" value="0" />
			<?php
		}
		?>
	</form>
		<?php
	}

}
?>