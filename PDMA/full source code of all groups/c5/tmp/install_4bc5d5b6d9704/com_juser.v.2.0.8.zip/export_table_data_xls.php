<?php 
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
	header("Content-type: application/xls");
	header("Content-Disposition: attachment; filename=downloaded.xls");

	if(isset($_POST['serial_post'])){
      $_POST = array_merge($_POST, unserialize(stripslashes($_POST['serial_post'])));
    }
	
  $query = "SELECT #__extending_field_list. * , #__extending_field_list.id as field_id, #__categories.title as cat_title"
      . "\n FROM #__extending_field_list"
      . "\n LEFT JOIN #__categories ON #__categories.id = #__extending_field_list.catid"
      . "\n WHERE #__extending_field_list.published = 1"
      . "\n ORDER by #__extending_field_list.catid ASC, #__extending_field_list.ordering ASC"
      ;
  $database->setQuery( $query );
  $ext_fields = $database->loadObjectList();

	$additional_sql_fields = '';
	$conditions_having = "\n HAVING 1 ";
	$conditions_where =  "\n WHERE 1 ";
  
	if(mosgetparam($_POST,'user_active')!='Both'){
			$conditions_where.= " AND u.block = '".mosgetparam($_POST,'user_active')."'";
	}
	$conditions_where.=mosgetparam($_POST,'from_date') ? " AND u.registerDate >= '".mosgetparam($_POST,'from_date')."'" : '';
	$conditions_where.=mosgetparam($_POST,'to_date') ? " AND u.registerDate <= '".mosgetparam($_POST,'to_date')."'" : '';
	foreach($ext_fields as $field)
	{
		if($field->type=='file')
		{
			$path=stripslashes(JEConfig::get('general.uploaded_file_directory'));
			$path=str_replace('\\','/',$path);
			$path=str_replace($mosConfig_absolute_path,$mosConfig_live_site,$path);
			$additional_sql_fields .= "\n, IF((SELECT `uvalue` FROM `#__users_extended_data`"
									. "\n WHERE `user_id` = u.id AND `field_id` = '".$field->field_id."')<>'',concat((SELECT `uvalue` FROM `#__users_extended_data`"
									. "\n WHERE `user_id` = u.id AND `field_id` = '".$field->field_id."'),' (','','".$path."','user_',u.id,'field_".$field->field_id."',RIGHT((SELECT `uvalue` FROM `#__users_extended_data`"
									. "\n WHERE `user_id` = u.id AND `field_id` = '".$field->field_id."'),4),')'),'') as `field_".$field->field_id."`";
		}
		else
		{
			$additional_sql_fields .= "\n, (SELECT `uvalue` FROM `#__users_extended_data`"
									. "\n WHERE `user_id` = u.id AND `field_id` = '".$field->field_id."') as `field_".$field->field_id."`";
		}
		$conditions_having .= "\n ".condition_cell($field);
	}
	$query = "SELECT u.id ,u.name, u.username, u.email, u.registerDate, u.block "
   			. $additional_sql_fields
   			. "\n FROM `#__users` as `u`"
   			. $conditions_where
   			. $conditions_having
   			;
	$database->setQuery( $query );
	$rows = $database->loadAssocList();
  
  
  
  $table='<table cellpadding="4" cellspacing="1" border="0" class="adminlist">';
		$table.='<tr>';
		$table.= '<th class="title" nowrap="nowrap">#</th>';
		$table.= mosgetparam($_POST,'show_field_name')=='show' ? '<th class="title" nowrap="nowrap">Name</th>' : '';
		$table.= mosgetparam($_POST,'show_field_username')=='show' ? '<th class="title" nowrap="nowrap">User Name</th>' : '';
		$table.= mosgetparam($_POST,'show_field_email')=='show' ? '<th class="title" nowrap="nowrap">Email</th>' : ''; 
		$table.= mosgetparam($_POST,'show_field_registerDate')=='show' ? '<th class="title" nowrap="nowrap">Register Date</th>' : '';
		$table.= mosgetparam($_POST,'show_field_block')=='show' ? '<th class="title" nowrap="nowrap">Active</th>' : '';
    
		foreach($ext_fields as $field)
		{
			$table.=mosgetparam($_POST,'show_field_'.$field->field_id)=='show' ? '<th class="title" nowrap="nowrap">'.$field->title.'</th>' : '';
		}
		$table.='</tr>';
		$i=0;
		$k=0;
		$table2=$table;

		foreach( $rows as $row )
		{
			$table2.= $i>0 ? '</tr><tr class="row'.$k.'">' : '<tr class="row'.$k.'">';
			$table2.= '<td>'.($i+1).'</td>';
			$table2.= mosgetparam($_POST,'show_field_name')=='show' ? '<td>'.$row['name'].'</td>' : '';
			$table2.= mosgetparam($_POST,'show_field_username')=='show' ? '<td>'.$row['username'].'</td>' : '';
			$table2.= mosgetparam($_POST,'show_field_email')=='show' ? '<td>'.$row['email'].'</td>' : '';
			$table2.= mosgetparam($_POST,'show_field_registerDate')=='show' ? '<td>'.$row['registerDate'].'</td>' : '';
			$table2.= mosgetparam($_POST,'show_field_block')=='show' ? '<td>'.str_limit($row['block'] == 1 ? 'No' : 'Yes' ,50).'</td>' : '';
			foreach($ext_fields as $field)
			{
        $value=$row['field_'.$field->field_id];
        if($field->type=='phone')
        {
          $value=unserialize(stripslashes($value));
          $value=$value[code].' '.$value[prefix].' '.$value[phone];
        }
		
		if($field->type=='simple phone'){
		  $value=unserialize(stripslashes($value));
          $value=$value[prefix].' '.$value[phone];
        }
				$table.= mosgetparam($_POST,'show_field_'.$field->field_id)=='show' ? '<td>'.str_limit($value,50).'</td>' : '';
				$table2.= mosgetparam($_POST,'show_field_'.$field->field_id)=='show' ? '<td>'.$value.'</td>' : '';
			}
        	$i++;
        	$k=1-$k;
		}
		
		$table2.='</td></tr></table>';
  
  
	if($_POST['type']=='xls')
	{
		header("Content-type: application/xls");
		header("Content-Disposition: attachment; filename=downloaded.xls");
		print $table2;
	}
	else
	{
		header("Content-type: application/csv");
		header("Content-Disposition: attachment; filename=downloaded.csv");
		$table_csv=str_replace( '<table cellpadding="4" cellspacing="1" border="0" class="adminlist">'		,'',			$table2);
		$table_csv=str_replace( '</table>'																	,'',			$table_csv);
		$table_csv=str_replace( '<tr>'																		,'',			$table_csv);
		$table_csv=str_replace( '<tr class="row0">'															,'',			$table_csv);
		$table_csv=str_replace( '<tr class="row1">'															,'',			$table_csv);
		$table_csv=str_replace( '</th><th class="title" nowrap="nowrap">'									,'</td><td>',	$table_csv);
		$table_csv=str_replace( '<th class="title" nowrap="nowrap">'										,'<td>',		$table_csv);
		$table_csv=str_replace( '</th>'																		,'<td>',		$table_csv);
		$table_csv=str_replace( '</tr>'																		,"\n",			$table_csv);
		$table_csv=str_replace( '"'																			,'""',			$table_csv);
		$table_csv=str_replace( '</td><td>'																	,'","',			$table_csv);
		$table_csv=str_replace( '<td>'																		,'"',			$table_csv);
		$table_csv=str_replace( '</td>'																		,'"',			$table_csv);
		print $table_csv;
	}
?>