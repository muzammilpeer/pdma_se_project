<?php 
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
?>
<style type="text/css">
	div.jusermenu {
		width: 150px;
		border: 2px solid #414141;
		padding:3px;
	}
	div.jusermenu div.ju_link{
			text-align:left;
			padding-top:3px;
			padding-bottom:3px;
			padding-left:8px;
	}
	div.jusermenu div.head{
			text-align:center;
			background: #414141;
			color:white;
	}
</style>
<div class="jusermenu">
	<div class="head">JUser</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/includes/js/ThemeOffice/users.png" align="absmiddle">
		<a href="index2.php?option=com_juser"><?php echo SECTION_MENU_USER_MANAGER?> </a>
	</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/includes/js/ThemeOffice/categories.png" align="absmiddle">
		<a href="index2.php?option=com_categories&section=com_extending_field_list" > <?php echo SECTION_MENU_FIELD_CATEGORIES?></a>
	</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/includes/js/ThemeOffice/mainmenu.png" align="absmiddle">
		<a href="index2.php?option=com_juser&task=extend_fields"> <?php echo SECTION_MENU_FIELD_MANAGER?></a>
	</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/includes/js/ThemeOffice/config.png" align="absmiddle">
		<a href="index2.php?option=com_juser&task=config"> <?php echo SECTION_MENU_CONFIGURATION?></a>
	</div>
</div>
<br>
<div class="jusermenu">
	<div class="head">JUser Tools</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/components/com_juser/img/reports16.png" align="absmiddle">
		<a href="index2.php?option=com_juser&task=report"> <?php echo SECTION_MENU_REPORT?></a>
	</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/components/com_juser/img/xls.png" align="absmiddle">
		<a href="index2.php?option=com_juser&task=exportUser"> <?php echo UM_TOOLBAR_LABEL_EXPORT?></a>
	</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/includes/js/ThemeOffice/restore.png" align="absmiddle">
		<a href="index2.php?option=com_juser&task=integration_manager"> <?php echo SECTION_MENU_INTEGRATION_MANAGER?></a>
	</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/components/com_juser/img/messaging.png" align="absmiddle" >
		<a href="<?php JUserProSourcePath("newsletter");?>" > <?php echo SECTION_MENU_NEWS_LETTER?></a>
	</div>
	<div class="ju_link">
		<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/components/com_juser/img/check_email.png" align="absmiddle" >
		<a href="<?php JUserProSourcePath("check_email");?>"> <?php echo SECTION_MENU_NEWS_CHECKEMAIL?></a>
	</div>
</div>
<br>
<?php if(is_dir($mosConfig_absolute_path."/administrator/components/com_jcs")){?>
<div class="jusermenu">
	<div class="head">Subscription Plans</div>
	<div class="ju_link">
		<IMG src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/components/com_jcs/subscription.gif" height="16" width="13" align="absmiddle">
		<a href="index2.php?option=com_jcs">Subscription Plans</a>
	</div>
	<div class="ju_link">
		<IMG src="<?php echo $GLOBALS['mosConfig_live_site'];?>/includes/js/ThemeOffice/add_section.png" height="16" width="16" align="absmiddle">
		<a href="index2.php?option=com_categories&section=com_jcs_plans">Subscription Categories</a>
	</div>
	<div class="ju_link">
		<IMG src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/components/com_jcs/usubscription.gif" height="16" width="16" align="absmiddle">
		<a href="index2.php?option=com_jcs&task=usub">User Subscriptions</a>
	</div>
	<div class="ju_link">
		<IMG src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/components/com_jcs/config.png" height="16" width="16" align="absmiddle">
		<a href="index2.php?option=com_jcs&task=config">Configuration</a>
	</div>
	<div class="ju_link">
		<IMG src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/components/com_jcs/reports16.png" height="16" width="16" align="absmiddle">
		<a href="index2.php?option=com_jcs&task=report">Reports</a>
	</div>
</div>
<?php }?>