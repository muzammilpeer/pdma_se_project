<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
	include_once ("lib/jpgraph.php");
	include_once ("lib/jpgraph_line.php");
	include_once ("lib/jpgraph_bar.php");

	$datay=explode('|',$_GET['value']);
	if($_GET['value_plot2'])
	{
	 
	 $datay2=explode('|',$_GET['value_plot2']);
	 $value_max=max($datay);
	 $value_max2=max($datay2);
	 $value_max= $value_max>$value_max2 ? $value_max : $value_max2;
	}
	else
	{
	 $value_max=max($datay);
	}
	
	$datax=explode('|',$_GET['label']);
	
	$graph = new Graph($_GET['sizex'],200,"auto");	
	$graph->img->SetMargin(50,30,40,40);
	$bar_max=round($value_max*1.2)+1;
	$graph->SetScale("textlin",0,round($value_max*1.2)+1);
		
	$graph->SetBackgroundGradient('#ffffff','gray9',GRAD_HOR,BGRAD_PLOT);
	$graph->title->SetColor("gray3"); 
	$graph->SetShadow(FALSE);
	$graph->SetFrame(FALSE);
	$graph->tabtitle->Set($_GET['title']);
	$graph->tabtitle->SetColor('gray3');
	$graph->tabtitle->SetFillColor('white');

	$graph->xaxis->SetFont(FF_FONT1,FS_NORMAL,10);
	$graph->yaxis->SetFont(FF_FONT1,FS_NORMAL,10);

	$graph->yscale->ticks->SupressZeroLabel(false);

	$graph->xaxis->SetTickLabels($datax);

	$bplot = new BarPlot($datay);
	
	$bplot->SetFillColor('plum4@0.3');
	$bplot->SetWidth(0.5);
	$bplot->value->Show();
	$bplot->value->SetFormat('%d');
	$bplot->value->SetFont(FF_FONT1, FS_NORMAL);
	if($_GET['value_plot_legend'])
	{
		$bplot->SetLegend($_GET['value_plot_legend']);
	}
	$bplot->value->SetColor('deeppink4');
	$bplot->SetValuePos('top');
	
	if($_GET['value_plot2'])
	{
		$bplot2 = new BarPlot($datay2);
		//$graph->AddY2($bplot2);
		
		$bplot2->SetFillColor('red@0.3');
		$bplot2->SetWidth(0.5);
		$bplot2->value->Show();
		$bplot2->value->SetFormat('%d');
		$bplot2->value->SetFont(FF_FONT1, FS_NORMAL);
		$bplot2->value->SetColor('deeppink4');
		if($_GET['value_plot2_legend'])
		{
			$bplot2->SetLegend($_GET['value_plot2_legend']);
		}
		$bplot2->SetValuePos('top');
		$bplotG = new GroupBarPlot(array($bplot, $bplot2));
		$bplotG->SetWidth(0.8);
		$graph->Add($bplotG);
		
	}
	else
	{$graph->Add($bplot);}
	
	$graph->yaxis->SetColor("deeppink4");
	
	if(isset($_GET['value_line']))
	{
		$dataC=explode('|',$_GET['value_line']);
		
		$l2plot=new LinePlot($dataC);
		$graph->AddY2($l2plot);
		
		
		$l2plot->SetColor("chartreuse4");
		$l2plot->SetWeight(1);
		if($_GET['line_legend'])
		{
			$l2plot->SetLegend($_GET['line_legend']);
		}
		$l2plot->value->Show();
		$l2plot->value->SetFormat('%d');
		$l2plot->value->SetColor('darkgreen');
		$l2plot->value->SetFont(FF_FONT1, FS_BOLD);
		$l2plot->mark->SetType(MARK_FILLEDCIRCLE);
		$l2plot->mark->SetFillColor("chartreuse4");
		$l2plot->mark->SetWidth(2);
		$value_max=max($dataC);
		$graph->SetY2Scale('lin',0,$bar_max); 
		$graph->y2axis->SetColor("chartreuse4");
	}
	$graph->legend->Pos(0.01,0.01);
	$graph->Stroke();
?>