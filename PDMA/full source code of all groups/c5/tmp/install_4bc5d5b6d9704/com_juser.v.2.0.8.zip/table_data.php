<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
header("Content-type: application/xls");
header("Content-Disposition: attachment; filename=downloaded.xls");
    $value=unserialize(stripslashes(urldecode($_GET['value'])));
    $label=unserialize(stripslashes(urldecode($_GET['label'])));
    $data_table=$_GET['title'].'<br><table cellpadding="4" cellspacing="1" border width="620px" style="width:620px;">';
    $data_table.='<tr><th width="15px">#</th><th >Value</th><th width="65px">Count</th><th width="30px">%</th></tr>';
    $k=0;
    $i=0;
    $summ=array_sum($value);
    foreach($value as $val)
    {
      $data_table.=  '<tr class="row'.$k.'">'
          ."\n".     '<td>'.($i+1).'</td><td>'.$label[$i].'</td><td>'.$val.'</td><td>'.round($val/($summ/100),2).'%</td>'
          ."\n".     '</tr>';
      $k=1-$k;
      $i++;
    }
    $data_table.='</table><br><br>';
    print $data_table;
?>

