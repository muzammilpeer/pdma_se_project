<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined( '_VALID_MOS' ) or die( 'access denied' );
 
  function BackToInstall($error) {
    echo "<script> alert('".$error."'); window.history.go(-1); </script>\n";
    exit();
  }

  function changeIcon($name,$option,$icon,$newlink='') {
    global $database;
    $update= $newlink ? ' , `admin_menu_link` = \''.$database->getEscaped($newlink)."' " : '';
    $database->setQuery( "UPDATE #__components"
    ."\n SET admin_menu_img = '".$icon."' ".$update
    ."\n WHERE name = '".$name."' AND `option` = '".$option."'");
    if (!$database->query()) {
      echo $database->stderr();
      //BackToInstall($database->getErrorMsg());
    }
  }

function com_install() {
  global $database, $mosConfig_absolute_path;

  changeIcon(".JUser","com_juser","js/ThemeOffice/users.png");

  $database->setQuery( "TRUNCATE TABLE `#__juser_integration`");
  $database->setQuery( "TRUNCATE TABLE `#__juser_integration_cash`");
  $database->setQuery( "TRUNCATE TABLE `#__juser_integration_comparisons`");

  $database->setQuery( "UPDATE #__je_config"
    ."\n SET selected = '". $mosConfig_absolute_path."/administrator/components/com_juser/files/'"
    ."\n WHERE name = 'uploaded_file_directory' AND `component` = 'com_juser'");
  $database->query();
  $database->setQuery( "UPDATE #__je_config"
    ."\n SET selected = '". $mosConfig_absolute_path."/images/stories/Avatars/juser_avatars/'"
    ."\n WHERE name = 'uploaded_avatar_directory' AND `component` = 'com_juser'");
  $database->query();

  $dir = $mosConfig_absolute_path."/images/stories/Avatars/";
  if(!is_dir($dir)) mkdir($dir, 0777);
  $dir = $mosConfig_absolute_path."/images/stories/Avatars/juser_avatars";
  if(!is_dir($dir)) mkdir($dir, 0777);

  copy($mosConfig_absolute_path.'/administrator/components/com_juser/img/import.png', $mosConfig_absolute_path.'/administrator/images/import.png');
}
?>