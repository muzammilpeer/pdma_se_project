<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/

// ������ ������� �������
defined( '_VALID_MOS' ) or die( 'access denied' );

class TOOLBAR_JUser {
  function integrationEditor()
  {
    mosMenuBar::startTable();
    mosMenuBar::spacer();
		mosMenuBar::save('integration_editor_save');
    mosMenuBar::spacer();
    mosMenuBar::apply('integration_editor_apply');
    mosMenuBar::spacer();
    mosMenuBar::cancel('integration_editor_cancel');
    mosMenuBar::spacer();
		mosMenuBar::endTable();
  }
	function integrationManager()
	{
		mosMenuBar::startTable();
		mosMenuBar::spacer();
		?>
		<td>
		<a class="toolbar" href="javascript:if (document.adminForm.boxchecked.value == 0){ alert('Please make a selection from the list to Import');}else{submitbutton('import_integration')}">
			<img src="<?php print $GLOBALS['mosConfig_live_site']; ?>/administrator/images/import.png" alt="<?php print INTEGRATION_TOOLBAR_LABEL_IMPORT; ?>" name="import_integration" align="middle" border="0">
			<br><?php print INTEGRATION_TOOLBAR_LABEL_IMPORT; ?>
		</a>
		</td>
		<?php
		/*mosMenuBar::custom( 'import_integration', 'dbrestore2.png', 'dbrestore2.png', INTEGRATION_TOOLBAR_LABEL_IMPORT );*/
		mosMenuBar::spacer();
		mosMenuBar::custom( 'export_integration', 'dbrestore.png', 'dbrestore.png', INTEGRATION_TOOLBAR_LABEL_EXPORT );
		mosMenuBar::spacer();
		mosMenuBar::editListX( 'edit_integration' );
		mosMenuBar::spacer();
		mosMenuBar::deleteList( '', 'delete_integration', 'Uninstall' );
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}
	function send_newsLetter()
	{
		mosMenuBar::startTable();
		mosMenuBar::spacer();
    ?>
		<td>
				<a class="toolbar" href="javascript:document.adminForm.target='_blank';submitbutton('send_newsletter_preview')">
					<img src="images/apply_f2.png" alt="<?php print NL_TOOLBAR_LABEL_PREVIEW; ?>" name="send_newsletter_preview" align="middle" border="0">
          <br><?php print NL_TOOLBAR_LABEL_PREVIEW; ?></a>
		</td>
		<?php
		mosMenuBar::spacer();
		?>
		<td>
				<a class="toolbar" href="javascript:document.adminForm.target='_self';submitbutton('send_newsletter_execute')">
					<img src="images/apply_f2.png" alt="<?php print NL_TOOLBAR_LABEL_EXECUTE; ?>" name="send_newsletter_execute" align="middle" border="0">
          <br><?php print NL_TOOLBAR_LABEL_EXECUTE; ?></a>
		</td>
		<?php
		//mosMenuBar::custom( 'send_newsletter_execute', 'apply_f2.png', 'apply_f2.png', NL_TOOLBAR_LABEL_EXECUTE , false );
		mosMenuBar::spacer();
		mosMenuBar::cancel( 'newsletter');
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}
	function CheckEmail()
	{
		mosMenuBar::startTable();
		mosMenuBar::spacer();
		mosMenuBar::custom( 'fromstart_check_email', 'restore_f2.png', 'restore_f2.png', CE_TOOLBAR_LABEL_FROMSTART , false );
		mosMenuBar::spacer();
		mosMenuBar::deleteList( '', 'delete_check_useremail');
		mosMenuBar::spacer();
		mosMenuBar::custom( 'next_check_email', 'next_f2.png', 'next_f2.png', CE_TOOLBAR_LABEL_NEXT , false );
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}
	function newsLetter()
	{
		mosMenuBar::startTable();
		mosMenuBar::spacer();
		mosMenuBar::custom( 'publishing_newsletter', 'publish.png', 'publish_f2.png', FM_TOOLBAR_LABEL_PUBLISH );
		mosMenuBar::spacer();
		mosMenuBar::custom( 'unpublishing_newsletter', 'unpublish.png', 'unpublish_f2.png', FM_TOOLBAR_LABEL_UNPUBLISH );
		mosMenuBar::spacer();
		mosMenuBar::custom( 'send_newsletter', 'go_f2.png', 'go_f2.png', NL_TOOLBAR_LABEL_SEND , false );
		mosMenuBar::spacer();
		mosMenuBar::custom( 'new_newsletter', 'new_f2.png', 'new_f2.png', NL_TOOLBAR_LABEL_NEW , false );
		mosMenuBar::spacer();
		mosMenuBar::deleteList( '', 'delete_newsletter' );
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}
	function EXPORT_EXECUTE()
	{
		mosMenuBar::startTable();
		?>
		<td>
     <a class="toolbar" href="index2.php?option=com_juser&task=exportUser">
				<img src="<?php print $GLOBALS['mosConfig_live_site'];?>/administrator/images/back_f2.png" alt="<?php print R_TOOLBAR_LABEL_BACK;?>" name="show_users" align="middle" border="0">				<br><?php print R_TOOLBAR_LABEL_BACK;?></a></td>
    <?php
    mosMenuBar::spacer();
//		mosMenuBar::cancel( 'show_users');
    ?>
    <td>
			<a class="toolbar" href="javascript:document.getElementById('adminFormsTask').value='show_users';submitbutton('show_users');">
				<img src="<?php print $GLOBALS['mosConfig_live_site'];?>/administrator/images/cancel_f2.png" alt="<?php print UM_TOOLBAR_LABEL_EXIT;?>" name="show_users" align="middle" border="0">				<br><?php print UM_TOOLBAR_LABEL_EXIT;?></a>
		</td><?php
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}
	function EXPORT_USER()
	{
		mosMenuBar::startTable();
		mosMenuBar::custom( 'export_execute', 'apply.png', 'apply_f2.png', EXPORT_TOOLBAR_LABEL_EXECUTE , false);
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}
	function ReportForPrint()
	{
	}
	function report_execute()
	{
		mosMenuBar::startTable();
		?>
		<td>
     <a class="toolbar" href="index2.php?option=com_juser&task=report">
				<img src="<?php print $GLOBALS['mosConfig_live_site'];?>/administrator/images/back_f2.png" alt="<?php print R_TOOLBAR_LABEL_BACK;?>" name="show_users" align="middle" border="0">				<br><?php print R_TOOLBAR_LABEL_BACK;?></a></td>
    <?php
    mosMenuBar::spacer();
		mosMenuBar::custom( 'report_for_print', 'apply.png', 'apply_f2.png', R_TOOLBAR_LABEL_PRINTVIEW , false);
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}
	function _REPORT()
	{
		mosMenuBar::startTable();
		mosMenuBar::custom( 'report_execute', 'apply.png', 'apply_f2.png', R_TOOLBAR_LABEL_EXECUTE , false);
		mosMenuBar::spacer();
		mosMenuBar::endTable();
	}

	function _FIELDS()
	{
		mosMenuBar::startTable();
		mosMenuBar::custom( 'publish_fields', 'publish.png', 'publish_f2.png', FM_TOOLBAR_LABEL_PUBLISH );
		mosMenuBar::spacer();
		mosMenuBar::custom( 'hide_fields', 'unpublish.png', 'unpublish_f2.png', FM_TOOLBAR_LABEL_UNPUBLISH );
		mosMenuBar::spacer();
		mosMenuBar::custom( 'delete_fields', 'delete.png', 'delete_f2.png', FM_TOOLBAR_LABEL_DELETE );
		mosMenuBar::spacer();
		mosMenuBar::custom( 'new_field', 'new.png', 'new_f2.png', FM_TOOLBAR_LABEL_NEW,false);
		mosMenuBar::endTable();
	}

	function _NEW_FIELD() {
		global $id;

		mosMenuBar::startTable();
		?>
		<td>
			<a class="toolbar" href="javascript:
		  if(document.getElementById('select_cat_id').value==''){
			  alert('Parameter \'Category\' must be filled');
      }
      else{submitbutton('savefield');}">
				<img src="<?php print $GLOBALS['mosConfig_live_site'];?>/administrator/images/save_f2.png" alt="<?php print FM_TOOLBAR_LABEL_SAVE;?>" name="updatefield" align="middle" border="0">				<br><?php print FM_TOOLBAR_LABEL_SAVE;?></a>
		</td>
		<?php
		mosMenuBar::spacer();
		mosMenuBar::cancel( 'canselfield');
		mosMenuBar::spacer();
		mosMenuBar::help( 'screen.users.edit' );
		mosMenuBar::endTable();
	}

	function _EDIT_FIELD() {
		global $id;

		mosMenuBar::startTable();
		?>
		<td>
			<a class="toolbar" href="javascript:
		  if(document.getElementById('select_cat_id').value==''){
			  alert('Parameter \'Category\' must be filled');
      }
      else{submitbutton('updatefield');}">
				<img src="<?php print $GLOBALS['mosConfig_live_site'];?>/administrator/images/save_f2.png" alt="<?php print FM_TOOLBAR_LABEL_SAVE;?>" name="updatefield" align="middle" border="0">				<br><?php print FM_TOOLBAR_LABEL_SAVE;?></a>
		</td>
		<?php
		mosMenuBar::spacer();
		mosMenuBar::cancel( 'canselfield');
		mosMenuBar::spacer();
		mosMenuBar::help( 'screen.users.edit' );
		mosMenuBar::endTable();
	}

	function _EDIT() {
		global $id;

		mosMenuBar::startTable();
		mosMenuBar::save();
		mosMenuBar::spacer();
		mosMenuBar::apply();
		mosMenuBar::spacer();
		if ( $id ) {
			mosMenuBar::cancel( 'cancel', UM_EDIT_TOOLBAR_LABEL_CLOSE );
		} else {
			mosMenuBar::cancel();
		}
		mosMenuBar::spacer();
		mosMenuBar::help( 'screen.users.edit' );
		mosMenuBar::endTable();
	}

	function _DEFAULT() {
		mosMenuBar::startTable();
		mosMenuBar::custom( 'logout', 'cancel.png', 'cancel_f2.png', UM_TOOLBAR_LABEL_LOGOUT );
		mosMenuBar::spacer();
		mosMenuBar::deleteList();
		mosMenuBar::spacer();
		if(is_dir($GLOBALS['mosConfig_absolute_path']."/administrator/components/com_jcs"))
		{?>
		<TD>
			<a class="toolbar" href="javascript:if (document.adminForm.boxchecked.value == 0){ alert('<?php print UM_TOOLBAR_MESSAGE_SUBSCRIBE;?>'); }
			else{ document.adminForm.option.value='com_jcs'; submitbutton('new_subscr'); }">
			<img src="<?php echo $GLOBALS['mosConfig_live_site'];?>/administrator/images/note_f2.png"  alt="Subscribe" name="remove" title="Subscribe" align="middle" border="0" /> <br />Subscribe</a>
		</TD>
		<?php
		mosMenuBar::spacer();
		}
		//mosMenuBar::custom( 'exportUser', 'download_f2.png', 'download_f2.png', UM_TOOLBAR_LABEL_EXPORT, false );
		mosMenuBar::spacer();
		mosMenuBar::editListX();
		mosMenuBar::spacer();
		mosMenuBar::addNewX();
		mosMenuBar::spacer();
		mosMenuBar::help( 'screen.users' );
		mosMenuBar::endTable();
	}
}
?>