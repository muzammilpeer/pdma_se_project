<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
		DEFINE( '_CURRENT_SERVER_TIME_FORMAT', '%Y-%m-%d %H:%M:%S' );
    DEFINE( 'INTEGRATION_MANUALY_FIELD_SUGGESTION', 'To create new or configure one existed JUser field for comparison with this exterior component field you`ll need follow next settings:');
    DEFINE( 'INTEGRATION_MANUALY_FIELD_SUGGESTION_CRITICAL', 'Parameters marked as <font color="#993300">(required)</font> is critical. Without this parameters integration can`t work.');

/*  back end | section "Integration"  */
  /*laying*/
    define( "INTEGRATION_LAYING_IMPORT",				"Import" );
    define( "INTEGRATION_LAYING_EXPORT",				"Export" );
  /*Head table*/
    define( "SECTION_HEAD_INTEGRATION_MANAGER_INSTALL_NEW",		"Install new integration" );
    define( "SECTION_HEAD_INTEGRATION_MANAGER_INSTALLED",		"Installed integrations" );
    define( "SECTION_HEAD_INTEGRATION_EDITOR",		"Integration Editor" );
    define( "SECTION_HEAD_SHOWSYSTEMFIELD",		"Show all fields" );
	/*Toolbar labels*/
    define( "INTEGRATION_TOOLBAR_LABEL_IMPORT",				"Import" );
    define( "INTEGRATION_TOOLBAR_LABEL_EXPORT",				"Export" );
    define( "INTEGRATION_TOOLBAR_LABEL_CHECK",				"Check" );
	/*News Letter table fields*/
		define( "INTEGRATION_TABLE_HEAD",			            "Upload Package File" );
    define( "INTEGRATION_TABLE_FIELD_FILE",			      "Package file:" );

    define( "INTEGRATION_TABLE_FIELD_COMPONENT",			"Component" );
    define( "INTEGRATION_TABLE_FIELD_PUBLISHED",			"Published" );
    define( "INTEGRATION_TABLE_FIELD_SATUSIMPORT",		"Import Ready" );
    define( "INTEGRATION_TABLE_FIELD_SATUSEXPORT",		"Synchronize status" );
    define( "INTEGRATION_TABLE_FIELD_INTEGRATIONDATE","Install Date" );
	/*Messages*/
		define( "INTEGRATION_MESSAGE_WRONGEXTENTION",		"File must have extention *.xml" );
    define( "INTEGRATION_MESSAGE_NOTWRITEABLE",		'Directory  '.$GLOBALS['mosConfig_absolute_path'].'/administrator/components/com_juser/integration/  is not writeable' );
    define( "INTEGRATION_MESSAGE_CANTREADXML", 'Does not manage to read XML with use the list of the styles XSL. Correct the mistake and repeat the attempt later.');
    define( "INTEGRATION_MESSAGE_ALREADYINSTALLED", 'The Scenario to integrations for component %s is already installed.');
    define( "INTEGRATION_MESSAGE_CANTCOPYFILE", 'Failed copy installation file.');
    define( "INTEGRATION_MESSAGE_INSTALLSUCCESS", 'Instalation is completed.');
    define( "INTEGRATION_MESSAGE_UNPUBLISHSUCCESS", 'Integration unpublished success.');
    define( "INTEGRATION_MESSAGE_PUBLISHSUCCESS", 'Integration published success.');
    define( "INTEGRATION_MESSAGE_PUBLISHNOTPOSSIBLE", 'Integration published is not possible. Synchronize status is not ready.');
    define( "INTEGRATION_MESSAGE_EXPORTFINISHEDSUCCESS", 'Export finished Success');
    define( "INTEGRATION_MESSAGE_IMPORTFINISHEDSUCCESS", 'Import finished Success');
    define( "INTEGRATION_MESSAGE_SYNCHRONIZESTATUSISNOTREADY", 'Synchronize status is not ready');
/*  back end | all sections  */
	/*Section menu*/
		define( "SECTION_MENU_USER_MANAGER", 		"User Manager" );
		define( "SECTION_MENU_FIELD_MANAGER", 		"Field Manager" );
		define( "SECTION_MENU_INTEGRATION_MANAGER", "Integration Manager" );
		define( "SECTION_MENU_FIELD_CATEGORIES", 	"Field Categories" );
		define( "SECTION_MENU_CONFIGURATION",		"Configuration" );
		define( "SECTION_MENU_REPORT", 				"Report" );
		define( "SECTION_MENU_SUBSCRIBTIONS", 		"User Subscriptions" );
		define( "SECTION_MENU_NEWS_LETTER", 		"News Letter" );
		define( "SECTION_MENU_NEWS_CHECKEMAIL", 	"Validate User`s Emails" );

/*  back end | section "User Manager"  */
	/*Table head*/
		define( "UM_TABLE_HEAD_FILES",				"Files" );
		define( "UM_TABLE_HEAD_NAME",				"Name" );
		define( "UM_TABLE_HEAD_USERNAME",			"Username" );
		define( "UM_TABLE_HEAD_LOGGEDIN",			"Logged In" );
		define( "UM_TABLE_HEAD_ENABLED",			"Enabled" );
		define( "UM_TABLE_HEAD_GROUP",				"Group" );
		define( "UM_TABLE_HEAD_EMAIL",				"E-Mail" );
		define( "UM_TABLE_HEAD_LASTVISIT",			"Last Visit" );
		define( "UM_TABLE_HEAD_ID",					"ID" );
	/*Table image alts*/
		define( "UM_TABLE_ALT_BLOCKIMAGE",			"Blocked" );
		define( "UM_TABLE_ALT_ENABLEDIMAGE",		"Enabled" );
	/*Toolbar labels*/
		define( "UM_TOOLBAR_LABEL_LOGOUT",			"Logout" );
		define( "UM_TOOLBAR_LABEL_EXPORT",			"Export" );
		define( "EXPORT_TOOLBAR_LABEL_EXECUTE",		"Execute" );
	/*Toolbar messages*/
		define( "UM_TOOLBAR_MESSAGE_SUBSCRIBE",		"Check object from list for subscribing" );
	/*Export head*/
		define( "UM_EXPORT_HEAD",					"Export" );
	/*Export table*/
	  define( "UM_TOOLBAR_LABEL_EXIT",			"Exit" );
		define( "UM_EXPORT_TABLE_FILTERS",			"Filters:" );
		define( "UM_EXPORT_TABLE_SHOWFIELDS",		"Show fields:" );
		define( "UM_EXPORT_TABLE_DATELIMIT",		"Date registration limit:" );
		define( "UM_EXPORT_TABLE_SELECTDESELECT",	"Select all / Deselect all" );
		define( "UM_EXPORT_TABLE_ACTIVE",			"Active:");
		define( "UM_EXPORT_TABLE_ACTIVEYES",		"Yes");
		define( "UM_EXPORT_TABLE_ACTIVENO",			"No");
		define( "UM_EXPORT_TABLE_ACTIVEBOTH",		"Both");
		define( "UM_EXPORT_TABLE_RESULT",			"Result:");

/*  back end | section "News Letter"  */
  /*Head table*/
    define( "SECTION_HEAD_NEWSLETTER_CONDITIONS",		"Conditions" );
	/*Toolbar labels*/
		define( "NL_TOOLBAR_LABEL_NEW",				"New" );
		define( "NL_TOOLBAR_LABEL_DELETEMESSAGE",	"Are you sure delete choosing items?" );
		define( "NL_TOOLBAR_LABEL_CHECKFORDELETE",	"Please choose item from the list for deleting it." );
		define( "NL_TOOLBAR_LABEL_NEW",				"New" );
		define( "NL_TOOLBAR_LABEL_SEND",			"Send" );
		define( "NL_TOOLBAR_LABEL_EMAILCHECK",		"Check" );
    define( "NL_TOOLBAR_LABEL_EXECUTE",		"Execute" );
	/*News Letter table fields*/
		define( "NL_SHOW_TABLE_FIELDS_TITLE",			"Title" );
    define( "NL_SHOW_TABLE_FIELDS_SECTION",			"Section" );
    define( "NL_SHOW_TABLE_FIELDS_CATEGORY",			"Category" );
		define( "NL_SHOW_TABLE_FIELDS_SUBJECT",			"Subject" );
		define( "NL_SHOW_TABLE_FIELDS_MESSAGE",			"Message" );
		define( "NL_SHOW_TABLE_FIELDS_CD",				"Create Date" );
		define( "NL_SHOW_TABLE_FIELDS_STATUS",			"Status" );
		define( "NL_SHOW_TABLE_FIELDS_PUBLISHED",		"Published" );
	/*Messages*/
		define( "NL_MESSAGE_UNPUBLISHED_SUCCESS",		"News letters unpublished success" );
		define( "NL_MESSAGE_PUBLISHED_SUCCESS",			"News letters published success" );

/*  back end | section "News Letter (edit/new)"  */
	/*News Letter table fields*/
		define( "NL_TOOLBAR_LABEL_SAVE",			"Save" );
		define( "NL_TOOLBAR_LABEL_PREVIEW", "Preview" );
		define( "NL_TABLE_FIELDS_TITLE",			"Title:" );
		define( "NL_TABLE_FIELDS_SUBJECT",			"Subject:" );
		define( "NL_TABLE_FIELDS_MESSAGE",			"Message:" );
		define( "NL_TABLE_FIELDS_CONDITIONS",		"Conditions:" );
		define( "NL_TABLE_FIELDS_JCSCONDITIONS",	"Only for users, wich have one or more subscription of:" );
		define( "NL_TABLE_FIELDS_MARK_LILE",		"like" );
		define( "NL_TABLE_FIELDS_MARK_MORETHEN",	">" );
		define( "NL_TABLE_FIELDS_MARK_LESSTHEN",	"<" );
		define( "NL_TABLE_FIELDS_MARK_MOREOREQUALSTHEN",	">=" );
		define( "NL_TABLE_FIELDS_MARK_LESSOREQUALSTHEN",	"<=" );
		define( "NL_TABLE_FIELDS_MARK_QUALSTHEN",	"=" );
		define( "NL_TABLE_FIELDS_MARK_NOTQUALSTHEN",	"<>" );
		define( "NL_TABLE_FIELDS_NOTFOUNDJCS",		"Not found subscription plans." );
		define( "NL_TABLE_FIELDS_HTMLORTEXT",			"Send as:" );
		define( "NL_TABLE_FIELDS_SUBJECT",			"Subject:" );
		define( "NL_TABLE_FIELDS_PRETEXT",			"Greeting:" );
		define( "NL_TABLE_FIELDS_POSTTEXT",			"Signature:" );
		/*other*/
		define( "NL_TABLE_TEXT",			"Text" );
		define( "NL_TABLE_HTML",			"HTML" );

/*  back end | section "Check Email"  */
		define( "CE_TOOLBAR_LABEL_NEXT",			"Next" );
		define( "CE_TOOLBAR_LABEL_DELETE",			"Delete" );
		define( "CE_TOOLBAR_LABEL_FROMSTART",		"From start" );
		define( "CE_CHECKEDANDLEFT",				"Validated %s user`s Emails. Left %s. Validate next %s user`s Emails." );
		define( "CE_VALIDATEPROCESSFINISHED",		"Validation process finished" );
		define( "CE_ALLUSERSVALIDATE",				"All user`s Emails is validated" );
		define( "CE_VALIDATIONBEGINFROMSTART",		"Begin validation from start" );

/*  back end | section "User Manager (edit/new)"  */
	/*User Details table head*/
		define( "UM_UD_TABLE_HEAD", "User Details" );
	/*User Details table fields*/
		define( "UM_UD_TABLE_FIELDS_NAME",			"Name:" );
		define( "UM_UD_TABLE_FIELDS_USERNAME",		"Username:" );
		define( "UM_UD_TABLE_FIELDS_EMAIL",			"E-mail:" );
		define( "UM_UD_TABLE_FIELDS_NEWPASS",		"New Password:" );
		define( "UM_UD_TABLE_FIELDS_VERIFYPASS",	"Verify Password:" );
		define( "UM_UD_TABLE_FIELDS_GROUP", 		"Category:" );
		define( "UM_UD_TABLE_FIELDS_BLOCKUSER",		"Block User" );
		define( "UM_UD_TABLE_FIELDS_RSE", 			"Receive System E-mails" );
		define( "UM_UD_TABLE_FIELDS_REGDATE",		"Register Date" );
		define( "UM_UD_TABLE_FIELDS_LASTVISIT",		"Last Visit Date" );

	/*Extended User Details table head*/
		define( "UM_EUD_TABLE_HEAD",				"Extended User Details" );
	/*Toolbar labels*/
		define( "UM_EDIT_TOOLBAR_LABEL_CLOSE",		"Exit" );

/*  back end | section "Field Manager"  */
	/*Table head*/
		define( "FM_TABLE_HEAD_TITLE",				"Title" );
		define( "FM_TABLE_HEAD_TYPE",				"Type" );
		define( "FM_TABLE_HEAD_GROUP",				"Category" );
		define( "FM_TABLE_HEAD_MOVE",				"Move" );
		define( "FM_TABLE_HEAD_ORDER",				"Order" );
		define( "FM_TABLE_HEAD_PUBLISHED",			"Published" );
		define( "FM_TABLE_HEAD_REQUIRED",			"Required" );
		define( "FM_TABLE_HEAD_ACCESS",			"Access" );
		define( "FM_TABLE_HEAD_VALUES",				"Values" );
		define( "FM_TABLE_HEAD_USERS",				"Users" );
	/*Toolbar labels*/
		define( "FM_TOOLBAR_LABEL_PUBLISH",			"Publish" );
		define( "FM_TOOLBAR_LABEL_UNPUBLISH",		"Unpublish" );
		define( "FM_TOOLBAR_LABEL_DELETE",			"Delete" );
		define( "FM_TOOLBAR_LABEL_NEW",				"New" );

/*  back end | section "Field Manager (edit/new)"  */
	/*Table fields*/
	  define( "FM_TOOLBAR_LABEL_SAVE",			"Save" );
		define( "FM_TABLE_EDIT_FIELDS_TITLE",		"Title" );
		define( "FM_TABLE_EDIT_FIELDS_TYPE",		"Type" );
		define( "FM_TABLE_EDIT_FIELDS_GROUP",		"Category" );
		define( "FM_TABLE_EDIT_FIELDS_ORDERING",		"Ordering" );
		define( "FM_TABLE_EDIT_FIELDS_PUBLISHED",	"Published" );
		define( "FM_TABLE_EDIT_FIELDS_REQUIRED",	"Required" );
		define( "FM_TABLE_EDIT_FIELDS_SHOWATREG",	"Show at registration" );
    define( "FM_TABLE_EDIT_FIELDS_SHOWATEDIT",	"Show at my details" );
    define( "FM_TABLE_EDIT_FIELDS_CHANGEABLE",	"Changeable at my details" );
    define( "FM_TABLE_EDIT_FIELDS_UNIQUE",	"Unique" );
    define( "FM_TABLE_EDIT_FIELDS_SEARCHBYFIELD",	"Filter/search by this field" );
		define( "FM_TABLE_EDIT_FIELDS_VALIDATE",	"Validate( Regular Expression Perl-Compatible)" );
		define( "FM_TABLE_EDIT_FIELDS_SIZE",		"Size" );
		define( "FM_TABLE_EDIT_FIELDS_COLUMNS",		"Columns" );
		define( "FM_TABLE_EDIT_FIELDS_VSIZE",		"Vertical size" );
		define( "FM_TABLE_EDIT_FIELDS_VALUES",		"Values" );
		define( "FM_TABLE_EDIT_FIELDS_DEFAULT_VALUE",		"Default value" );
		define( "FM_TABLE_EDIT_FIELDS_DESCRIPTION",	"Description" );
    define( "FM_TABLE_EDIT_FIELDS_ACCESS",	"Access" );
    define( "FM_TABLE_EDIT_FIELDS_SHOWATLIST",	"Show at" );


/*  back end | section "Report"  */
	/*Toolbar labels*/
		define( "R_TOOLBAR_LABEL_EXECUTE",			"Execute" );
		define( "R_TOOLBAR_LABEL_PRINTVIEW",		"Print View" );
		define( "R_TOOLBAR_LABEL_BACK",		"Back" );
	/*User Details table head*/
		define( "R_TABLE_HEAD", "Report" );
	/*Table fields*/
		define( "R_TABLE_FIELDS_CHECKFIELDS",		"Check fields for report:");
		define( "R_TABLE_FIELDS_SHOWTOTALREPORT",	"Show total report:");
		define( "R_TABLE_FIELDS_DATEFROM",			"Limit Report from date:");
		define( "R_TABLE_FIELDS_DATETO",			"Limit Report to date:");
		define( "R_TABLE_FIELDS_TOTALSTATISIC",		"User Registration Progress");
		define( "R_TABLE_FIELDS_STATISTICBYFIELDS",	"Extended User Information");


/*  front end  */
	/*Registration form*/
		define( "REG_FORM_HEAD_TITLE_REGISTRATION",	"User registration" );
		define( "REG_FORM_HEAD_TITLE_USERDETAILS",	"User Details" );
		define( "REG_FORM_HEAD_NOTICE",				"Welcome to registration!" );
		define( "REG_FORM_HEAD_ATTENTION",			"Required Fields marked with" );
		define( "REG_FORM_FIRST_GROUP",				"Your Details" );
		define( "REG_FORM_SUBMIT_BUTTON_REGISTER",	"Register" );
		define( "REG_FORM_SUBMIT_BUTTON_UPDATE",	"Update" );
		define( "REG_FORM_IAGREE",					"I have read and agree." );
		define( "REQUIRED_MARK_SIGN",					"sign" );
		define( "HEAD_MSG_CAPTCHA_WRONG","You have entered the code from the picture incorrectly" );
		define("REG_FORM_ENTERCAPTCHA",				"Please, enter the code specified on picture:");
	/*messages*/
		/*Error messages*/
		define( "HEAD_MSG_IF_DONT_AGREE",			"You must agree to the terms and conditions to register. If you do not agree please contact the website administrator." );
		define( "HEAD_MSG_CAPTCHA_WRONG",			"You are entered incorect code from picture" );
		define( "MSG_IF_FIELD_IS_EMPTY",			"Field is empty" );
		define( "MSG_IF_FIELD_IS_NOT_VALID",		"Field entry is invalid" );
		define( "HEAD_MSG_IF_FIELD_IS_EMPTY",		"Some required fields have not been completed." );
		define( "HEAD_MSG_IF_PASSWORDS_ISNOT_SAME",	"Password and Verify Password do not match" );
		define( "HEAD_MSG_IF_FILE_EXTEND_ISNOT_CORRECT", "Uploaded file extension is not allowed" );
		define( "MSG_IF_FIELD_IS_UNIQUE_ERROR", "This field is unique. You are entered existing value" );
/*  mail  */
/* send to admin after registration */
		define( "ADMIN_EMAIL_REGISTRATION",			"Hello %s,

A new user has registered at %s. This email contains their details:

Standard Details
User ID:  %s
Name:  %s
e-mail:  %s
Username:  %s

(*extended details*)

Please do not respond to this message as it is automatically generated and is for information purposes only");
		DEFINE('JUSER_USEND_MSG', 'Hello %s,

Thank you for registering at %s. Your account is created and must be activated before you can use it.
Administrator activate you during the day.

After activation you may login to %s using the following username and password:

Username - %s
Password - %s');
/*  Months  */
		define( "ALL_MONTH_JANUARY", "January");
		define( "ALL_MONTH_FEBRUARY", "February");
		define( "ALL_MONTH_MARCH", "March");
		define( "ALL_MONTH_APRIL", "April");
		define( "ALL_MONTH_MAY", "May");
		define( "ALL_MONTH_JUNE", "June");
		define( "ALL_MONTH_JULY", "July");
		define( "ALL_MONTH_AUGUST", "August");
		define( "ALL_MONTH_SEPTEMBER", "September");
		define( "ALL_MONTH_OCTOBER", "October");
		define( "ALL_MONTH_NOVEMBER", "November");
		define( "ALL_MONTH_DECEMBER", "December");
/* Avatar */
    define( "ALL_AVATAR_TITLE", "Avatar");
    define( "ALL_AVATAR_REMOVE", "Remove exist avatar");
    define( "ALL_AVATAR_PHONE_COUNTRY_CODE", "Country code:");
    define( "ALL_AVATAR_PHONE_CITY_CODE", "City code:");
    define( "ALL_AVATAR_PHONE_PHONE_NUMBER", "Phone number:");
    define( "ALL_AVATAR_PHONE_EXTENTION", "Extention:");
    define( "MSG_IF_FILE_IS_TOOBIG", "Image is too big");

/*Filters*/
    define( "FILTERS_SEARCH", "Search");
    define( "FILTERS_COREFILTERS", "Filters");
    define( "FILTERS_ADDITIONALFILTERS", "Additional filters");
	define( "FILTERS_EQUIVALENT", "Like");
	define( "FILTERS_LESS_EQUIVALENT", "Like and less");
	define( "FILTERS_MORE_EQUIVALENT", "Like and more");
	define( "FILTERS_MORE", "More");
	define( "FILTERS_LESS", "Less");

/*Other*/
    define( "JUSER_REG_COMPLETE", '<div class="componentheading">Registration Complete!</div><br />Your account has been created and Administrator activate you diuring day.<br>If you do not activate in diuring one day send email on %s');
    define( "JUSER_ALREADY_REGISTER", '<div class="componentheading">You are already register on this site!</div>You are already register on this site!');
	define( "MSG_FILE_EXIST", "File already exist:");
	?>