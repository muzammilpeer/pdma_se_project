<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
	include_once ("lib/jpgraph.php");
	switch($_GET['type_0'])
	{
		case 'bar':
		case 'line':
			$graph = new Graph(620,250,"auto");	
			$graph->img->SetMargin(50,30,40,40);
			$graph->SetScale("textlin");
			
			$graph->SetBackgroundGradient('gray9','#ffffff',GRAD_HOR,BGRAD_PLOT);
			$graph->SetShadow(FALSE);
			$graph->SetFrame(FALSE);
			if($_GET['title']){
				$graph->tabtitle->Set($_GET['title']);
			}
			$graph->tabtitle->SetColor('gray3');
			$graph->tabtitle->SetFillColor('white');

			$graph->xaxis->SetFont(FF_FONT1,FS_NORMAL,10);
			$graph->yaxis->SetFont(FF_FONT1,FS_NORMAL,10);

			$graph->yscale->ticks->SupressZeroLabel(false);
			break;
		case 'pie':
			include_once ("lib/jpgraph_pie.php");
			$graph = new PieGraph($_GET['xsize'],$_GET['ysize']);
			$graph->img->SetMargin(0,0,0,0);
			if($_GET['title']){
				$graph->title->Set($_GET['title']);
			}
			$graph->SetBackgroundGradient('gray9','#ffffff',GRAD_HOR,BGRAD_PLOT);
			$graph->SetShadow(FALSE);
			$graph->SetFrame(FALSE);
			$graph->tabtitle->SetPos('left');
			$graph->tabtitle->SetColor('gray3');
			$graph->tabtitle->SetFillColor('white');
			$graph->title->SetFont(FF_FONT1,FS_BOLD,10); 
			break;
	}

	$colors=array("brown","cadetblue","chartreuse","cornsilk","darkgoldenrod","darkolivegreen","deeppink","deepskyblue","gainsboro","gray8","hotpink","linen","maroon4","poorple3","rosybrown3","thistle3","turquoise");
	$color_id=0;
	$graph_i=0;
	$max_datay=0;
	while($_GET['type_'.$graph_i])
	{
		switch($_GET['type_'.$graph_i])
		{
			case 'bar':
				include_once ("lib/jpgraph_bar.php");
				
				$bar_i=0;
				while($_GET['value_'.$graph_i.'_'.$bar_i])
				{
					$datay=unserialize(stripslashes(urldecode($_GET['value_'.$graph_i.'_'.$bar_i])));
					$max_datay=max($datay)>$max_datay?max($datay):$max_datay;
					$graph->SetScale("textlin",0,round($max_datay*1.2)+1);
					$bplots[$bar_i]= new BarPlot($datay);
					$bplots[$bar_i]->SetFillColor($colors[$color_id]);
					$color_id++;
					$bplots[$bar_i]->SetWidth(0.5);
					$bplots[$bar_i]->value->Show();
					$bplots[$bar_i]->value->SetFormat('%d');
					$bplots[$bar_i]->value->SetFont(FF_FONT1, FS_NORMAL);
					if($_GET['legend_'.$graph_i.'_'.$bar_i])
					{
						$bplots[$bar_i]->SetLegend($_GET['legend_'.$graph_i.'_'.$bar_i]);
					}
					$bplots[$bar_i]->value->SetColor('deeppink4');
					$bplots[$bar_i]->SetValuePos('top');
					$bar_i++;
				}
				$bplotG = new GroupBarPlot($bplots);
				$graph->Add($bplotG);
				break;
			case 'line':
				include_once ("lib/jpgraph_line.php");
				
				$line_i=0;
				while($_GET['value_'.$graph_i.'_'.$line_i])
				{
					$datay=unserialize(stripslashes(urldecode($_GET['value_'.$graph_i.'_'.$line_i])));
					$max_datay=max($datay)>$max_datay?max($datay):$max_datay;
					$graph->SetScale("textlin",0,round($max_datay*1.2)+1);
					$plot[$line_i]= new LinePlot($datay);
					$plot[$line_i]->SetColor($colors[$color_id]);
					$plot[$line_i]->SetBarCenter();
					$plot[$line_i]->mark->SetType(MARK_FILLEDCIRCLE);
					$plot[$line_i]->mark->SetFillColor($colors[$color_id]);
					$plot[$line_i]->mark->SetWidth(2);
					if($_GET['legend_'.$graph_i.'_'.$line_i]){
						$plot[$line_i]->SetLegend($_GET['legend_'.$graph_i.'_'.$line_i]);
					}
					$graph->Add($plot[$line_i]);
					$color_id++;
					$line_i++;
				}
				break;
			case 'pie':
				include_once ("lib/jpgraph_pie.php");
				$pie_i=0;
				while($_GET['value_'.$graph_i.'_'.$pie_i])
				{
					$data=unserialize(stripslashes(urldecode($_GET['value_'.$graph_i.'_'.$pie_i])));
					$datax=unserialize(stripslashes(urldecode($_GET['label_'.$graph_i.'_'.$pie_i])));
					if(count($data)>20 )
					{
					
						$arrays=array_chunk ($data,20);
						$data=$arrays[0];
						for($array_i=1; $array_i< count($arrays);$array_i++)
						{
							foreach($arrays[$array_i] as $arr)
							{
								$data[20]+=$arr;
							}
						}
					
						$datax=array_chunk ($datax,20);
						$datax=$datax[0];
						$datax[20]="(".$data[20].")Other";
					}
					$plot_pie = new PiePlot($data);
					$plot_pie->SetCenter(0.3,0.5);
					$plot_pie->SetSize(0.3);

					$plot_pie->SetGuideLines(true,false);
					$plot_pie->SetGuideLinesAdjust(1.1);

					$plot_pie->SetLabelType(PIE_VALUE_PER);    
					$plot_pie->value->Show();            
					$plot_pie->value->SetFont(FF_FONT1,FS_NORMAL,7);    
					$plot_pie->value->SetFormat('%2.1f%%');        
					if($_GET['label_'.$graph_i.'_'.$pie_i]){
						$plot_pie->SetLegends($datax);
						$graph->legend->SetAbsPos(0,20,'right','top');
					}
					$graph->Add($plot_pie);
					$pie_i++;
				}
				break;
		}
		$graph_i++;
	}
	
	if($_GET['label'])
	{
		$datax=unserialize(stripslashes(urldecode($_GET['label'])));
		$graph->xaxis->SetTickLabels($datax);
	}

	$graph->legend->Pos(0.01,0.01);
	$graph->Stroke();
?>