<?php
/**
* @copyright Copyright (C) 2006 - 2010 JoomlaEquipment (http://www.joomlaequipment.com). All rights reserved.
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined( '_VALID_MOS' ) or die( 'access denied' );

function changeIcon($name,$option,$icon) {
  global $database,$mosConfig_dbprefix;

  $database->setQuery( "UPDATE #__components"
  ."\n SET admin_menu_img = '".$icon."'"
  ."\n WHERE name = '".$name."' AND `option` = '".$option."'");
  if (!$database->query()) {
    echo $database->getErrorMsg();
  }
}
changeIcon(".JUser","com_juser","js/ThemeOffice/users.png");

$database->setQuery("ALTER TABLE `#__users_extended_data` ADD INDEX `second` ( `user_id` )");
$database->query();
$database->setQuery("ALTER TABLE `#__users_extended_data` ADD INDEX `third` ( `field_id` )");
$database->query();

$sql = "SHOW TABLES";
$database->setQuery($sql);
$rows = $database->loadResultArray();

if(!in_array(str_replace('#__', $mosConfig_dbprefix,'#__juser_integration'), $rows))
{
  $sql = "CREATE TABLE IF NOT EXISTS `#__juser_integration` (
           `id` int(11) NOT NULL auto_increment,
           `component` varchar(50) NOT NULL default '',
           `published` tinyint(1) NOT NULL default '0',
           `export_status` int(11) NOT NULL default '0',
           `import_status` int(11) NOT NULL default '0',
           `integration_data` datetime NOT NULL default '0000-00-00 00:00:00',
           PRIMARY KEY  (`id`)
       ) TYPE=MyISAM;";
  $database->setQuery($sql);
  $database->query();
}

if(!in_array(str_replace('#__', $mosConfig_dbprefix,'#__juser_integration_cash'), $rows))
{
  $sql = "CREATE TABLE IF NOT EXISTS `#__juser_integration_cash` (
           `id` int(11) NOT NULL auto_increment,
           `name` varchar(30) NOT NULL default '',
           `component_id` int(11) NOT NULL default '0',
           `user_id` int(11) NOT NULL default '0',
           `value` text NOT NULL,
           `mdate` datetime NOT NULL default '0000-00-00 00:00:00',
           PRIMARY KEY  (`id`)
         ) TYPE=MyISAM;";
  $database->setQuery($sql);
  $database->query();
}

if(!in_array(str_replace('#__', $mosConfig_dbprefix,'#__juser_integration_comparisons'), $rows))
{
  $sql = "CREATE TABLE IF NOT EXISTS `#__juser_integration_comparisons` (
          `id` int(11) NOT NULL auto_increment,
          `ident` text NOT NULL,
          `name` text NOT NULL,
          `component_id` int(11) NOT NULL default '0',
          `juser_field_id` int(11) NOT NULL default '0',
          `static_juser_field` text NOT NULL,
          `default_value` text NOT NULL,
          `integrate` varchar(30) NOT NULL default '0',
          `m_date` datetime NOT NULL default '0000-00-00 00:00:00',
          PRIMARY KEY  (`id`)
        ) TYPE=MyISAM;";
  $database->setQuery($sql);
  $database->query();
}

if(!in_array(str_replace('#__', $mosConfig_dbprefix,'#__juser_users_additional_data'), $rows))
{
  $sql = "CREATE TABLE IF NOT EXISTS `#__juser_users_additional_data` ("
    . "\n `id`       int(11)   NOT NULL auto_increment,"
    . "\n `user_id`  int(11)   NOT NULL default '0',"
    . "\n `avatar`   text      NOT NULL,"
    . "\n `email_valid` int(11) default NULL,"
    . "\n `mtime`    datetime  NOT NULL default '0000-00-00 00:00:00',"
    . "\n PRIMARY KEY  (`id`)"
    . "\n );";
  $database->setQuery($sql);
  $database->query();
}

$sql = "SHOW COLUMNS FROM #__juser_users_additional_data";
$database->setQuery($sql);
$rows = $database->loadResultArray();
if(in_array('value', $rows))
{
  $sql = "ALTER TABLE `#__juser_users_additional_data` CHANGE `value` `email_valid` INT( 11 ) NULL DEFAULT NULL ";
  $database->setQuery($sql);
  $database->query();
}
$sql = "SHOW COLUMNS FROM #__juser_users_additional_data";
$database->setQuery($sql);
$rows = $database->loadResultArray();
if(!in_array('email_valid', $rows))
{
    $sql = "ALTER TABLE `#__juser_users_additional_data` ADD `email_valid` INT( 11 ) NULL DEFAULT NULL  AFTER `user_id` ;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('avatar', $rows))
{
    $sql = "ALTER TABLE `#__juser_users_additional_data` ADD `avatar` TEXT NOT NULL AFTER `user_id` ;";
    $database->setQuery($sql);
    $database->query();
}
if(in_array('type', $rows))
{
    $sql = "ALTER TABLE `#__juser_users_additional_data` DROP `type`";
    $database->setQuery($sql);
    $database->query();
}

$dir = $mosConfig_absolute_path."/administrator/components/com_juser/files";
if(!is_dir($dir)) mkdir($dir, 0777);
$dir = $mosConfig_absolute_path."/images/stories/Avatars/";
if(!is_dir($dir)) mkdir($dir, 0777);
$dir = $mosConfig_absolute_path."/images/stories/Avatars/juser_avatars";
if(!is_dir($dir)) mkdir($dir, 0777);
$sql = "ALTER TABLE `#__je_config` CHANGE `type` `type` SET( 'selectlist', 'yesno', 'dropdown', 'text', 'textarea', 'page', 'directory', 'sections', 'static_content', 'categories_multiple') NOT NULL";
$database->setQuery($sql);
$database->query();

function newJeconfigParam( $name, $label, $type, $values, $fieldset, $default_value)
{
  global $database;
  $sql = "SELECT id FROM #__je_config WHERE component = 'com_juser' AND name = '".$name."'";
  $database->setQuery($sql);
  $id = $database->loadResult();
  $o['lable']   = $label;
  $o['type']    = $type;
  $o['values']  = $values;
  $o['fieldset']= $fieldset;
  if(!$id) JEConfig::set('general.'.$name, $default_value, $o);
}
function updateJeconfigParam( $oldname, $name, $label, $type, $values, $fieldset, $default_value, $description )
{
  global $database;
  $database->setQuery("UPDATE `#__je_config` SET `lable` = '".$label."',`type` = '".$type."',`values` = '".$values."',`fieldset` = '".$fieldset."', `selected` = '".$default_value."', `name` = '".$name."', `description` = '".$description."' WHERE  `component` = 'com_juser' AND `name` = '".$oldname."'");
  $database->query();
}

//add to config table
newJeconfigParam( 'uploaded_file_directory', 'Directory to Upload Form Files', 'directory', '/administrator/components/com_juser/files/', 'Uploaded file', $dir.'/');
newJeconfigParam( 'allowed_extends', 'Allowed File Extensions', 'textarea', '', 'Uploaded file', "zip\r\nrar\r\njpg\r\ngif\r\npng\r\ndoc\r\nxls");
newJeconfigParam( 'newsletters_sections', 'Newsletters Sections', 'sections', '', 'News Letters', "");
newJeconfigParam( 'show_users_list', 'Show users list', 'yesno', '', 'Users List', "");
newJeconfigParam( 'show_name_at_userlist', 'Show name', 'yesno', '', 'Users List', "");
newJeconfigParam( 'count_cards', 'Cards on one page', 'dropdown', '5, 10, 15, 20, 25, 30, 50', 'Users List', "");
newJeconfigParam( 'show_email_at_userlist', 'Show Email', 'yesno', '', 'Users List', "");
newJeconfigParam( 'show_reg_date_at_userlist', 'Show Data Registration', 'yesno', '', 'Users List', "");
newJeconfigParam( 'show_last_visit_at_userlist', 'Show Last Visit', 'yesno', '', 'Users List', "");
newJeconfigParam( 'show_avatar_at_userlist', 'Show Avatar', 'yesno', '', 'Users List', "");
newJeconfigParam( 'enable_avatar', 'Enable avatar', 'yesno', '', 'Avatar', '');
newJeconfigParam( 'required_avatar', 'Required avatar', 'yesno', '', 'Avatar', '');
newJeconfigParam( 'max_size', 'Max size (pixels)', 'dropdown', '80, 90,100,110,120,130,140,150', 'Avatar', '');
newJeconfigParam( 'uploaded_avatar_directory', 'Uploaded Avatar Directory', 'directory', '/images/', 'Avatar', '');
newJeconfigParam( 'avatar_allowed_extendstory', 'Allowed extends', 'textarea', 'jpg\r\ngif\r\npng', 'Avatar', '');
newJeconfigParam( 'filters_show_search', 'Show search filter', 'yesno', 'jpg\r\ngif\r\npng', 'User Filters', '');
newJeconfigParam( 'filters_show_corefilters', 'Show core filters', 'yesno', 'jpg\r\ngif\r\npng', 'User Filters', '');
newJeconfigParam( 'filters_show_additionalfilters', 'Show additional filters', 'yesno', 'jpg\r\ngif\r\npng', 'User Filters', '');
newJeconfigParam( 'activationuser_manual', 'Manual activation user', 'yesno', '0', 'Activation Users', '');
newJeconfigParam( 'content_after_registration','Content after registration','static_content','','User Registration','');
newJeconfigParam( 'count_chars_captcha',	'Count chars in captcha','selectlist','4, 5, 6, 7, 8, 9, 10','Captcha','4');
newJeconfigParam( 'captcha_character_set','Character set','selectlist','letters and numerals, letters only, numerals only','Captcha','letters and numerals');
newJeconfigParam( 'captcha_on','Captcha on/off','yesno','','Captcha','1');
newJeconfigParam( 'date_format','Date format','selectlist','YYYY-MM-DD, YYYY-DD-MM, MM-DD-YYYY, MM-YYYY-DD, DD-MM-YYYY, DD-YYYY-MM','Other','MM-DD-YYYY');

updateJeconfigParam( 'newsletters_sections', 'newsletters_categories', 'Newsletters Categories', 'categories_multiple', '', 'News Letters', '', 'Newsletters Categories');

$sql = "SHOW COLUMNS FROM #__extending_field_list";
$database->setQuery($sql);
$rows = $database->loadResultArray();
if(in_array('reg_only', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` CHANGE `reg_only` `show_at_reg` TINYINT(1) NOT NULL DEFAULT '1';";
    $database->setQuery($sql);
    $database->query();
    $sql = "UPDATE `#__extending_field_list` SET `show_at_reg` = 1 WHERE `show_at_reg` = 0;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('show_at_edit', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` ADD `show_at_edit` BOOL NOT NULL DEFAULT '1' AFTER `show_at_reg`;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('unique_field', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` ADD `unique_field` BOOL NOT NULL DEFAULT '0' AFTER `show_at_reg`;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('checked_out', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` ADD `checked_out` INT NOT NULL AFTER `alternative_value` ;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('checked_out_time', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` ADD `checked_out_time` DATETIME NOT NULL AFTER `checked_out` ;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('access', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` ADD `access` BOOL NOT NULL DEFAULT '0' AFTER `alternative_value`;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('display_at_users_list', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` ADD `display_at_users_list` BOOL NOT NULL DEFAULT '0' AFTER `alternative_value`;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('search_by_this_field', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` ADD `search_by_this_field` BOOL NOT NULL DEFAULT '0' AFTER `unique_field`;";
    $database->setQuery($sql);
    $database->query();
}
if(!in_array('default_value', $rows))
{
    $sql = "ALTER TABLE `#__extending_field_list` ADD `default_value` TEXT NOT NULL DEFAULT '' AFTER `alternative_value`;";
    $database->setQuery($sql);
    $database->query();
}

unlink(__FILE__);
?>